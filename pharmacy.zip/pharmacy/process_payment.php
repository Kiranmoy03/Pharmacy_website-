<?php
require_once 'config/database.php';
require_once 'config/razorpay_config.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Include Razorpay PHP SDK
require 'vendor/autoload.php';
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $api = new Api($config['key_id'], $config['key_secret']);
    
    try {
        // Get the order ID from the form
        $order_id = $_POST['order_id'];
        $payment_id = $_POST['razorpay_payment_id'];
        $signature = $_POST['razorpay_signature'];
        
        // Verify payment signature
        $attributes = array(
            'razorpay_order_id' => $order_id,
            'razorpay_payment_id' => $payment_id,
            'razorpay_signature' => $signature
        );
        
        $api->utility->verifyPaymentSignature($attributes);
        
        // Payment is successful, update your database
        $sql = "UPDATE orders SET payment_status = 'completed', status = 'processing' WHERE order_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "i", $order_id);
        mysqli_stmt_execute($stmt);
        
        // Redirect to success page
        header("Location: payment_success.php?order_id=" . $order_id);
        exit();
        
    } catch(SignatureVerificationError $e) {
        // Payment verification failed
        header("Location: payment_failed.php?error=payment_verification_failed");
        exit();
    } catch(Exception $e) {
        // Other errors
        header("Location: payment_failed.php?error=payment_processing_error");
        exit();
    }
} else {
    header("Location: checkout.php");
    exit();
}
?>
