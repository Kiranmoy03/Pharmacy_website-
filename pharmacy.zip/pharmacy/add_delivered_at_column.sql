-- Add delivered_at column to orders table
ALTER TABLE orders 
ADD COLUMN IF NOT EXISTS delivered_at TIMESTAMP NULL AFTER status;
