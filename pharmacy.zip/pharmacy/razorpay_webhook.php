<?php
require_once 'config/database.php';
require_once 'config/razorpay_config.php';

// Include Razorpay PHP SDK
require 'vendor/autoload.php';
use Razorpay\Api\Api;

// Get POST data
$webhookBody = file_get_contents('php://input');
$webhookData = json_decode($webhookBody, true);

// Verify webhook signature
$webhookSecret = 'YOUR_WEBHOOK_SECRET'; // Set this in your Razorpay Dashboard -> Webhooks
$expectedSignature = hash_hmac('sha256', $webhookBody, $webhookSecret);

$webhookSignature = $_SERVER['HTTP_X_RAZORPAY_SIGNATURE'] ?? '';

if (!hash_equals($expectedSignature, $webhookSignature)) {
    http_response_code(400);
    error_log('Invalid webhook signature');
    exit('Invalid signature');
}

// Process the webhook event
$event = $webhookData['event'] ?? '';
$payload = $webhookData['payload'] ?? [];
$payment = $payload['payment'] ?? [];
$order = $payload['order'] ?? [];

// Log the webhook for debugging
error_log('Razorpay Webhook: ' . $event . ' - ' . json_encode($payload));

try {
    switch ($event) {
        case 'payment.captured':
            // Payment is captured
            $razorpay_payment_id = $payment['id'] ?? '';
            $razorpay_order_id = $order['id'] ?? '';
            $amount = $payment['amount'] ?? 0;
            $status = strtolower($payment['status'] ?? '');
            
            // Find the order by Razorpay order ID
            $sql = "SELECT * FROM orders WHERE razorpay_order_id = ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "s", $razorpay_order_id);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            $order_data = mysqli_fetch_assoc($result);
            
            if ($order_data) {
                // Verify the amount matches
                $expected_amount = $order_data['total_amount'] * 100; // Convert to paise
                
                if ($amount == $expected_amount) {
                    // Update order status
                    $sql = "UPDATE orders SET 
                            payment_status = 'completed',
                            status = 'processing',
                            razorpay_payment_id = ?,
                            razorpay_signature = ?
                            WHERE order_id = ?";
                    $stmt = mysqli_prepare($conn, $sql);
                    $signature = $webhookSignature; // Store the signature for reference
                    mysqli_stmt_bind_param($stmt, "ssi", $razorpay_payment_id, $signature, $order_data['order_id']);
                    mysqli_stmt_execute($stmt);
                    
                    // Clear the user's cart
                    if (!empty($order_data['user_id'])) {
                        $sql = "DELETE FROM cart WHERE user_id = ?";
                        $stmt = mysqli_prepare($conn, $sql);
                        mysqli_stmt_bind_param($stmt, "i", $order_data['user_id']);
                        mysqli_stmt_execute($stmt);
                    }
                    
                    // Send order confirmation email (you'll need to implement this)
                    // sendOrderConfirmationEmail($order_data['order_id']);
                    
                    error_log("Payment captured for order #" . $order_data['order_id']);
                } else {
                    error_log("Payment amount mismatch for order #" . $order_data['order_id']);
                }
            } else {
                error_log("Order not found for Razorpay order ID: " . $razorpay_order_id);
            }
            break;
            
        case 'payment.failed':
            // Payment failed
            $razorpay_payment_id = $payment['id'] ?? '';
            $error_code = $payment['error_code'] ?? '';
            $error_description = $payment['error_description'] ?? '';
            
            // Find the order by Razorpay payment ID
            $sql = "SELECT * FROM orders WHERE razorpay_payment_id = ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "s", $razorpay_payment_id);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            $order_data = mysqli_fetch_assoc($result);
            
            if ($order_data) {
                // Update order status to failed
                $sql = "UPDATE orders SET 
                        payment_status = 'failed',
                        status = 'failed',
                        notes = CONCAT(IFNULL(notes, ''), ' | Payment failed: ', ?)
                        WHERE order_id = ?";
                $stmt = mysqli_prepare($conn, $sql);
                $error_note = $error_code . ' - ' . $error_description;
                mysqli_stmt_bind_param($stmt, "si", $error_note, $order_data['order_id']);
                mysqli_stmt_execute($stmt);
                
                // Restore product stock (you'll need to implement this)
                // restoreProductStock($order_data['order_id']);
                
                error_log("Payment failed for order #" . $order_data['order_id'] . ": " . $error_description);
            }
            break;
            
        // Add more event handlers as needed
        
        default:
            // Log unhandled events
            error_log("Unhandled webhook event: " . $event);
            break;
    }
    
    // Return a 200 OK response to acknowledge receipt of the webhook
    http_response_code(200);
    echo json_encode(['status' => 'success']);
    
} catch (Exception $e) {
    // Log the error
    error_log("Webhook processing error: " . $e->getMessage());
    
    // Return a 500 error
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
