<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?redirect=cart.php");
    exit();
}

// Get cart items
$user_id = $_SESSION['user_id'];
$sql = "SELECT c.*, p.name, p.price, p.image_url 
        FROM cart c 
        JOIN products p ON c.product_id = p.product_id 
        WHERE c.user_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$cart_items = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Calculate total
$total = 0;
foreach ($cart_items as $item) {
    $total += $item['price'] * $item['quantity'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - PharmaMed</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container mt-4">
        <div class="row">
            <div class="col-12 mb-4">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php" class="text-success text-decoration-none"><i class="fas fa-home me-1"></i>Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Shopping Cart</li>
                    </ol>
                </nav>
                <h2 class="text-success mb-4"><i class="fas fa-shopping-cart me-2"></i>Shopping Cart</h2>
            </div>
                <?php if (empty($cart_items)): ?>
                    <div class="alert alert-info d-flex align-items-center">
                        <i class="fas fa-shopping-cart me-3 fa-2x"></i>
                        <div>
                            <h4 class="alert-heading">Your cart is empty!</h4>
                            <p class="mb-0">Looks like you haven't added any items to your cart yet.</p>
                            <a href="products.php" class="btn btn-success mt-2">
                                <i class="fas fa-shopping-bag me-2"></i>Start Shopping
                            </a>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover border-success">
                            <thead class="table-success">
                                <tr class="text-uppercase">
                                    <th>Product</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Subtotal</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($cart_items as $item): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <img src="<?php echo $item['image_url']; ?>" 
                                                     alt="<?php echo $item['name']; ?>" 
                                                     style="width: 50px; height: 50px; object-fit: cover;">
                                                <div class="ms-3">
                                                    <h5 class="mb-0"><?php echo $item['name']; ?></h5>
                                                </div>
                                            </div>
                                        </td>
                                        <td>₹<?php echo $item['price']; ?></td>
                                        <td>
                                            <form action="includes/update_cart.php" method="POST" class="d-inline">
                                                <input type="hidden" name="cart_id" value="<?php echo $item['cart_id']; ?>">
                                                <input type="number" name="quantity" 
                                                       value="<?php echo $item['quantity']; ?>" 
                                                       min="1" max="100" 
                                                       class="form-control" 
                                                       style="width: 80px;">
                                                    <button type="submit" class="btn btn-sm btn-success mt-2">
                                                        <i class="fas fa-sync-alt me-1"></i>Update
                                                    </button>
                                            </form>
                                        </td>
                                        <td>₹<?php echo $item['price'] * $item['quantity']; ?></td>
                                        <td>
                                            <form action="includes/remove_from_cart.php" method="POST" class="d-inline">
                                                <input type="hidden" name="cart_id" value="<?php echo $item['cart_id']; ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline-danger">
                                                        <i class="far fa-trash-alt me-1"></i>Remove
                                                    </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                            <tfoot>
                                <tr class="table-light">
                                    <td colspan="3" class="text-end"><strong class="h5">Total Amount:</strong></td>
                                    <td class="h5 text-success"><strong>₹<?php echo number_format($total, 2); ?></strong></td>
                                    <td></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    
                    <div class="row mt-4">
                        <div class="col-md-6">
                            <a href="products.php" class="btn btn-outline-success">
                                <i class="fas fa-arrow-left me-2"></i>Continue Shopping
                            </a>
                        </div>
                        <div class="col-md-6 text-end">
                            <form action="includes/place_order.php" method="POST" class="d-inline">
                                <button type="submit" class="btn btn-success btn-lg">
                                    <i class="fas fa-shopping-bag me-2"></i>Proceed to Checkout
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>
