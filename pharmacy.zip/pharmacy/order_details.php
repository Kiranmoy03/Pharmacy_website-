<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?redirect=order_details.php");
    exit();
}

if (!isset($_GET['order_id'])) {
    header("Location: profile.php?error=Invalid order ID");
    exit();
}

$order_id = $_GET['order_id'];

// Get order details
$sql = "SELECT o.*, u.full_name, u.address, u.phone, u.email, u.pincode 
        FROM orders o 
        JOIN users u ON o.user_id = u.user_id 
        WHERE o.order_id = ? AND o.user_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ii", $order_id, $_SESSION['user_id']);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$order = mysqli_fetch_assoc($result);

if (!$order) {
    header("Location: profile.php?error=Invalid order");
    exit();
}

// Get order items
$sql = "SELECT oi.*, p.name as product_name 
        FROM order_items oi 
        JOIN products p ON oi.product_id = p.product_id 
        WHERE oi.order_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $order_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$order_items = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Details - PharmaMed</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5>Order Details</h5>
                        <a href="profile.php" class="btn btn-secondary btn-sm">
                            <i class="fas fa-arrow-left"></i> Back to Orders
                        </a>
                    </div>
                    <div class="card-body">
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <h6>Order Information</h6>
                                <p><strong>Order ID:</strong> #<?php echo $order['order_id']; ?></p>
                                <p><strong>Order Date:</strong> <?php echo date('F j, Y', strtotime($order['created_at'])); ?></p>
                                <?php 
                                // Calculate estimated delivery date (2 business days from order date)
                                $order_date = new DateTime($order['created_at']);
                                $business_days = 0;
                                $days_to_add = 0;
                                while ($business_days < 2) {
                                    $days_to_add++;
                                    $order_date->modify('+1 day');
                                    // Skip weekends (0 = Sunday, 6 = Saturday)
                                    if (!in_array($order_date->format('N'), [6, 7])) {
                                        $business_days++;
                                    }
                                }
                                $estimated_delivery = $order_date->format('F j, Y');
                                ?>
                                <p><strong>Estimated Delivery:</strong> <?php echo $estimated_delivery; ?></p>
                                <p><strong>Status:</strong> 
                                    <span class="badge bg-<?php 
                                        echo $order['status'] == 'cancelled' ? 'danger' : 
                                               ($order['status'] == 'returned' ? 'warning' : 
                                                ($order['status'] == 'completed' ? 'success' : 'primary'));
                                    ?>"><?php echo ucfirst($order['status'] == 'completed' ? 'Delivered' : 
                                                                   ($order['status'] == 'cancelled' ? 'Cancelled' : 
                                                                    ($order['status'] == 'returned' ? 'Returned' : 'Ordered')));
                                    ?></span>
                                </p>
                                <p><strong>Payment Method:</strong> <?php echo strtoupper($order['payment_method']); ?></p>
                            </div>
                            <div class="col-md-6">
                                <h6>Shipping Information</h6>
                                <p><strong>Name:</strong> <?php echo htmlspecialchars($order['full_name']); ?></p>
                                <p><strong>Address:</strong> <?php echo nl2br(htmlspecialchars($order['address'])); ?></p>
                                <p><strong>Pin Code:</strong> <?php echo htmlspecialchars($order['pincode']); ?></p>
                                <p><strong>Email:</strong> <?php echo htmlspecialchars($order['email']); ?></p>
                                <p><strong>Phone:</strong> <?php echo htmlspecialchars($order['phone']); ?></p>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Quantity</th>
                                        <th>Price</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($order_items as $item): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                            <td><?php echo $item['quantity']; ?></td>
                                            <td>₹<?php echo number_format($item['price'], 2); ?></td>
                                            <td>₹<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="3" class="text-end"><strong>Total Amount:</strong></td>
                                        <td><strong>₹<?php echo number_format($order['total_amount'], 2); ?></strong></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>

                        <?php if ($order['status'] == 'cancelled' || $order['status'] == 'returned'): ?>
                            <div class="alert alert-info mt-4">
                                This order has been <?php echo $order['status'] == 'cancelled' ? 'cancelled' : 'returned'; ?>.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>
