<?php
// Database configuration file

define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'pharmacy_db');

// Function to create database tables
function createDatabaseTables($conn) {
    // Create prescriptions table
    $sql = 'CREATE TABLE IF NOT EXISTS `prescriptions` (' . 
           '`id` int(11) NOT NULL AUTO_INCREMENT, ' .
           '`user_id` int(11) NOT NULL, ' .
           '`file_path` varchar(255) NOT NULL, ' .
           '`notes` text DEFAULT NULL, ' .
           '`status` enum("pending","approved","rejected") NOT NULL DEFAULT "pending", ' .
           '`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP, ' .
           '`updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP, ' .
           'PRIMARY KEY (`id`), ' .
           'KEY `user_id` (`user_id`) ' .
           ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4';

    if (!mysqli_query($conn, $sql)) {
        error_log('Error creating prescriptions table: ' . mysqli_error($conn));
        return false;
    }
    
    return true;
}

// Attempt to connect to MySQL database
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD);

// Check connection
if(!$conn) {
    die('ERROR: Could not connect to MySQL. ' . mysqli_connect_error());
}

// Create database if not exists
$sql = 'CREATE DATABASE IF NOT EXISTS ' . DB_NAME;
if(mysqli_query($conn, $sql)) {
    if (!mysqli_select_db($conn, DB_NAME)) {
        die('Error selecting database: ' . mysqli_error($conn));
    }
    
    // Create necessary tables
    if (!createDatabaseTables($conn)) {
        error_log('Warning: Failed to create one or more database tables');
    }
} else {
    die('Error creating database: ' . mysqli_error($conn));
}
?>
