<?php
// Razorpay Configuration
return [
    'key_id' => 'YOUR_KEY_ID',         // Replace with your Razorpay Key ID
    'key_secret' => 'YOUR_KEY_SECRET', // Replace with your Razorpay Key Secret
    'display_currency' => 'INR',
];
?>
