<?php
require_once 'config/database.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get order ID from query string
$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;

// Get order details
$sql = "SELECT o.*, u.email, u.full_name 
        FROM orders o 
        JOIN users u ON o.user_id = u.user_id 
        WHERE o.order_id = ? AND o.user_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ii", $order_id, $_SESSION['user_id']);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$order = mysqli_fetch_assoc($result);

// Redirect if order not found
if (!$order) {
    header("Location: profile.php?error=order_not_found");
    exit();
}

// Get order items
$sql = "SELECT oi.*, p.name as product_name, p.image_url 
        FROM order_items oi 
        JOIN products p ON oi.product_id = p.product_id 
        WHERE oi.order_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $order_id);
mysqli_stmt_execute($stmt);
$order_items = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmed - PharmaMed</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .success-animation {
            text-align: center;
            margin: 30px 0;
        }
        .checkmark {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            display: block;
            stroke-width: 5;
            stroke: #4bb71b;
            stroke-miterlimit: 10;
            margin: 10% auto 20px;
            box-shadow: inset 0 0 0 #4bb71b;
            animation: fill .4s ease-in-out .4s forwards, scale .3s ease-in-out .9s both;
        }
        .checkmark__circle {
            stroke-dasharray: 166;
            stroke-dashoffset: 166;
            stroke-width: 5;
            stroke-miterlimit: 10;
            stroke: #4bb71b;
            fill: none;
            animation: stroke .6s cubic-bezier(0.65, 0, 0.45, 1) forwards;
        }
        .checkmark__check {
            transform-origin: 50% 50%;
            stroke-dasharray: 48;
            stroke-dashoffset: 48;
            animation: stroke .3s cubic-bezier(0.65, 0, 0.45, 1) .8s forwards;
        }
        @keyframes stroke {
            100% { stroke-dashoffset: 0; }
        }
        @keyframes scale {
            0%, 100% { transform: none; }
            50% { transform: scale3d(1.1, 1.1, 1); }
        }
        @keyframes fill {
            100% { box-shadow: inset 0 0 0 100vh #f1f8e9; }
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-5">
                        <div class="text-center mb-5">
                            <div class="success-animation">
                                <svg class="checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52">
                                    <circle class="checkmark__circle" cx="26" cy="26" r="25" fill="none"/>
                                    <path class="checkmark__check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
                                </svg>
                            </div>
                            <h2 class="fw-bold mb-3">Order Confirmed!</h2>
                            <p class="lead text-muted mb-4">Thank you for your order, <?php echo htmlspecialchars($order['full_name']); ?>!</p>
                            <p>Your order #<?php echo $order['order_id']; ?> has been received and is being processed.</p>
                            
                            <?php if ($order['payment_method'] === 'cod'): ?>
                                <div class="alert alert-info">
                                    <h5 class="alert-heading"><i class="fas fa-money-bill-wave me-2"></i> Cash on Delivery</h5>
                                    <p class="mb-0">Please have the exact amount ready for the delivery person.</p>
                                </div>
                            <?php endif; ?>
                            
                            <div class="d-flex justify-content-center gap-3 mt-4">
                                <a href="order_details.php?order_id=<?php echo $order['order_id']; ?>" class="btn btn-primary px-4">
                                    <i class="fas fa-receipt me-2"></i>View Order Details
                                </a>
                                <a href="index.php" class="btn btn-outline-secondary px-4">
                                    <i class="fas fa-shopping-bag me-2"></i>Continue Shopping
                                </a>
                            </div>
                        </div>
                        
                        <div class="border-top pt-4 mt-4">
                            <h5 class="mb-4">Order Summary</h5>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <h6>Order Number</h6>
                                    <p class="text-muted">#<?php echo $order['order_id']; ?></p>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <h6>Date</h6>
                                    <p class="text-muted"><?php echo date('F j, Y', strtotime($order['created_at'])); ?></p>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <h6>Total</h6>
                                    <p class="text-muted">₹<?php echo number_format($order['total_amount'], 2); ?></p>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <h6>Payment Method</h6>
                                    <p class="text-muted text-uppercase"><?php echo $order['payment_method']; ?></p>
                                </div>
                            </div>
                            
                            <div class="mt-4">
                                <h6>Delivery Address</h6>
                                <p class="text-muted">
                                    <?php echo nl2br(htmlspecialchars($order['shipping_address'])); ?><br>
                                    Pincode: <?php echo htmlspecialchars($order['pincode']); ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="text-center mt-4">
                    <p class="text-muted">
                        Need help? <a href="contact.php" class="text-decoration-none">Contact us</a> or call us at 
                        <a href="tel:+911234567890" class="text-decoration-none">+91 1234567890</a>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Clear cart after successful order
        if (localStorage.getItem('cart')) {
            localStorage.removeItem('cart');
        }
    </script>
</body>
</html>
