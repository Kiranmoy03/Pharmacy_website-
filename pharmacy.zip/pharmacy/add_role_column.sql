-- Add role column to users table
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS role VARCHAR(20) DEFAULT 'user';

-- Add admin user (you can modify the username and password as needed)
INSERT INTO users (username, email, password, full_name, phone, role)
VALUES ('admin', 'admin@example.com', 
       '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
       'Admin User', '1234567890', 'admin');

-- The password above is 'password' hashed with PHP's password_hash() function
-- You should change this to a secure password in production
