-- Sample Users
INSERT INTO users (username, email, password, full_name, phone, address) VALUES
('john_doe', 'john@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'John Doe', '9876543210', '123 Main St, City'),
('jane_smith', 'jane@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Jane Smith', '9876543211', '456 Oak Ave, City');

-- Sample Products
INSERT INTO products (name, description, price, stock_quantity, category, manufacturer, image_url) VALUES
('Paracetamol 500mg', 'Pain relief and fever reducer', 10.00, 100, 'Pain Relief', 'Generic', 'assets/images/paracetamol.jpg'),
('Ibuprofen 400mg', 'Anti-inflammatory pain reliever', 15.00, 150, 'Pain Relief', 'Generic', 'assets/images/ibuprofen.jpg'),
('Antacid Syrup', 'For heartburn and indigestion', 20.00, 200, 'Digestive', 'Generic', 'assets/images/antacid.jpg'),
('Cough Syrup', 'For dry and productive cough', 25.00, 180, 'Respiratory', 'Generic', 'assets/images/cough_syrup.jpg'),
('Antibiotic Tablet', 'Broad spectrum antibiotic', 30.00, 120, 'Antibiotics', 'Generic', 'assets/images/antibiotic.jpg'),
('Multivitamin', 'Daily multivitamin supplement', 40.00, 250, 'Supplements', 'Generic', 'assets/images/multivitamin.jpg'),
('Eye Drops', 'For dry and irritated eyes', 22.00, 150, 'Eye Care', 'Generic', 'assets/images/eye_drops.jpg'),
('Antiseptic Liquid', 'For wound cleaning', 18.00, 200, 'First Aid', 'Generic', 'assets/images/antiseptic.jpg');

-- Sample Orders
INSERT INTO orders (user_id, total_amount, status, shipping_address) VALUES
(1, 65.00, 'completed', '123 Main St, City'),
(1, 50.00, 'pending', '123 Main St, City'),
(2, 75.00, 'processing', '456 Oak Ave, City');

-- Sample Order Items
INSERT INTO order_items (order_id, product_id, quantity, price) VALUES
(1, 1, 2, 10.00),
(1, 2, 1, 15.00),
(1, 3, 1, 20.00),
(2, 4, 2, 25.00),
(3, 5, 3, 30.00);
