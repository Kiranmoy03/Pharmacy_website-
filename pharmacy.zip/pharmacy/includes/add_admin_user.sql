-- Add admin user with username and password
-- Password: admin123 (hashed)
INSERT INTO users (username, password, full_name, email, phone, role) 
VALUES (
    'admin', 
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 
    'Admin User', 
    'admin@pharmacy.com', 
    '0000000000', 
    'admin'
);

-- If the username column doesn't exist, you'll need to add it first:
-- ALTER TABLE users ADD COLUMN username VARCHAR(50) UNIQUE AFTER user_id;
