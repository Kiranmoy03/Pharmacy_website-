<?php
session_start();
require_once '../config/database.php';
require_once 'functions.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php?redirect=payment.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $payment_method = $_POST['payment_method'];
    $total_amount = $_POST['total_amount'];
    
    // Get cart items
    $sql = "SELECT c.*, p.name, p.price 
            FROM cart c 
            JOIN products p ON c.product_id = p.product_id 
            WHERE c.user_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $cart_items = mysqli_fetch_all($result, MYSQLI_ASSOC);

    if (empty($cart_items)) {
        header("Location: ../cart.php?error=empty_cart");
        exit();
    }

    // Create order
    $sql = "INSERT INTO orders (user_id, total_amount, status, payment_method) 
            VALUES (?, ?, 'pending', ?)";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ids", $user_id, $total_amount, $payment_method);
    
    if (mysqli_stmt_execute($stmt)) {
        $order_id = mysqli_insert_id($conn);
        
        // Add order items
        foreach ($cart_items as $item) {
            $sql = "INSERT INTO order_items (order_id, product_id, quantity, price) 
                    VALUES (?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $sql);
            $price = $item['price'];
            mysqli_stmt_bind_param($stmt, "iiid", $order_id, $item['product_id'], $item['quantity'], $price);
            mysqli_stmt_execute($stmt);
        }
        
        // Clear cart
        $sql = "DELETE FROM cart WHERE user_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "i", $user_id);
        mysqli_stmt_execute($stmt);
        
        // Update order status based on payment method
        if ($payment_method == 'cod') {
            $sql = "UPDATE orders SET status = 'processing' WHERE order_id = ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "i", $order_id);
            mysqli_stmt_execute($stmt);
        }
        
        header("Location: ../order_confirmation.php?order_id=" . $order_id);
        exit();
    } else {
        header("Location: ../payment.php?error=payment_failed");
        exit();
    }
} else {
    header("Location: ../payment.php");
    exit();
}
?>
