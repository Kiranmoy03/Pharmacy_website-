-- Add payment_method column to orders table if it doesn't exist
ALTER TABLE orders 
ADD COLUMN IF NOT EXISTS payment_method VARCHAR(20) AFTER status;
