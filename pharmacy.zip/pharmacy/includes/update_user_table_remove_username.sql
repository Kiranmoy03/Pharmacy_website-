-- Remove username column and update unique constraint
ALTER TABLE users 
DROP COLUMN username,
DROP INDEX idx_username;

-- Update login functions to use email instead of username
