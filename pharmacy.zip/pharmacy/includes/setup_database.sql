-- Create database if not exists
CREATE DATABASE IF NOT EXISTS pharmacy_db;
USE pharmacy_db;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Products Table
CREATE TABLE IF NOT EXISTS products (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    category VARCHAR(50) NOT NULL,
    image_url VARCHAR(255),
    stock INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Orders Table
CREATE TABLE IF NOT EXISTS orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    total_amount DECIMAL(10,2) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    payment_method VARCHAR(20),
    shipping_address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Order Items Table
CREATE TABLE IF NOT EXISTS order_items (
    order_item_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT,
    product_id INT,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- Cart Table
CREATE TABLE IF NOT EXISTS cart (
    cart_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    product_id INT,
    quantity INT NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- Contact Messages Table
CREATE TABLE IF NOT EXISTS contact_messages (
    message_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    subject VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample data
INSERT INTO users (username, password, full_name, email, phone, address)
VALUES 
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Admin User', 'admin@example.com', '1234567890', '123 Admin Street'),
('john_doe', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'John Doe', 'john@example.com', '9876543210', '123 Main St, City'),
('jane_smith', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Jane Smith', 'jane@example.com', '9876543211', '456 Oak Ave, City');

INSERT INTO products (name, description, price, category, image_url, stock)
VALUES 
('Paracetamol 500mg', 'Pain relief and fever reducer', 10.00, 'Pain Relief', 'assets/images/products/paracetamol.svg', 100),
('Ibuprofen 400mg', 'Anti-inflammatory pain relief', 15.00, 'Pain Relief', 'assets/images/products/ibuprofen.svg', 80),
('Cough Syrup', 'For dry and wet cough', 25.00, 'Cough & Cold', 'assets/images/products/cough-syrup.svg', 50),
('Vitamin C 500mg', 'Immune support', 20.00, 'Vitamins', 'assets/images/products/vitamin-c.svg', 75),
('Antacid Syrup', 'For heartburn and indigestion', 20.00, 'Digestive', 'assets/images/products/antacid.svg', 200),
('Antibiotic Tablet', 'Broad spectrum antibiotic', 30.00, 'Antibiotics', 'assets/images/products/antibiotic.svg', 120),
('Multivitamin', 'Daily multivitamin supplement', 40.00, 'Supplements', 'assets/images/products/multivitamin.svg', 250),
('Eye Drops', 'For dry and irritated eyes', 22.00, 'Eye Care', 'assets/images/products/eye_drops.svg', 150),
('Antiseptic Liquid', 'For wound cleaning', 18.00, 'First Aid', 'assets/images/products/antiseptic.svg', 200);
('Antacid Syrup', 'For heartburn and indigestion', 20.00, 200, 'Digestive', 'Generic', 'assets/images/products/antacid.svg'),
('Cough Syrup', 'For dry and productive cough', 25.00, 180, 'Respiratory', 'Generic', 'assets/images/products/cough_syrup.svg'),
('Antibiotic Tablet', 'Broad spectrum antibiotic', 30.00, 120, 'Antibiotics', 'Generic', 'assets/images/products/antibiotic.svg'),
('Multivitamin', 'Daily multivitamin supplement', 40.00, 250, 'Supplements', 'Generic', 'assets/images/products/multivitamin.svg'),
('Eye Drops', 'For dry and irritated eyes', 22.00, 150, 'Eye Care', 'Generic', 'assets/images/products/eye_drops.svg'),
('Antiseptic Liquid', 'For wound cleaning', 18.00, 200, 'First Aid', 'Generic', 'assets/images/products/antiseptic.svg');

-- Sample Orders
INSERT INTO orders (user_id, total_amount, status, shipping_address) VALUES
(1, 65.00, 'completed', '123 Main St, City'),
(1, 50.00, 'pending', '123 Main St, City'),
(2, 75.00, 'processing', '456 Oak Ave, City');

-- Sample Order Items
INSERT INTO order_items (order_id, product_id, quantity, price) VALUES
(1, 1, 2, 10.00),
(1, 2, 1, 15.00),
(1, 3, 1, 20.00),
(2, 4, 2, 25.00),
(3, 5, 3, 30.00);
