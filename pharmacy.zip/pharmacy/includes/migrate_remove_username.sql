-- Remove username column from users table
ALTER TABLE users DROP COLUMN username;

-- Update any foreign key constraints or indexes that might reference username
-- Note: This assumes there are no foreign key constraints referencing username
-- If there are, you'll need to drop and recreate those constraints
