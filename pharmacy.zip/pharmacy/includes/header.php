<?php
require_once 'config/database.php';
require_once 'includes/functions.php';

if (!isset($_SESSION['user_id'])) {
    $user_menu = '<li class="nav-item">
                    <a class="nav-link d-flex align-items-center px-3 py-2 rounded-3 mx-1 hover-bg-light" href="login.php">
                        <i class="fas fa-sign-in-alt me-2"></i> Sign In
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link d-flex align-items-center px-3 py-2 rounded-3 mx-1 bg-primary text-white hover-bg-primary" href="register.php">
                        <i class="fas fa-user-plus me-2"></i> Register
                    </a>
                </li>';
} else {
    $user_menu = '<li class="nav-item d-flex align-items-center">
                    <a class="nav-link d-flex align-items-center px-3 py-2 rounded-3 me-2 hover-bg-light" href="profile.php">
                        <i class="fas fa-user-circle me-2"></i> My Account
                    </a>
                </li>
                <li class="nav-item d-flex align-items-center me-2">
                    <a class="nav-link position-relative p-0" href="cart.php" title="Cart">
                        <div class="position-relative">
                            <i class="fas fa-shopping-cart fs-5 p-2 rounded-circle hover-bg-light"></i>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-primary">
                                <?php echo getCartItemCount(); ?>
                            </span>
                        </div>
                    </a>
                </li>
                <li class="nav-item d-flex align-items-center">
                    <a class="nav-link d-flex align-items-center px-3 py-2 rounded-3 hover-bg-light text-danger" href="logout.php">
                        <i class="fas fa-sign-out-alt me-2"></i> Sign Out
                    </a>
                </li>';
}
?>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="index.php" style="color: #1c7430 !important; font-weight: 700; font-size: 1.5rem; text-decoration: none;">
            <span class="me-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" viewBox="0 0 16 16" style="color: #1c7430;">
                    <path d="M1.828 8.9 8.9 1.827a4 4 0 1 1 5.657 5.657l-7.07 7.071A4 4 0 1 1 1.827 8.9Zm9.128.771.414-.414a2 2 0 1 0-2.828-2.828l-.414.415 2.828 2.827Z"/>
                </svg>
            </span>
            PharmaMed
        </a>
        <style>
            .hover-bg-light {
                transition: all 0.2s ease;
            }
            .hover-bg-light:hover {
                background-color: rgba(0, 0, 0, 0.05);
            }
            .hover-bg-primary:hover {
                background-color: #3451b5 !important;
            }
            .navbar-nav .nav-link {
                font-size: 0.95rem;
                font-weight: 500;
            }
            .gradient-text {
                background: linear-gradient(90deg, #1c7430, #28a745);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                font-weight: 700;
            }
            .brand-suffix {
                color: #1c7430 !important;
                font-weight: 700;
                position: relative;
            }
            .brand-suffix::after {
                content: '';
                position: absolute;
                width: 100%;
                height: 2px;
                bottom: -2px;
                left: 0;
                background: linear-gradient(90deg, #1c7430, #28a745);
                transform: scaleX(0);
                transform-origin: right;
                transition: transform 0.3s ease;
            }
            .navbar-brand:hover .brand-suffix::after {
                transform: scaleX(1);
                transform-origin: left;
            }
            .navbar-brand {
                font-size: 1.5rem;
                letter-spacing: 0.5px;
            }
            .navbar-nav .btn-cart {
                position: relative;
                padding: 0.5rem;
            }
            .cart-badge {
                position: absolute;
                top: -5px;
                right: -5px;
                font-size: 0.65rem;
                min-width: 18px;
                height: 18px;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 0 4px;
            }
        </style>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link" href="products.php">Products</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="categories.php">Categories</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about.php">About</a>
                </li>
            </ul>
            <ul class="navbar-nav">
                <?php echo $user_menu; ?>
            </ul>
        </div>
    </div>
</nav>
