<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php?redirect=cart.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cart_id = $_POST['cart_id'];
    
    $sql = "DELETE FROM cart WHERE cart_id = ? AND user_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ii", $cart_id, $_SESSION['user_id']);
    
    if (mysqli_stmt_execute($stmt)) {
        header("Location: ../cart.php");
        exit();
    } else {
        echo "Error removing from cart";
    }
} else {
    header("Location: ../cart.php");
    exit();
}
?>
