<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database connection
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/settings_functions.php';

// Check if maintenance mode is enabled
$maintenance_mode = getSetting($conn, 'maintenance_mode', '0');

// Get the current page
$current_page = basename($_SERVER['PHP_SELF']);

// Pages that should be accessible during maintenance
$allowed_pages = [
    'login.php',
    'logout.php',
    'maintenance.php',
    'forgot-password.php',
    'reset-password.php'
];

// Check if maintenance mode is on and current page is not in allowed pages
if ($maintenance_mode === '1' && !in_array($current_page, $allowed_pages)) {
    // Check if user is admin
    $is_admin = isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
    
    // If not admin, redirect to maintenance page
    if (!$is_admin) {
        header('Location: /pharmacy/maintenance.php');
        exit();
    }
}
?>
