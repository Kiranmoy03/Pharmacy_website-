<!-- Footer -->
<footer class="footer" style="background: linear-gradient(135deg, #1c7430, #28a745); color: white; padding: 40px 0 20px; margin-top: 60px; position: relative; overflow: hidden;">
    <div class="container">
        <div class="row g-4">
            <!-- About Column -->
            <div class="col-md-4">
                <h4 class="mb-3" style="color: #fff; position: relative; font-weight: 600;">About PharmaMed</h4>
                <p style="color: rgba(255,255,255,0.9); margin-bottom: 20px; line-height: 1.6;">We are committed to providing quality healthcare products and services to our customers with care and professionalism.</p>
                <div class="social-links" style="margin-top: 25px;">
                    <a href="#" style="color: #fff; margin-right: 15px; font-size: 1.2rem; transition: all 0.3s ease; display: inline-block; width: 36px; height: 36px; line-height: 36px; text-align: center; background: rgba(255,255,255,0.1); border-radius: 50%;"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" style="color: #fff; margin-right: 15px; font-size: 1.2rem; transition: all 0.3s ease; display: inline-block; width: 36px; height: 36px; line-height: 36px; text-align: center; background: rgba(255,255,255,0.1); border-radius: 50%;"><i class="fab fa-twitter"></i></a>
                    <a href="#" style="color: #fff; margin-right: 15px; font-size: 1.2rem; transition: all 0.3s ease; display: inline-block; width: 36px; height: 36px; line-height: 36px; text-align: center; background: rgba(255,255,255,0.1); border-radius: 50%;"><i class="fab fa-instagram"></i></a>
                    <a href="#" style="color: #fff; font-size: 1.2rem; transition: all 0.3s ease; display: inline-block; width: 36px; height: 36px; line-height: 36px; text-align: center; background: rgba(255,255,255,0.1); border-radius: 50%;"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
            
            <!-- Quick Links Column -->
            <div class="col-md-4">
                <h4 class="mb-3" style="color: #fff; position: relative; font-weight: 600;">Quick Links</h4>
                <ul style="list-style: none; padding: 0; margin: 0;">
                    <li style="margin-bottom: 12px; position: relative;"><a href="about.php" style="color: rgba(255,255,255,0.9); text-decoration: none; transition: all 0.3s ease; display: block; padding: 2px 0 2px 15px; position: relative; z-index: 1;">
                        <i class="fas fa-chevron-right me-2" style="color: rgba(255,255,255,0.7); font-size: 0.7rem; position: absolute; left: 0; top: 6px;"></i>About Us
                    </a></li>
                    <li style="margin-bottom: 12px; position: relative;"><a href="privacy.php" style="color: rgba(255,255,255,0.9); text-decoration: none; transition: all 0.3s ease; display: block; padding: 2px 0 2px 15px; position: relative; z-index: 1;">
                        <i class="fas fa-chevron-right me-2" style="color: rgba(255,255,255,0.7); font-size: 0.7rem; position: absolute; left: 0; top: 6px;"></i>Privacy Policy
                    </a></li>
                    <li style="margin-bottom: 12px; position: relative;"><a href="terms.php" style="color: rgba(255,255,255,0.9); text-decoration: none; transition: all 0.3s ease; display: block; padding: 2px 0 2px 15px; position: relative; z-index: 1;">
                        <i class="fas fa-chevron-right me-2" style="color: rgba(255,255,255,0.7); font-size: 0.7rem; position: absolute; left: 0; top: 6px;"></i>Terms of Service
                    </a></li>
                    <li style="position: relative;"><a href="contact.php" style="color: rgba(255,255,255,0.9); text-decoration: none; transition: all 0.3s ease; display: block; padding: 2px 0 2px 15px; position: relative; z-index: 1;">
                        <i class="fas fa-chevron-right me-2" style="color: rgba(255,255,255,0.7); font-size: 0.7rem; position: absolute; left: 0; top: 6px;"></i>Contact Us
                    </a></li>
                </ul>
            </div>
            
            <!-- Contact Column -->
            <div class="col-md-4">
                <h4 class="mb-3" style="color: #fff; position: relative; font-weight: 600;">Contact Us</h4>
                <ul style="list-style: none; padding: 0; margin: 0; color: rgba(255,255,255,0.9);">
                    <li style="margin-bottom: 15px; padding-left: 5px;"><i class="fas fa-envelope me-2" style="color: rgba(255,255,255,0.7);"></i>Email: hkiranmoy@gmail.com</li>
                    <li style="margin-bottom: 15px; padding-left: 5px;"><i class="fas fa-phone me-2" style="color: rgba(255,255,255,0.7);"></i>Phone: +91 7086551649</li>
                    <li style="padding-left: 5px;"><i class="fas fa-map-marker-alt me-2" style="color: rgba(255,255,255,0.7);"></i>Address: Debepara Chariali, Nakachari, Assam</li>
                </ul>
            </div>
        </div>
        
        <!-- Copyright -->
        <div class="row mt-5 pt-3" style="border-top: 1px solid rgba(255,255,255,0.1);">
            <div class="col-12 text-center">
                <p class="mb-0" style="color: rgba(255,255,255,0.7); font-size: 0.9rem;">&copy; <?php echo date('Y'); ?> PharmaMed. All rights reserved.</p>
            </div>
        </div>
    </div>
</footer>

<!-- Ensure jQuery and Bootstrap JS are loaded -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- Simple touch optimization -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        if ('ontouchstart' in window) {
            document.querySelectorAll('footer a').forEach(link => {
                link.style.touchAction = 'manipulation';
                link.style.position = 'relative';
                link.style.zIndex = '10';
            });
        }
    });
</script>

<style>
    footer .col-md-4:nth-child(2) a {
        display: block;
        padding-left: 15px;
        -webkit-tap-highlight-color: rgba(0,0,0,0.1);
        transition: all 0.3s ease;
        position: relative;
    }
    
    footer a:active {
        opacity: 0.8;
        transform: translateY(1px);
    }
    
    @media (hover: hover) {
        footer a:hover {
            opacity: 0.9;
        }
    }
    
    /* Footer Link Hover Effects */
    footer .col-md-4:nth-child(2) a {
        transition: all 0.3s ease !important;
    }
    
    /* Quick Links Hover Effect */
    footer .col-md-4:nth-child(2) a:hover {
        color: #fff !important;
        padding-left: 20px;
    }
    
    footer .col-md-4:nth-child(2) a:hover {
        color: #fff !important;
        padding-left: 8px;
    }
    
    /* Social Icons Hover Effect */
    .social-links a {
        transition: all 0.3s ease !important;
    }
    
    .social-links a:hover {
        background: rgba(255,255,255,0.2) !important;
        transform: translateY(-3px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    
    /* Contact Icons Animation */
    footer .col-md-4:last-child i {
        transition: all 0.3s ease;
    }
    
    footer .col-md-4:last-child li:hover i {
        transform: scale(1.2);
        color: #fff !important;
    }
    
    /* Quick Links Chevron Animation */
    footer .col-md-4:nth-child(2) li {
        transition: all 0.3s ease;
    }
    
    footer .col-md-4:nth-child(2) li:hover {
        transform: translateX(5px);
    }
    
    footer .col-md-4:nth-child(2) li:hover i {
        color: #fff !important;
    }
</style>
