<!-- Footer -->
<footer class="footer" style="background: linear-gradient(135deg, #1c7430, #28a745); color: white; padding: 40px 0 20px; margin-top: 60px; position: relative; overflow: hidden;">
    <div class="footer-overlay" style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.03); pointer-events: none;"></div>
    <div class="container">
        <div class="row g-4">
            <!-- About Column -->
            <div class="col-md-4">
                <h4 class="mb-3" style="color: #fff; position: relative; font-weight: 600;">About PharmaMed</h4>
                <p style="color: rgba(255,255,255,0.9); margin-bottom: 20px; line-height: 1.6;">We are committed to providing quality healthcare products and services to our customers with care and professionalism.</p>
                <div class="social-links" style="margin-top: 25px;">
                    <a href="#" style="color: #fff; margin-right: 15px; font-size: 1.2rem; transition: all 0.3s ease; display: inline-block; width: 36px; height: 36px; line-height: 36px; text-align: center; background: rgba(255,255,255,0.1); border-radius: 50%;"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" style="color: #fff; margin-right: 15px; font-size: 1.2rem; transition: all 0.3s ease; display: inline-block; width: 36px; height: 36px; line-height: 36px; text-align: center; background: rgba(255,255,255,0.1); border-radius: 50%;"><i class="fab fa-twitter"></i></a>
                    <a href="#" style="color: #fff; margin-right: 15px; font-size: 1.2rem; transition: all 0.3s ease; display: inline-block; width: 36px; height: 36px; line-height: 36px; text-align: center; background: rgba(255,255,255,0.1); border-radius: 50%;"><i class="fab fa-instagram"></i></a>
                    <a href="#" style="color: #fff; font-size: 1.2rem; transition: all 0.3s ease; display: inline-block; width: 36px; height: 36px; line-height: 36px; text-align: center; background: rgba(255,255,255,0.1); border-radius: 50%;"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
            
            <!-- Quick Links Column -->
            <div class="col-md-4">
                <h4 class="mb-3" style="color: #fff; position: relative; font-weight: 600;">Quick Links</h4>
                <ul style="list-style: none; padding: 0; margin: 0;">
                    <li style="margin-bottom: 12px; position: relative; padding-left: 15px;"><i class="fas fa-chevron-right me-2" style="color: rgba(255,255,255,0.7); font-size: 0.7rem; position: absolute; left: 0; top: 6px;"></i><a href="about.php" style="color: rgba(255,255,255,0.9); text-decoration: none; transition: all 0.3s ease; display: inline-block; padding: 2px 0; border-bottom: 1px solid transparent;">About Us</a></li>
                    <li style="margin-bottom: 12px; position: relative; padding-left: 15px;"><i class="fas fa-chevron-right me-2" style="color: rgba(255,255,255,0.7); font-size: 0.7rem; position: absolute; left: 0; top: 6px;"></i><a href="privacy.php" style="color: rgba(255,255,255,0.9); text-decoration: none; transition: all 0.3s ease; display: inline-block; padding: 2px 0; border-bottom: 1px solid transparent;">Privacy Policy</a></li>
                    <li style="margin-bottom: 12px; position: relative; padding-left: 15px;"><i class="fas fa-chevron-right me-2" style="color: rgba(255,255,255,0.7); font-size: 0.7rem; position: absolute; left: 0; top: 6px;"></i><a href="terms.php" style="color: rgba(255,255,255,0.9); text-decoration: none; transition: all 0.3s ease; display: inline-block; padding: 2px 0; border-bottom: 1px solid transparent;">Terms of Service</a></li>
                    <li style="position: relative; padding-left: 15px;"><i class="fas fa-chevron-right me-2" style="color: rgba(255,255,255,0.7); font-size: 0.7rem; position: absolute; left: 0; top: 6px;"></i><a href="contact.php" style="color: rgba(255,255,255,0.9); text-decoration: none; transition: all 0.3s ease; display: inline-block; padding: 2px 0; border-bottom: 1px solid transparent;">Contact Us</a></li>
                </ul>
            </div>
            
            <!-- Contact Column -->
            <div class="col-md-4">
                <h4 class="mb-3" style="color: #fff; position: relative; font-weight: 600;">Contact Us</h4>
                <ul style="list-style: none; padding: 0; margin: 0; color: rgba(255,255,255,0.9);">
                    <li style="margin-bottom: 15px; padding-left: 5px;"><i class="fas fa-envelope me-2" style="color: rgba(255,255,255,0.7);"></i>Email: hkiranmoy@gmail.com</li>
                    <li style="margin-bottom: 15px; padding-left: 5px;"><i class="fas fa-phone me-2" style="color: rgba(255,255,255,0.7);"></i>Phone: +91 7086551649</li>
                    <li style="padding-left: 5px;"><i class="fas fa-map-marker-alt me-2" style="color: rgba(255,255,255,0.7);"></i>Address: 123 Pharmacy Street, Jorhat, Assam, 785001</li>
                </ul>
            </div>
        </div>
        
        <!-- Copyright -->
        <div class="row mt-5 pt-3" style="border-top: 1px solid rgba(255,255,255,0.1);">
            <div class="col-12 text-center">
                <p class="mb-0" style="color: rgba(255,255,255,0.7); font-size: 0.9rem;">&copy; <?php echo date('Y'); ?> PharmaMed. All rights reserved.</p>
            </div>
        </div>
    </div>
</footer>

<!-- Ensure jQuery and Bootstrap JS are loaded -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- Fix for any potential overlay issues -->
<script>
    // Chrome-specific fixes
    if (navigator.userAgent.indexOf('Chrome') > -1) {
        // Fix for Chrome's touch events
        document.addEventListener('DOMContentLoaded', function() {
            // Force hardware acceleration
            document.body.style.transform = 'translateZ(0)';
            
            // Make footer links clickable
            const footerLinks = document.querySelectorAll('footer a');
            footerLinks.forEach(link => {
                link.style.pointerEvents = 'auto';
                link.style.position = 'relative';
                link.style.zIndex = '9999';
                
                // Add click event to ensure links work
                link.addEventListener('click', function(e) {
                    e.stopPropagation();
                    window.location.href = this.href;
                });
            });
            
            // Remove any potential overlays
            const overlays = document.querySelectorAll('.modal-backdrop, .fade, .show');
            overlays.forEach(el => el.remove());
            
            // Force repaint
            document.body.offsetHeight;
        });
    }
</script>

<!-- Add a meta tag to disable Chrome's touch highlighting -->
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<style>
    /* Chrome-specific fix for clickable elements */
    @media (-webkit-min-device-pixel-ratio:0) {
        footer a {
            -webkit-tap-highlight-color: transparent;
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    }
    
    /* Footer Link Hover Effects */
    footer a {
        position: relative;
        transition: all 0.3s ease !important;
    }
    
    /* Quick Links Hover Effect */
    footer .col-md-4:nth-child(2) a {
        display: inline-block;
        padding: 2px 0;
        transition: all 0.3s ease;
    }
    
    footer .col-md-4:nth-child(2) a:hover {
        color: #fff !important;
        padding-left: 8px;
    }
    
    /* Social Icons Hover Effect */
    .social-links a {
        transition: all 0.3s ease !important;
    }
    
    .social-links a:hover {
        background: rgba(255,255,255,0.2) !important;
        transform: translateY(-3px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    
    /* Contact Icons Animation */
    footer .col-md-4:last-child i {
        transition: all 0.3s ease;
    }
    
    footer .col-md-4:last-child li:hover i {
        transform: scale(1.2);
        color: #fff !important;
    }
    
    /* Quick Links Chevron Animation */
    footer .col-md-4:nth-child(2) li {
        transition: all 0.3s ease;
    }
    
    footer .col-md-4:nth-child(2) li:hover {
        transform: translateX(5px);
    }
    
    footer .col-md-4:nth-child(2) li:hover i {
        color: #fff !important;
    }
</style>
