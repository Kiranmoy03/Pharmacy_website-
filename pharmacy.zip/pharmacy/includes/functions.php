<?php
require_once __DIR__ . '/../config/database.php';

// Function to get cart item count
function getCartItemCount() {
    global $conn;
    if (isset($_SESSION['user_id'])) {
        $sql = "SELECT COUNT(*) as count FROM cart WHERE user_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "i", $_SESSION['user_id']);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $row = mysqli_fetch_assoc($result);
        return $row['count'];
    }
    return 0;
}

// Function to add product to cart
function addToCart($product_id) {
    global $conn;
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        $sql = "INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, 1)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ii", $user_id, $product_id);
        return mysqli_stmt_execute($stmt);
    }
    return false;
}

// Function to get all products
function getProducts($limit = null) {
    global $conn;
    $sql = "SELECT * FROM products";
    if ($limit) {
        $sql .= " LIMIT $limit";
    }
    $result = mysqli_query($conn, $sql);
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

// Function to get product by ID
function getProductById($product_id) {
    global $conn;
    $sql = "SELECT * FROM products WHERE product_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $product_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    return mysqli_fetch_assoc($result);
}

// Function to create order
function createOrder($user_id, $cart_items) {
    global $conn;
    
    // Start transaction
    mysqli_begin_transaction($conn);
    
    try {
        // Create order
        $payment_method = isset($_POST['payment_method']) ? $_POST['payment_method'] : 'cash_on_delivery';
        $status = $payment_method == 'cash_on_delivery' ? 'processing' : 'pending';
        
        $sql = "INSERT INTO orders (user_id, total_amount, status, payment_method) VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        $total_amount = calculateTotalAmount($cart_items);
        mysqli_stmt_bind_param($stmt, "idss", $user_id, $total_amount, $status, $payment_method);
        mysqli_stmt_execute($stmt);
        $order_id = mysqli_insert_id($conn);
        
        // Add order items
        foreach ($cart_items as $item) {
            $sql = "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $sql);
            $price = $item['price'];
            mysqli_stmt_bind_param($stmt, "iidi", $order_id, $item['product_id'], $item['quantity'], $price);
            mysqli_stmt_execute($stmt);
        }
        
        // Clear cart
        $sql = "DELETE FROM cart WHERE user_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "i", $user_id);
        mysqli_stmt_execute($stmt);
        
        mysqli_commit($conn);
        return true;
    } catch (Exception $e) {
        mysqli_rollback($conn);
        return false;
    }
}

// Function to calculate total amount
function calculateTotalAmount($cart_items) {
    $total = 0;
    foreach ($cart_items as $item) {
        $total += $item['price'] * $item['quantity'];
    }
    return $total;
}

// Function to get user orders
function getUserOrders($user_id) {
    global $conn;
    $sql = "SELECT o.*, oi.product_id, oi.quantity, oi.price 
            FROM orders o 
            JOIN order_items oi ON o.order_id = oi.order_id 
            WHERE o.user_id = ? 
            ORDER BY o.created_at DESC";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

// Function to get user profile
function getUserProfile($user_id) {
    global $conn;
    $sql = "SELECT * FROM users WHERE user_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    return mysqli_fetch_assoc($result);
}

// Function to cancel order
function cancelOrder($order_id) {
    global $conn;
    
    // Get order details
    $sql = "SELECT * FROM orders WHERE order_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $order_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $order = mysqli_fetch_assoc($result);
    
    if (!$order) {
        return false;
    }
    
    // Update order status to cancelled
    $sql = "UPDATE orders SET status = 'cancelled' WHERE order_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $order_id);
    return mysqli_stmt_execute($stmt);
}

// Function to return order
function returnOrder($order_id) {
    global $conn;
    
    // Get order details
    $sql = "SELECT * FROM orders WHERE order_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $order_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $order = mysqli_fetch_assoc($result);
    
    if (!$order) {
        return false;
    }
    
    // Check if order is completed
    if ($order['status'] != 'completed') {
        return false;
    }
    
    // Check if return period is valid (7 days from delivery)
    $delivery_date = strtotime($order['created_at']);
    $current_date = time();
    $days_since_delivery = floor(($current_date - $delivery_date) / (60 * 60 * 24));
    
    if ($days_since_delivery > 7) {
        return false;
    }
    
    // Update order status to returned
    $sql = "UPDATE orders SET status = 'returned' WHERE order_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $order_id);
    return mysqli_stmt_execute($stmt);
}

// Function to update user profile
function updateUserProfile($user_id, $data) {
    global $conn;
    $sql = "UPDATE users SET ";
    $fields = [];
    $params = [];
    
    foreach ($data as $key => $value) {
        $fields[] = "$key = ?";
        $params[] = $value;
    }
    
    $sql .= implode(', ', $fields) . " WHERE user_id = ?";
    $params[] = $user_id;
    
    $stmt = mysqli_prepare($conn, $sql);
    $types = str_repeat('s', count($params));
    mysqli_stmt_bind_param($stmt, $types, ...$params);
    return mysqli_stmt_execute($stmt);
}
?>
