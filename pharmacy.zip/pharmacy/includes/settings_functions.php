<?php
/**
 * Get a setting value from the database
 * 
 * @param mysqli $conn Database connection
 * @param string $key Setting key
 * @param mixed $default Default value if setting not found
 * @return mixed Setting value or default value
 */
function getSetting($conn, $key, $default = '') {
    // First check if settings table exists
    $table_check = mysqli_query($conn, "SHOW TABLES LIKE 'settings'");
    
    if (mysqli_num_rows($table_check) === 0) {
        // Table doesn't exist, return default value
        return $default;
    }
    
    // Table exists, try to get the setting
    $sql = "SELECT setting_value FROM settings WHERE setting_key = ?";
    $stmt = mysqli_prepare($conn, $sql);
    
    if ($stmt === false) {
        return $default;
    }
    
    mysqli_stmt_bind_param($stmt, "s", $key);
    
    if (!mysqli_stmt_execute($stmt)) {
        return $default;
    }
    
    $result = mysqli_stmt_get_result($stmt);
    
    if ($row = mysqli_fetch_assoc($result)) {
        return $row['setting_value'];
    }
    
    return $default;
}

/**
 * Update or insert a setting
 * 
 * @param mysqli $conn Database connection
 * @param string $key Setting key
 * @param string $value Setting value
 * @return bool True on success, false on failure
 */
function updateSetting($conn, $key, $value) {
    // First check if settings table exists
    $table_check = mysqli_query($conn, "SHOW TABLES LIKE 'settings'");
    
    if (mysqli_num_rows($table_check) === 0) {
        // Table doesn't exist, try to create it
        $create_table = "CREATE TABLE IF NOT EXISTS settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            setting_key VARCHAR(50) NOT NULL UNIQUE,
            setting_value TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
        
        if (!mysqli_query($conn, $create_table)) {
            return false;
        }
    }
    
    $sql = "INSERT INTO settings (setting_key, setting_value) 
            VALUES (?, ?) 
            ON DUPLICATE KEY UPDATE setting_value = ?";
    
    $stmt = mysqli_prepare($conn, $sql);
    
    if ($stmt === false) {
        return false;
    }
    
    mysqli_stmt_bind_param($stmt, "sss", $key, $value, $value);
    return mysqli_stmt_execute($stmt);
}
?>
