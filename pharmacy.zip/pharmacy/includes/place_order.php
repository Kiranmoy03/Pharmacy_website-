<?php
session_start();
require_once '../config/database.php';
require_once 'functions.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php?redirect=cart.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    
    // Get cart items
    $sql = "SELECT c.*, p.name, p.price 
            FROM cart c 
            JOIN products p ON c.product_id = p.product_id 
            WHERE c.user_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $cart_items = mysqli_fetch_all($result, MYSQLI_ASSOC);
    
    if (empty($cart_items)) {
        header("Location: ../cart.php?error=empty_cart");
        exit();
    }
    
    // Create order
    // Instead of creating order directly, redirect to payment page
    header("Location: ../payment.php");
    exit();
} else {
    header("Location: ../cart.php");
    exit();
}
?>
