<?php
$file = file_get_contents('index.php');
$file = str_replace('href="product.php?id=', 'href="product-details.php?id=', $file);
file_put_contents('index.php', $file);
echo 'All product links have been updated to point to product-details.php';
?>
