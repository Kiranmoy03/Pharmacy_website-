<?php
require_once 'config/database.php';
require_once 'config/razorpay_config.php';
session_start();

header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Please log in to continue']);
    exit();
}

// Include Razorpay PHP SDK
require 'vendor/autoload.php';
use Razorpay\Api\Api;

// Get POST data
$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$address = trim($_POST['address'] ?? '');
$pincode = trim($_POST['pincode'] ?? '');

// Basic validation
$errors = [];
if (empty($name)) $errors[] = 'Name is required';
if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required';
if (empty($phone) || !preg_match('/^[0-9]{10}$/', $phone)) $errors[] = 'Valid 10-digit phone number is required';
if (empty($address)) $errors[] = 'Address is required';
if (empty($pincode) || !preg_match('/^[0-9]{6}$/', $pincode)) $errors[] = 'Valid 6-digit pincode is required';

if (!empty($errors)) {
    echo json_encode(['status' => 'error', 'message' => implode('\n', $errors)]);
    exit();
}

try {
    // Start transaction
    mysqli_begin_transaction($conn);
    
    // Get cart items and calculate total
    $sql = "SELECT c.*, p.price, p.stock_quantity 
            FROM cart c 
            JOIN products p ON c.product_id = p.product_id 
            WHERE c.user_id = ? FOR UPDATE";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $_SESSION['user_id']);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $cart_items = mysqli_fetch_all($result, MYSQLI_ASSOC);
    
    if (empty($cart_items)) {
        throw new Exception('Your cart is empty');
    }
    
    // Calculate total amount
    $total_amount = 0;
    foreach ($cart_items as $item) {
        $total_amount += $item['price'] * $item['quantity'];
    }
    
    // Create order
    $sql = "INSERT INTO orders (user_id, total_amount, status, payment_method, shipping_address, pincode) 
            VALUES (?, ?, 'pending', 'online', ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    $status = 'pending';
    mysqli_stmt_bind_param($stmt, "idss", $_SESSION['user_id'], $total_amount, $address, $pincode);
    mysqli_stmt_execute($stmt);
    $order_id = mysqli_insert_id($conn);
    
    if (!$order_id) {
        throw new Exception('Failed to create order');
    }
    
    // Add order items and update product stock
    foreach ($cart_items as $item) {
        // Add order item
        $sql = "INSERT INTO order_items (order_id, product_id, quantity, price) 
                VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "iiid", $order_id, $item['product_id'], $item['quantity'], $item['price']);
        mysqli_stmt_execute($stmt);
        
        // Check stock and update
        if ($item['stock_quantity'] < $item['quantity']) {
            throw new Exception('Insufficient stock for some items');
        }
        
        $new_stock = $item['stock_quantity'] - $item['quantity'];
        $sql = "UPDATE products SET stock_quantity = ? WHERE product_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ii", $new_stock, $item['product_id']);
        mysqli_stmt_execute($stmt);
    }
    
    // Create Razorpay order
    $api = new Api($config['key_id'], $config['key_secret']);
    
    $orderData = [
        'receipt'         => 'order_rcpt_' . $order_id,
        'amount'          => $total_amount * 100, // Convert to paise
        'currency'        => 'INR',
        'payment_capture' => 1 // Auto-capture payment
    ];
    
    $razorpayOrder = $api->order->create($orderData);
    $razorpayOrderId = $razorpayOrder['id'];
    
    // Update order with Razorpay order ID
    $sql = "UPDATE orders SET razorpay_order_id = ? WHERE order_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "si", $razorpayOrderId, $order_id);
    mysqli_stmt_execute($stmt);
    
    // Prepare Razorpay checkout data
    $data = [
        'key'               => $config['key_id'],
        'amount'            => $orderData['amount'],
        'name'              => 'PharmaMed',
        'description'       => 'Order #' . $order_id,
        'image'             => 'assets/images/logo.png',
        'prefill'           => [
            'name'    => $name,
            'email'   => $email,
            'contact' => $phone,
        ],
        'theme'             => [
            'color' => '#3399cc'
        ],
        'order_id'          => $razorpayOrderId,
        'handler'           => function($response) {
            // This will be handled by the success callback
            return true;
        },
        'callback_url'      => 'payment_success.php?order_id=' . $order_id,
        'prefill'           => [
            'name'    => $name,
            'email'   => $email,
            'contact' => $phone,
        ],
        'notes'             => [
            'address' => $address,
            'pincode' => $pincode
        ]
    ];
    
    // Commit transaction
    mysqli_commit($conn);
    
    // Return success response with Razorpay data
    echo json_encode([
        'status' => 'success',
        'order_id' => $order_id,
        'razorpay' => [
            'key' => $config['key_id'],
            'amount' => $orderData['amount'],
            'currency' => 'INR',
            'name' => 'PharmaMed',
            'description' => 'Order #' . $order_id,
            'image' => 'assets/images/logo.png',
            'order_id' => $razorpayOrderId,
            'handler' => 'https://checkout.razorpay.com/v1/checkout.html',
            'prefill' => [
                'name' => $name,
                'email' => $email,
                'contact' => $phone
            ],
            'theme' => [
                'color' => '#3399cc'
            ]
        ]
    ]);
    
} catch (Exception $e) {
    // Rollback transaction on error
    mysqli_rollback($conn);
    
    error_log('Order creation error: ' . $e->getMessage());
    echo json_encode([
        'status' => 'error',
        'message' => 'Failed to create order: ' . $e->getMessage()
    ]);
}
?>
