<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maintenance Mode - Pharmacy</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #f8f9fc;
            --accent-color: #4e73df;
            --text-color: #5a5c69;
            --light-gray: #f8f9fc;
        }
        
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--text-color);
            background-color: var(--light-gray);
        }
        
        .maintenance-wrapper {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
            background: linear-gradient(135deg, #f8f9fc 0%, #e2e8f0 100%);
        }
        
        .maintenance-card {
            max-width: 600px;
            width: 100%;
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            overflow: hidden;
            border: none;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .maintenance-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
        }
        
        .maintenance-header {
            background: var(--primary-color);
            color: white;
            padding: 2rem;
            text-align: center;
        }
        
        .maintenance-icon {
            font-size: 4.5rem;
            margin-bottom: 1.5rem;
            color: white;
            animation: pulse 2s infinite;
        }
        
        .maintenance-body {
            padding: 2.5rem;
            text-align: center;
        }
        
        h1 {
            color: #2c3e50;
            margin-bottom: 1.5rem;
            font-weight: 700;
            font-size: 2.2rem;
        }
        
        .lead {
            font-size: 1.25rem;
            margin-bottom: 1.5rem;
            color: #6c757d;
            line-height: 1.6;
        }
        
        .admin-login {
            margin-top: 2rem;
            padding-top: 1.5rem;
            border-top: 1px solid #eee;
        }
        
        .btn-admin {
            background: var(--primary-color);
            color: white;
            padding: 0.6rem 1.5rem;
            border-radius: 50px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            border: 2px solid var(--primary-color);
        }
        
        .btn-admin:hover {
            background: transparent;
            color: var(--primary-color);
            transform: translateY(-2px);
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
        
        /* Responsive adjustments */
        @media (max-width: 576px) {
            .maintenance-body {
                padding: 1.5rem;
            }
            
            h1 {
                font-size: 1.8rem;
            }
            
            .lead {
                font-size: 1.1rem;
            }
        }
    </style>
</head>
<body>
    <div class="maintenance-wrapper">
        <div class="maintenance-card">
            <div class="maintenance-header">
                <div class="maintenance-icon">
                    <i class="fas fa-tools"></i>
                </div>
                <h1 class="mb-0">Under Maintenance</h1>
            </div>
            <div class="maintenance-body">
                <p class="lead">We're currently performing scheduled maintenance to improve your experience.</p>
                <p>We apologize for any inconvenience. Our team is working hard to get everything back up and running as soon as possible.</p>
                <p class="text-muted mt-4">
                    <i class="far fa-clock me-1"></i> Expected completion: <strong>30 minutes</strong>
                </p>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>
