<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

// Check if product ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: index.php');
    exit();
}

$product_id = (int)$_GET['id'];

// Get product details
$sql = "SELECT * FROM products WHERE product_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'i', $product_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) === 0) {
    header('Location: index.php');
    exit();
}

$product = mysqli_fetch_assoc($result);

// Get related products (products from the same category, excluding current product)
$related_sql = "SELECT * FROM products WHERE category = ? AND product_id != ? LIMIT 4";
$related_stmt = mysqli_prepare($conn, $related_sql);
mysqli_stmt_bind_param($related_stmt, 'si', $product['category'], $product_id);
mysqli_stmt_execute($related_stmt);
$related_products = mysqli_stmt_get_result($related_stmt);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['name']); ?> - PharmaMed</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-green: #1c7430;
            --light-green: #e8f5e9;
            --lighter-green: #f1f8e9;
        }
        body {
            background-color: #f8f9fa;
        }
        .product-details-container {
            background: linear-gradient(145deg, #e8f5e9 0%, #d8edd9 100%);
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.08);
            overflow: hidden;
            border: 1px solid #c0e0c0;
            position: relative;
        }
        .product-details-container:before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: linear-gradient(90deg, var(--primary-green), #34ce57);
        }
        .product-image-container {
            background: linear-gradient(145deg, #f8fef8 0%, #f0faf0 100%);
            padding: 25px;
            border-radius: 10px;
            text-align: center;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
            border: 1px solid #e0f0e0;
        }
        .product-image-container:before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--primary-green), #34ce57);
        }
        .product-image-container img {
            max-height: 400px;
            width: auto;
            object-fit: contain;
            position: relative;
            z-index: 2;
            transition: transform 0.3s ease;
            background: rgba(255, 255, 255, 0.98);
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .product-image-container img:hover {
            transform: scale(1.02);
        }
        .product-info {
            padding: 30px;
            background: linear-gradient(145deg, #e0f0e0 0%, #d0e8d0 100%);
            position: relative;
            z-index: 1;
            border-left: 1px solid #c0d8c0;
        }
        .product-title {
            color: var(--primary-green);
            font-weight: 600;
            margin-bottom: 15px;
        }
        .product-price {
            font-size: 1.75rem;
            color: var(--primary-green);
            font-weight: 700;
            margin: 15px 0;
        }
        .product-description {
            color: #444;
            line-height: 1.7;
            margin: 20px 0;
            background: rgba(255, 255, 255, 0.7);
            padding: 15px;
            border-radius: 8px;
            border-left: 3px solid var(--primary-green);
        }
        .product-category {
            background: var(--light-green);
            color: var(--primary-green);
            display: inline-block;
            padding: 5px 15px;
            border-radius: 50px;
            font-weight: 500;
            margin: 10px 0;
        }
        .btn-add-to-cart {
            background: var(--primary-green);
            border: none;
            padding: 10px 25px;
            font-weight: 500;
            transition: all 0.3s;
        }
        .btn-add-to-cart:hover {
            background: #155724;
            transform: translateY(-2px);
        }
        .quantity-input {
            width: 80px !important;
            text-align: center;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 8px 5px;
        }
        .related-products {
            margin-top: 50px;
            padding: 40px 0;
            border-top: 1px solid #e0f0e0;
            border-bottom: 1px solid #e0f0e0;
        }
        .related-products h3 {
            color: var(--primary-green);
            font-weight: 600;
            margin-bottom: 25px;
            position: relative;
            padding-bottom: 10px;
        }
        .related-products h3:after {
            content: '';
            position: absolute;
            left: 0;
            bottom: 0;
            width: 60px;
            height: 3px;
            background: var(--primary-green);
        }
        .related-product-card {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            transition: all 0.3s;
            box-shadow: 0 5px 15px rgba(0,0,0,0.04);
            height: 100%;
            border: 1px solid #e8f5e9;
        }
        .related-product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        .related-product-img {
            height: 180px;
            padding: 15px;
            background: linear-gradient(145deg, #f8fef8 0%, #f0faf0 100%);
            text-align: center;
        }
        .related-product-img img {
            max-height: 100%;
            width: auto;
            max-width: 100%;
            object-fit: contain;
            background: white;
            padding: 10px;
            border-radius: 4px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        .related-product-info {
            padding: 15px;
            border-top: 1px solid #eee;
        }
        .related-product-title {
            font-size: 1rem;
            font-weight: 600;
            margin-bottom: 5px;
            color: #333;
        }
        .related-product-price {
            color: var(--primary-green);
            font-weight: 700;
            font-size: 1.1rem;
        }
        .stock-badge {
            padding: 5px 10px;
            border-radius: 50px;
            font-size: 0.8rem;
            font-weight: 500;
        }
        .in-stock {
            background: #e8f5e9;
            color: #1c7430;
        }
        .out-of-stock {
            background: #ffebee;
            color: #c62828;
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container my-5">
        <div class="product-details-container">
            <div class="row g-0">
                <div class="col-md-6">
                    <div class="product-image-container">
                        <img src="<?php echo htmlspecialchars($product['image_url']); ?>" 
                             alt="<?php echo htmlspecialchars($product['name']); ?>" 
                             class="img-fluid">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="product-info">
                        <h1 class="product-title"><?php echo htmlspecialchars($product['name']); ?></h1>
                        
                        <div class="d-flex align-items-center mb-3">
                            <span class="product-price">₹<?php echo number_format($product['price'], 2); ?></span>
                            <?php if ($product['stock_quantity'] > 0): ?>
                                <span class="stock-badge in-stock ms-3">In Stock</span>
                            <?php else: ?>
                                <span class="stock-badge out-of-stock ms-3">Out of Stock</span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="product-description">
                            <h5 class="fw-bold mb-3">Product Details</h5>
                            <?php echo nl2br(htmlspecialchars($product['description'])); ?>
                        </div>

                        <div class="mb-4">
                            <span class="product-category">
                                <i class="fas fa-tag me-1"></i> <?php echo htmlspecialchars($product['category']); ?>
                            </span>
                        </div>

                        <?php if ($product['stock_quantity'] > 0): ?>
                        <div class="d-flex align-items-center">
                            <div class="me-3">
                                <label for="quantity" class="form-label fw-500 mb-2 d-block">Quantity</label>
                                <input type="number" id="quantity" name="quantity" value="1" 
                                       min="1" max="<?php echo $product['stock_quantity']; ?>" 
                                       class="form-control quantity-input">
                            </div>
                            <div class="pt-4 mt-2">
                                <button class="btn btn-add-to-cart btn-lg text-white add-to-cart" 
                                        data-product-id="<?php echo $product['product_id']; ?>">
                                    <i class="fas fa-cart-plus me-2"></i> Add to Cart
                                </button>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <?php if (mysqli_num_rows($related_products) > 0): ?>
        <div class="related-products">
            <div class="container">
                <h3>You May Also Like</h3>
                <div class="row g-4">
                    <?php 
                    // Reset the pointer to the beginning of the result set
                    mysqli_data_seek($related_products, 0);
                    while ($related = mysqli_fetch_assoc($related_products)): 
                    ?>
                    <div class="col-6 col-md-4 col-lg-3">
                        <a href="product-details.php?id=<?php echo $related['product_id']; ?>" class="text-decoration-none">
                            <div class="related-product-card h-100">
                                <div class="related-product-img">
                                    <img src="<?php echo htmlspecialchars($related['image_url']); ?>" 
                                         alt="<?php echo htmlspecialchars($related['name']); ?>">
                                </div>
                                <div class="related-product-info">
                                    <div class="related-product-title">
                                        <?php echo htmlspecialchars($related['name']); ?>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center mt-2">
                                        <span class="related-product-price">
                                            ₹<?php echo number_format($related['price'], 2); ?>
                                        </span>
                                        <?php if ($related['stock_quantity'] > 0): ?>
                                            <span class="stock-badge in-stock">In Stock</span>
                                        <?php else: ?>
                                            <span class="stock-badge out-of-stock">Out of Stock</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>
