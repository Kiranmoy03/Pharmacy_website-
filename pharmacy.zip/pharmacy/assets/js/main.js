// Add to Cart functionality
document.addEventListener('DOMContentLoaded', function() {
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.dataset.productId;
            addToCart(productId);
        });
    });

    // Search functionality - handle both form submission and direct button/keypress
    const searchForm = document.getElementById('searchForm');
    const searchInput = document.getElementById('searchInput');
    
    if (searchForm) {
        // Handle form submission
        searchForm.addEventListener('submit', function(e) {
            const searchTerm = searchInput.value.trim();
            if (!searchTerm) {
                e.preventDefault(); // Prevent form submission if search is empty
            }
            // Let the form submit naturally with the search parameter
        });
        
        // Handle enter key in search
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                const searchTerm = searchInput.value.trim();
                if (searchTerm) {
                    searchForm.submit();
                } else {
                    e.preventDefault();
                }
            }
        });
    }
});

function addToCart(productId) {
    fetch('includes/add_to_cart.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `product_id=${productId}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            updateCartCount();
            showNotification('Product added to cart successfully!');
        } else {
            showNotification('Error adding product to cart', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('An error occurred', 'error');
    });
}

function updateCartCount() {
    fetch('includes/get_cart_count.php')
        .then(response => response.json())
        .then(data => {
            // Update session storage for cross-page persistence
            sessionStorage.setItem('cart_count', data.count);
            
            // Update all cart badges on the page
            document.querySelectorAll('.badge.rounded-pill.bg-primary').forEach(badge => {
                badge.textContent = data.count;
                badge.style.display = data.count > 0 ? 'block' : 'none';
            });
        })
        .catch(error => {
            console.error('Error updating cart count:', error);
        });
}

// Initialize cart count on page load
window.addEventListener('load', () => {
    // Check if we have a stored cart count
    const storedCount = sessionStorage.getItem('cart_count');
    if (storedCount !== null) {
        // Update all cart badges with stored count
        document.querySelectorAll('.badge.rounded-pill.bg-primary').forEach(badge => {
            badge.textContent = storedCount;
            badge.style.display = storedCount > 0 ? 'block' : 'none';
        });
    }
    // Also fetch the actual count from server
    updateCartCount();
});

function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show fixed-top w-50 mx-auto mt-3`;
    notification.style.zIndex = '1000';
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// Search functionality
const searchInput = document.getElementById('searchInput');
if (searchInput) {
    searchInput.addEventListener('input', function() {
        const query = this.value.toLowerCase();
        const products = document.querySelectorAll('.product-card');
        
        products.forEach(product => {
            const productName = product.querySelector('h3').textContent.toLowerCase();
            if (productName.includes(query)) {
                product.style.display = 'block';
            } else {
                product.style.display = 'none';
            }
        });
    });
}

// Filter functionality
const filterButtons = document.querySelectorAll('.filter-btn');
if (filterButtons) {
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const category = this.dataset.category;
            const products = document.querySelectorAll('.product-card');
            
            products.forEach(product => {
                const productCategory = product.dataset.category;
                if (category === 'all' || productCategory === category) {
                    product.style.display = 'block';
                } else {
                    product.style.display = 'none';
                }
            });
        });
    });
}

// Payment method selection
document.querySelectorAll('.payment-method').forEach(method => {
    method.addEventListener('click', function() {
        // Remove selected class from all methods
        document.querySelectorAll('.payment-method').forEach(m => m.classList.remove('selected'));
        
        // Add selected class to clicked method
        this.classList.add('selected');
        
        // Hide all payment forms
        document.querySelectorAll('.payment-form').forEach(form => form.classList.remove('active'));
        
        // Show corresponding payment form
        const method = this.dataset.method;
        document.getElementById(`${method}Form`).classList.add('active');

        // If UPI method is selected, initialize UPI verification
        if (method === 'upi') {
            const verifyBtn = document.getElementById('verifyBtn');
            const upiSubmit = document.getElementById('upiSubmit');
            const verificationStatus = document.getElementById('verificationStatus');

            verifyBtn.addEventListener('click', function() {
                const transactionId = document.getElementById('upiVerify').value.trim();
                if (!transactionId) {
                    verificationStatus.innerHTML = '<div class="alert alert-warning">Please enter a transaction ID</div>';
                    return;
                }

                // Simulate UPI verification
                // In a real application, this would be an API call to verify the transaction
                setTimeout(() => {
                    verificationStatus.innerHTML = '<div class="alert alert-success">Transaction verified successfully!</div>';
                    upiSubmit.disabled = false;
                }, 1000);
            });
        }
    });
});
