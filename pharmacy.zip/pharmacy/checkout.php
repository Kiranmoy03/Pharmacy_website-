<?php
require_once 'config/database.php';
require_once 'config/razorpay_config.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?redirect=checkout.php");
    exit();
}

// Include Razorpay PHP SDK
require 'vendor/autoload.php';
use Razorpay\Api\Api;

// Get user's cart items
$sql = "SELECT c.*, p.name, p.price, p.stock_quantity 
        FROM cart c 
        JOIN products p ON c.product_id = p.product_id 
        WHERE c.user_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $_SESSION['user_id']);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$cart_items = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Calculate total amount
$total_amount = 0;
foreach ($cart_items as $item) {
    $total_amount += $item['price'] * $item['quantity'];
}

// Get user details
$sql = "SELECT * FROM users WHERE user_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $_SESSION['user_id']);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate form data
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $pincode = trim($_POST['pincode']);
    $payment_method = $_POST['payment_method'];
    
    // Basic validation
    $errors = [];
    if (empty($name)) $errors[] = 'Name is required';
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required';
    if (empty($phone) || !preg_match('/^[0-9]{10}$/', $phone)) $errors[] = 'Valid 10-digit phone number is required';
    if (empty($address)) $errors[] = 'Address is required';
    if (empty($pincode) || !preg_match('/^[0-9]{6}$/', $pincode)) $errors[] = 'Valid 6-digit pincode is required';
    
    if (empty($errors)) {
        // Process COD order
        if ($payment_method === 'cod') {
            // Create order
            $sql = "INSERT INTO orders (user_id, total_amount, status, payment_method, shipping_address, pincode) 
                    VALUES (?, ?, 'pending', 'cod', ?, ?)";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "idss", $_SESSION['user_id'], $total_amount, $address, $pincode);
            mysqli_stmt_execute($stmt);
            $order_id = mysqli_insert_id($conn);
            
            // Add order items
            foreach ($cart_items as $item) {
                $sql = "INSERT INTO order_items (order_id, product_id, quantity, price) 
                        VALUES (?, ?, ?, ?)";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "iiid", $order_id, $item['product_id'], $item['quantity'], $item['price']);
                mysqli_stmt_execute($stmt);
                
                // Update product stock
                $new_stock = $item['stock_quantity'] - $item['quantity'];
                $sql = "UPDATE products SET stock_quantity = ? WHERE product_id = ?";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "ii", $new_stock, $item['product_id']);
                mysqli_stmt_execute($stmt);
            }
            
            // Clear cart
            $sql = "DELETE FROM cart WHERE user_id = ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "i", $_SESSION['user_id']);
            mysqli_stmt_execute($stmt);
            
            // Redirect to success page
            header("Location: order_success.php?order_id=" . $order_id);
            exit();
        } 
        // Process online payment
        else if ($payment_method === 'online') {
            // Create order with pending payment status
            $sql = "INSERT INTO orders (user_id, total_amount, status, payment_method, shipping_address, pincode) 
                    VALUES (?, ?, 'pending', 'online', ?, ?)";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "idss", $_SESSION['user_id'], $total_amount, $address, $pincode);
            mysqli_stmt_execute($stmt);
            $order_id = mysqli_insert_id($conn);
            
            // Add order items
            foreach ($cart_items as $item) {
                $sql = "INSERT INTO order_items (order_id, product_id, quantity, price) 
                        VALUES (?, ?, ?, ?)";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "iiid", $order_id, $item['product_id'], $item['quantity'], $item['price']);
                mysqli_stmt_execute($stmt);
            }
            
            // Initialize Razorpay order
            $api = new Api($config['key_id'], $config['key_secret']);
            
            $orderData = [
                'receipt'         => 'order_rcpt_' . $order_id,
                'amount'          => $total_amount * 100, // Razorpay expects amount in paise
                'currency'        => 'INR',
                'payment_capture' => 1 // Auto-capture payment
            ];
            
            try {
                $razorpayOrder = $api->order->create($orderData);
                $razorpayOrderId = $razorpayOrder['id'];
                
                // Store Razorpay order ID in the database
                $sql = "UPDATE orders SET razorpay_order_id = ? WHERE order_id = ?";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "si", $razorpayOrderId, $order_id);
                mysqli_stmt_execute($stmt);
                
                // Store order ID in session for verification after payment
                $_SESSION['razorpay_order_id'] = $razorpayOrderId;
                
                // Display payment form
                $displayAmount = $total_amount;
                $data = [
                    'key'               => $config['key_id'],
                    'amount'            => $orderData['amount'],
                    'name'              => 'PharmaMed',
                    'description'       => 'Order #' . $order_id,
                    'image'             => 'assets/images/logo.png',
                    'prefill'           => [
                        'name'    => $name,
                        'email'   => $email,
                        'contact' => $phone,
                    ],
                    'theme'             => [
                        'color' => '#3399cc'
                    ],
                    'order_id'          => $razorpayOrderId,
                ];
                
                $json = json_encode($data);
                
            } catch (Exception $e) {
                $errors[] = 'Error creating order. Please try again.';
                error_log('Razorpay Order Error: ' . $e->getMessage());
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - PharmaMed</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <style>
        .order-summary {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
        }
        .payment-option {
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 15px;
            cursor: pointer;
            transition: all 0.3s;
        }
        .payment-option:hover {
            border-color: #0d6efd;
            background-color: #f8f9ff;
        }
        .payment-option.active {
            border-color: #0d6efd;
            background-color: #f0f7ff;
        }
        .payment-option input[type="radio"] {
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container my-5">
        <div class="row">
            <div class="col-md-8 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h4>Shipping Information</h4>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($errors)): ?>
                            <div class="alert alert-danger">
                                <ul class="mb-0">
                                    <?php foreach ($errors as $error): ?>
                                        <li><?php echo $error; ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        
                        <form id="checkoutForm" method="POST" action="">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="name" class="form-label">Full Name</label>
                                    <input type="text" class="form-control" id="name" name="name" required 
                                           value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" required
                                           value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="form-label">Phone Number</label>
                                <input type="tel" class="form-control" id="phone" name="phone" required
                                       value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="address" class="form-label">Delivery Address</label>
                                <textarea class="form-control" id="address" name="address" rows="3" required><?php 
                                    echo htmlspecialchars($user['address'] ?? ''); 
                                ?></textarea>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="pincode" class="form-label">Pincode</label>
                                    <input type="text" class="form-control" id="pincode" name="pincode" required
                                           value="<?php echo htmlspecialchars($user['pincode'] ?? ''); ?>">
                                </div>
                            </div>
                            
                            <h5 class="mt-4 mb-3">Payment Method</h5>
                            
                            <div class="mb-3">
                                <div class="payment-option">
                                    <input type="radio" id="cod" name="payment_method" value="cod" checked>
                                    <label for="cod">Cash on Delivery (COD)</label>
                                    <p class="text-muted mt-2 mb-0">Pay in cash when your order is delivered.</p>
                                </div>
                                
                                <div class="payment-option">
                                    <input type="radio" id="online" name="payment_method" value="online">
                                    <label for="online">Pay Online</label>
                                    <p class="text-muted mt-2 mb-0">Pay securely using UPI, Credit/Debit Card, or Net Banking.</p>
                                </div>
                            </div>
                            
                            <div id="onlinePaymentInfo" class="alert alert-info d-none">
                                <i class="fas fa-lock me-2"></i>
                                Your payment will be processed securely by Razorpay. We do not store your payment details.
                            </div>
                            
                            <div class="d-grid gap-2 mt-4">
                                <button type="submit" id="placeOrderBtn" class="btn btn-primary btn-lg">
                                    Place Order
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-header">
                        <h5>Order Summary</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-2">
                            <span>Subtotal (<?php echo count($cart_items); ?> items)</span>
                            <span>₹<?php echo number_format($total_amount, 2); ?></span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Shipping</span>
                            <span>Free</span>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between fw-bold">
                            <span>Total</span>
                            <span>₹<?php echo number_format($total_amount, 2); ?></span>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <h6>Need Help?</h6>
                    </div>
                    <div class="card-body">
                        <p class="mb-1"><i class="fas fa-phone-alt me-2"></i> +91 1234567890</p>
                        <p class="mb-0"><i class="fas fa-envelope me-2"></i> support@pharmamed.com</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Toggle payment options
        document.querySelectorAll('.payment-option').forEach(option => {
            option.addEventListener('click', function() {
                const input = this.querySelector('input[type="radio"]');
                input.checked = true;
                document.querySelectorAll('.payment-option').forEach(opt => {
                    opt.classList.remove('active');
                });
                this.classList.add('active');
                
                // Toggle online payment info
                if (input.value === 'online') {
                    document.getElementById('onlinePaymentInfo').classList.remove('d-none');
                } else {
                    document.getElementById('onlinePaymentInfo').classList.add('d-none');
                }
            });
        });
        
        // Handle form submission for online payment
        document.getElementById('checkoutForm').addEventListener('submit', function(e) {
            const paymentMethod = document.querySelector('input[name="payment_method"]:checked').value;
            
            if (paymentMethod === 'online') {
                e.preventDefault();
                
                // Show loading state
                const btn = document.getElementById('placeOrderBtn');
                const btnText = btn.innerHTML;
                btn.disabled = true;
                btn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...';
                
                // Submit form via AJAX to create order
                const formData = new FormData(this);
                
                fetch('create_order.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        // Initialize Razorpay
                        const options = data.razorpay;
                        const rzp = new Razorpay(options);
                        
                        // Handle payment success
                        rzp.on('payment.failed', function(response) {
                            alert('Payment failed. Please try again.');
                            window.location.href = 'payment_failed.php';
                        });
                        
                        // Open Razorpay payment form
                        rzp.open();
                    } else {
                        alert('Error creating order: ' + data.message);
                        window.location.href = 'checkout.php';
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred. Please try again.');
                    window.location.href = 'checkout.php';
                })
                .finally(() => {
                    btn.disabled = false;
                    btn.innerHTML = btnText;
                });
            }
            // For COD, the form will submit normally
        });
    </script>
</body>
</html>
