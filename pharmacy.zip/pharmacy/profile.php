<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?redirect=profile.php");
    exit();
}

// Get user profile
$user_id = $_SESSION['user_id'];
$user = getUserProfile($user_id);

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = [
        'full_name' => mysqli_real_escape_string($conn, $_POST['full_name']),
        'phone' => mysqli_real_escape_string($conn, $_POST['phone']),
        'address' => mysqli_real_escape_string($conn, $_POST['address']),
        'pincode' => mysqli_real_escape_string($conn, $_POST['pincode'])
    ];
    
    if (updateUserProfile($user_id, $data)) {
        $user = array_merge($user, $data);
        $success_message = "Profile updated successfully!";
    } else {
        $error_message = "Error updating profile";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - PharmaMed</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <div class="card border-success">
                    <div class="card-body text-center">
                        <div class="bg-light-success d-inline-flex align-items-center justify-content-center rounded-circle mb-3" style="width: 100px; height: 100px;">
                            <i class="fas fa-user-circle fa-4x text-success"></i>
                        </div>
                        <h4 class="text-success"><?php echo htmlspecialchars($user['full_name']); ?></h4>
                        <p class="text-muted"><?php echo htmlspecialchars($user['email']); ?></p>
                    </div>
                </div>
                <div class="list-group mt-3">
                    <a href="#profile" class="list-group-item list-group-item-action active bg-success border-success">
                        <i class="fas fa-user me-2"></i>Profile
                    </a>
                    <a href="#orders" class="list-group-item list-group-item-action">
                        <i class="fas fa-shopping-bag me-2"></i>My Orders
                    </a>
                </div>
            </div>
            <div class="col-md-9">
                <!-- Profile Section -->
                <div class="card mb-4 border-success">
                    <div class="card-header bg-light-success border-success">
                        <h5 class="mb-0"><i class="fas fa-user-edit me-2 text-success"></i>Profile Information</h5>
                    </div>
                    <div class="card-body">
                        <?php if(isset($error_message)): ?>
                            <div class="alert alert-danger"><?php echo $error_message; ?></div>
                        <?php endif; ?>
                        <?php if(isset($success_message)): ?>
                            <div class="alert alert-success"><?php echo $success_message; ?></div>
                        <?php endif; ?>
                        
                        <form method="POST" action="">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="full_name" class="form-label">Full Name</label>
                                    <input type="text" class="form-control" id="full_name" name="full_name" 
                                           value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="phone" class="form-label">Phone</label>
                                    <input type="tel" class="form-control" id="phone" name="phone" 
                                           value="<?php echo htmlspecialchars($user['phone']); ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="pincode" class="form-label">Pin Code</label>
                                    <input type="text" class="form-control" id="pincode" name="pincode" 
                                           value="<?php echo htmlspecialchars($user['pincode']); ?>" required>
                                </div>
                                <div class="col-md-12 mb-3">
                                    <label for="address" class="form-label">Address</label>
                                    <div class="input-group">
                                        <span class="input-group-text">
                                            <i class="fas fa-map-marker-alt"></i>
                                        </span>
                                        <textarea class="form-control" id="address" name="address" rows="3" required><?php echo htmlspecialchars($user['address']); ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-save me-2"></i>Update Profile
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Orders Section -->
                <div class="card border-success">
                    <div class="card-header bg-light-success border-success">
                        <h5 class="mb-0"><i class="fas fa-shopping-bag me-2 text-success"></i>My Orders</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        $orders = getUserOrders($user_id);
                        if (empty($orders)):
                        ?>
                            <div class="alert alert-info">
                                You have no orders yet.
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr class="table-success">
                                            <th><i class="fas fa-hashtag me-2"></i>Order ID</th>
                                            <th><i class="far fa-calendar-alt me-2"></i>Date</th>
                                            <th>Total Amount</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($orders as $order): ?>
                                            <tr>
                                                <td>#<?php echo $order['order_id']; ?></td>
                                                <td><?php echo date('Y-m-d', strtotime($order['created_at'])); ?></td>
                                                <td>₹<?php echo $order['total_amount']; ?></td>
                                                <td>
                                                    <span class="badge bg-<?php 
                                                        echo $order['status'] == 'cancelled' ? 'danger' : 
                                                               ($order['status'] == 'returned' ? 'warning' : 
                                                                ($order['status'] == 'completed' ? 'success' : 'primary'));
                                                    ?>">
                                                        <?php 
                                                        echo ucfirst($order['status'] == 'completed' ? 'Delivered' : 
                                                                   ($order['status'] == 'cancelled' ? 'Cancelled' : 
                                                                    ($order['status'] == 'returned' ? 'Returned' : 'Ordered')));
                                                        ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <?php 
                                                    // Calculate days since delivery
                                                    $delivery_date = strtotime($order['created_at']);
                                                    $current_date = time();
                                                    $days_since_delivery = floor(($current_date - $delivery_date) / (60 * 60 * 24));
                                                    
                                                    // Show cancel button for pending orders
                                                    if ($order['status'] != 'completed' && $order['status'] != 'cancelled' && $order['status'] != 'returned'): ?>
                                                        <form method="POST" action="cancel_order.php" style="display: inline;">
                                                            <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to cancel this order?')">
                                                                Cancel Order
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>
                                                    
                                                    <?php // Show return button for completed orders within 7 days
                                                    if ($order['status'] == 'completed' && $days_since_delivery <= 7): ?>
                                                        <form method="POST" action="return_order.php" style="display: inline;">
                                                            <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                                            <button type="submit" class="btn btn-sm btn-warning ms-2" onclick="return confirm('Are you sure you want to return this order?')">
                                                                Return Order
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>
                                                    
                                                    <a href="order_details.php?order_id=<?php echo $order['order_id']; ?>" 
                                                       class="btn btn-sm btn-primary ms-2">
                                                        View Details
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>
