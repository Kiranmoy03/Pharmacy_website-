<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms of Service - PharmaMed</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            padding-top: 2rem;
            padding-bottom: 2rem;
        }
        .card {
            margin-bottom: 1.5rem;
            border: none;
            box-shadow: 0 0.125rem 0.25rem rgba(0,0,0,0.075);
        }
        .card-body {
            padding: 1.5rem;
        }
        h1 {
            color: #0d6efd;
            margin-bottom: 2rem;
        }
        h5.card-title {
            color: #0d6efd;
            margin-bottom: 1rem;
        }
        a {
            color: #0d6efd;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="text-center mb-4">
            <a href="index.php" class="text-decoration-none">
                <h1 class="display-4">PharmaMed</h1>
            </a>
            <p class="lead">Your Trusted Online Pharmacy</p>
        </div>

<div class="container py-5">
    <div class="row">
        <div class="col-lg-10 mx-auto">
            <h1 class="mb-4">Terms of Service</h1>
            
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h5 class="card-title">1. Acceptance of Terms</h5>
                    <p class="card-text">
                        By accessing and using this website, you accept and agree to be bound by the terms and conditions of this agreement.
                    </p>
                </div>
            </div>
            
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h5 class="card-title">2. Use of Service</h5>
                    <p class="card-text">
                        This website provides an online platform for purchasing pharmaceutical products. You agree to use the service only for lawful purposes and in accordance with these terms.
                    </p>
                </div>
            </div>
            
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h5 class="card-title">3. Product Information</h5>
                    <p class="card-text">
                        We strive to provide accurate product information, but we do not warrant that product descriptions or other content is accurate, complete, reliable, current, or error-free.
                    </p>
                </div>
            </div>
            
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h5 class="card-title">4. Privacy Policy</h5>
                    <p class="card-text">
                        Your use of the website is also governed by our Privacy Policy. Please review our <a href="privacy.php">Privacy Policy</a> for information about how we collect, use, and share your information.
                    </p>
                </div>
            </div>
            
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h5 class="card-title">5. Changes to Terms</h5>
                    <p class="card-text">
                        We reserve the right to modify these terms at any time. Your continued use of the website after any such changes constitutes your acceptance of the new terms.
                    </p>
                </div>
            </div>
            
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">6. Contact Us</h5>
                    <p class="card-text">
                        If you have any questions about these Terms of Service, please contact us at <a href="mailto:hkiranmoy@gmail.com">hkiranmoy@gmail.com</a>.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
