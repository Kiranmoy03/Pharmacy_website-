-- Add address and pincode columns to users table if they don't exist
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS address TEXT,
ADD COLUMN IF NOT EXISTS pincode VARCHAR(10);
