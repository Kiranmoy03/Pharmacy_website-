-- Add payment status and Razorpay order ID to orders table
ALTER TABLE orders 
ADD COLUMN IF NOT EXISTS payment_status VARCHAR(20) DEFAULT 'pending' AFTER status,
ADD COLUMN IF NOT EXISTS razorpay_order_id VARCHAR(50) AFTER payment_method,
ADD COLUMN IF NOT EXISTS razorpay_payment_id VARCHAR(50) AFTER razorpay_order_id,
ADD COLUMN IF NOT EXISTS razorpay_signature VARCHAR(255) AFTER razorpay_payment_id,
ADD COLUMN IF NOT EXISTS delivered_at TIMESTAMP NULL AFTER created_at;

-- Add indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_orders_payment_status ON orders(payment_status);
CREATE INDEX IF NOT EXISTS idx_orders_razorpay_id ON orders(razorpay_order_id);
