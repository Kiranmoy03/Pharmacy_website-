<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Simple test upload handler
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_FILES['testFile'])) {
    $uploadDir = __DIR__ . '/uploads/test/';
    
    // Create test directory if it doesn't exist
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    
    $file = $_FILES['testFile'];
    $targetPath = $uploadDir . basename($file['name']);
    
    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        echo json_encode([
            'success' => true,
            'message' => 'File uploaded successfully!',
            'path' => $targetPath
        ]);
    } else {
        $error = error_get_last();
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Failed to upload file',
            'error' => $error ? $error['message'] : 'Unknown error'
        ]);
    }
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Test File Upload</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header bg-success text-white">
                        <h4 class="mb-0">Test File Upload</h4>
                    </div>
                    <div class="card-body">
                        <div id="message" class="mb-3"></div>
                        <form id="uploadForm" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="testFile" class="form-label">Select a file to upload:</label>
                                <input type="file" class="form-control" id="testFile" name="testFile" required>
                            </div>
                            <button type="submit" class="btn btn-success">Upload File</button>
                        </form>
                    </div>
                </div>
                <div class="mt-3">
                    <a href="check_uploads_permissions.php" class="btn btn-outline-secondary btn-sm">
                        Check Upload Permissions
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script>
    document.getElementById('uploadForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const submitBtn = e.target.querySelector('button[type="submit"]');
        const messageDiv = document.getElementById('message');
        
        // Show loading state
        const originalBtnText = submitBtn.innerHTML;
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Uploading...';
        messageDiv.innerHTML = '';
        
        try {
            const response = await fetch('upload-test.php', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                messageDiv.innerHTML = `
                    <div class="alert alert-success">
                        <strong>Success!</strong> ${result.message}<br>
                        <small>File saved to: ${result.path}</small>
                    </div>
                `;
            } else {
                throw new Error(result.message || 'Upload failed');
            }
        } catch (error) {
            console.error('Upload error:', error);
            messageDiv.innerHTML = `
                <div class="alert alert-danger">
                    <strong>Error:</strong> ${error.message || 'Failed to upload file'}
                </div>
            `;
        } finally {
            // Reset button
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalBtnText;
            
            // Reset form
            e.target.reset();
        }
    });
    </script>
</body>
</html>
