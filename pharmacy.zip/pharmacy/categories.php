<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

// Get all products with their categories
$sql = "SELECT p.*, c.category_name 
        FROM products p
        JOIN (
            SELECT DISTINCT category as category_name FROM products
        ) c
        ON p.category = c.category_name
        ORDER BY c.category_name, p.name";
$result = mysqli_query($conn, $sql);
$products = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Get all categories
$sql = "SELECT DISTINCT category as name FROM products ORDER BY name";
$result = mysqli_query($conn, $sql);
$categories = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Categories - PharmaMed</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Active state for category items */
        .list-group-item.active {
            background-color: #e8f5e9 !important;
            color: #1c7430 !important;
            border-left: 3px solid #1c7430 !important;
            font-weight: 500;
        }
        
        /* Ensure pills are green */
        .nav-pills .nav-link.active {
            background-color: #1c7430;
        }
        
        /* Hover effect for pills */
        .nav-pills .nav-link:not(.active):hover {
            color: #1c7430;
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container mt-4">
        <div class="row">
            <!-- Categories Sidebar -->
            <div class="col-md-3">
                <div class="card" style="border: none; box-shadow: 0 2px 10px rgba(0,0,0,0.05); overflow: hidden;">
                    <div class="card-header" style="background-color: #1c7430; color: white; border-bottom: none; padding: 12px 15px; font-weight: 600;">
                        <h5 class="mb-0">Categories</h5>
                    </div>
                    <div class="list-group" style="border-radius: 0;">
                        <?php 
                        $current_category = isset($_GET['category']) ? $_GET['category'] : '';
                        foreach ($categories as $cat): 
                            $is_active = ($current_category === $cat['name']);
                        ?>
                            <a href="products.php?category=<?php echo urlencode($cat['name']); ?>"
                               class="list-group-item list-group-item-action <?php echo $is_active ? 'active' : ''; ?>"
                               style="border: none; border-left: 3px solid transparent; padding: 10px 15px; color: #495057; transition: all 0.2s ease; background-color: #f8f9fa; text-decoration: none;"
                               onmouseover="this.style.backgroundColor='#e8f5e9'; this.style.borderLeftColor='#a5d6a7'; this.style.color='#1c7430'"
                               onmouseout="if(!this.classList.contains('active')) {this.style.backgroundColor='#f8f9fa'; this.style.borderLeftColor='transparent'; this.style.color='#495057'}">
                                <i class="fas fa-capsules me-2"></i> <?php echo htmlspecialchars($cat['name']); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Featured Categories -->
            <div class="col-md-9">
                <h2 style="color: #1c7430; font-weight: 600; margin-bottom: 1.5rem;">Featured Categories</h2>
                <div class="row g-4">
                    <?php
                    // Group products by category
                    $category_products = [];
                    foreach ($products as $product) {
                        $category_products[$product['category']][] = $product;
                    }

                    // Show featured categories
                    $featured_categories = array_slice($categories, 0, 4); // Show first 4 categories
                    foreach ($featured_categories as $cat):
                        $category_name = $cat['name'];
                        $featured_products = array_slice($category_products[$category_name], 0, 3); // Show 3 products per category
                    ?>
                        <div class="col-md-4">
                            <div class="card h-100 border-0 shadow-sm" style="transition: transform 0.3s ease, box-shadow 0.3s ease;">
                                <div class="card-header bg-white border-0 pt-3">
                                    <h5 class="card-title mb-0">
                                        <a href="products.php?category=<?php echo urlencode($category_name); ?>" 
                                           style="color: #1c7430; text-decoration: none; font-weight: 600;">
                                            <?php echo htmlspecialchars($category_name); ?>
                                            <i class="fas fa-arrow-right ms-2" style="font-size: 0.8em;"></i>
                                        </a>
                                    </h5>
                                </div>
                                <div class="card-body pt-0">
                                    <div class="category-products">
                                        <?php foreach ($featured_products as $product): ?>
                                            <div class="product-item d-flex align-items-center mb-3 p-2" 
                                                 style="border-radius: 8px; transition: background-color 0.2s ease;"
                                                 onmouseover="this.style.backgroundColor='#f1f8e9'"
                                                 onmouseout="this.style.backgroundColor='transient'">
                                                <img src="<?php echo $product['image_url']; ?>" 
                                                     alt="<?php echo $product['name']; ?>" 
                                                     class="img-fluid me-3" 
                                                     style="width: 60px; height: 60px; object-fit: contain; background: #f8f9fa; border-radius: 6px; padding: 5px;">
                                                <div style="flex: 1;">
                                                    <h6 class="mb-1" style="color: #1c7430; font-size: 0.9rem;">
                                                        <?php echo htmlspecialchars($product['name']); ?>
                                                    </h6>
                                                    <p class="mb-1" style="color: #28a745; font-weight: 600; font-size: 0.95rem;">
                                                        ₹<?php echo number_format($product['price'], 2); ?>
                                                    </p>
                                                    <button class="btn btn-sm add-to-cart" 
                                                            data-product-id="<?php echo $product['product_id']; ?>"
                                                            style="background-color: #1c7430; color: white; border: none; padding: 0.25rem 0.75rem; font-size: 0.8rem; border-radius: 4px;"
                                                            onmouseover="this.style.backgroundColor='#155724'"
                                                            onmouseout="this.style.backgroundColor='#1c7430'">
                                                        <i class="fas fa-cart-plus me-1"></i> Add
                                                    </button>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>
