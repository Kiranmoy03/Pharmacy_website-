<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/maintenance_check.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PharmaMed - Your Trusted Pharmacy</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/product-cards.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="index.php" style="color: #1c7430 !important; font-weight: 700; font-size: 1.5rem; text-decoration: none;">
                <span class="me-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" viewBox="0 0 16 16" style="color: #1c7430;">
                        <path d="M1.828 8.9 8.9 1.827a4 4 0 1 1 5.657 5.657l-7.07 7.071A4 4 0 1 1 1.827 8.9Zm9.128.771.414-.414a2 2 0 1 0-2.828-2.828l-.414.415 2.828 2.827Z"/>
                    </svg>
                </span>
                PharmaMed
            </a>
            <style>
                .gradient-text {
                    background: linear-gradient(90deg, #218838, #1c7430);
                    -webkit-background-clip: text;
                    -webkit-text-fill-color: transparent;
                    font-weight: 700;
                }
                .navbar-brand {
                    font-size: 1.5rem;
                    letter-spacing: 0.5px;
                }
            </style>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="products.php">Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="categories.php">Categories</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <li class="nav-item d-flex align-items-center">
                            <a class="nav-link d-flex align-items-center px-3 py-2 rounded-3 me-2 hover-bg-light" href="profile.php">
                                <i class="fas fa-user-circle me-2"></i> My Account
                            </a>
                        </li>
                        <li class="nav-item d-flex align-items-center me-2">
                            <a class="nav-link position-relative p-0" href="cart.php" title="Cart">
                                <div class="position-relative">
                                    <i class="fas fa-shopping-cart fs-5 p-2 rounded-circle hover-bg-light"></i>
                                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-primary">
                                        <?php echo getCartItemCount(); ?>
                                    </span>
                                </div>
                            </a>
                        </li>
                        <li class="nav-item d-flex align-items-center">
                            <a class="nav-link d-flex align-items-center px-3 py-2 rounded-3 hover-bg-light text-danger" href="logout.php">
                                <i class="fas fa-sign-out-alt me-2"></i> Sign Out
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link d-flex align-items-center px-3 py-2 rounded-3 mx-1 hover-bg-light" href="login.php">
                                <i class="fas fa-sign-in-alt me-2"></i> Sign In
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link d-flex align-items-center px-3 py-2 rounded-3 mx-1 bg-primary text-white hover-bg-primary" href="register.php">
                                <i class="fas fa-user-plus me-2"></i> Register
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
                <style>
                    .hover-bg-light {
                        transition: all 0.2s ease;
                    }
                    .hover-bg-light:hover {
                        background-color: rgba(0, 0, 0, 0.05);
                    }
                    .hover-bg-primary:hover {
                        background-color: #3451b5 !important;
                    }
                    .navbar-nav .nav-link {
                        font-size: 0.95rem;
                        font-weight: 500;
                    }
                    .navbar-nav .btn-cart {
                        position: relative;
                        padding: 0.5rem;
                    }
                    .cart-badge {
                        position: absolute;
                        top: -5px;
                        right: -5px;
                        font-size: 0.65rem;
                        min-width: 18px;
                        height: 18px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        padding: 0 4px;
                    }
                </style>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="hero-section py-5" style="background: linear-gradient(135deg, #c8e6c9 0%, #a5d6a7 100%);">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-12">
                    <h1 class="display-5 text-center mb-3" style="color: #155724; text-shadow: 0 1px 2px rgba(0,0,0,0.1);">Your Health, Our Priority</h1>
                    <p class="lead text-center mb-4 fw-medium" style="color: #1e7e34;">Get your medicines delivered right to your doorstep</p>
                    <div class="d-flex justify-content-center">
                        <div class="search-container" style="max-width: 600px; width: 100%;">
                            <form action="products.php" method="get" class="w-100" id="searchForm">
                                <div class="input-group">
                                    <input type="text" 
                                           class="form-control form-control-sm" 
                                           id="searchInput" 
                                           name="search"
                                           placeholder="Search medicines, health products..."
                                           aria-label="Search products"
                                           required>
                                    <button class="btn btn-search btn-sm" type="submit" id="searchButton">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <style>
            .search-container .input-group {
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                border-radius: 50px;
                overflow: hidden;
            }
            .search-container .form-control {
                border: none;
                padding: 0.5rem 1.25rem;
                font-size: 0.9rem;
                height: 38px;
            }
            .search-container .btn-search {
                padding: 0.25rem 1rem;
                border-radius: 0 50px 50px 0;
                height: 38px;
                display: flex;
                align-items: center;
                justify-content: center;
                background-color: #1c7430; /* Brand green background */
                border: 1px solid #155724; /* Slightly darker green border */
                transition: all 0.2s ease;
            }
            .search-container .btn-search:hover {
                background-color: #155724; /* Darker green on hover */
            }
            .search-container .btn-search i {
                font-size: 1rem;
                color: #ffffff; /* White color for the icon */
            }
            @ (max-width: 768px) {
                .hero-section {
                    padding: 1.5rem 0;
                }
                h1.display-5 {
                    font-size: 1.8rem;
                }
                .lead {
                    font-size: 1rem;
                }
            }
        </style>
    </div>

    <!-- Featured Products -->
    <style>
        .featured-products {
            padding: 1.25rem 0;
            margin: 0;
            width: 100%;
        }
        .featured-products .product-card {
            transition: all 0.25s ease;
            background: #a0d9a0; /* Darker green background */
            border-radius: 8px;
            padding: 0.6rem;
            height: 100%;
            border: 1px solid #7ac17a; /* Even darker green border */
            color: #fff; /* White text for better contrast */
            overflow: hidden;
            position: relative;
            max-width: 180px; /* Limit card width */
            margin: 0 auto; /* Center the card */
        }
        .featured-products .product-card a {
            display: flex;
            flex-direction: column;
            background-color: #fafbff;
            border-radius: 6px;
            padding: 0.4rem;
            margin: 0 0 0.3rem 0;
            text-decoration: none;
            height: calc(100% - 1.8rem);
        }
        .featured-products .product-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 3px 15px rgba(67, 97, 238, 0.1);
            border-color: #e0e6ff;
        }
        .featured-products .product-card img {
            max-height: 120px;
            width: auto;
            max-width: 100%;
            margin: 0 auto 0.4rem;
            display: block;
            background: white;
            padding: 2px;
            border-radius: 4px;
            object-fit: contain;
        }
        .featured-products .product-card h3 {
            font-size: 0.76rem;
            margin: 0 0 0.1rem 0;
            line-height: 1.15;
            font-weight: 500;
            color: #2c3e50;
            flex-grow: 1;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
            min-height: 1.6rem;
            padding: 0;
            width: 100%;
        }
        .featured-products .product-card .price {
            font-size: 0.85rem;
            font-weight: 600;
            margin: 0.1rem 0 0.2rem 0;
            color: #4361ee;
            text-align: left;
            padding: 0;
            line-height: 1;
            display: block;
            width: 100%;
        }
        .featured-products .product-card .btn {
            padding: 0;
            width: 22px;
            height: 22px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 3px;
            background: #4361ee;
            border: none;
            color: white;
            font-size: 0.65rem;
            transition: all 0.2s ease;
            margin: 0.1rem 0 0 0;
        }
        .featured-products .product-card .btn:hover {
            background: #3a56d4;
            transform: scale(1.05);
            box-shadow: 0 2px 4px rgba(0,0,0,0.15);
        }
        .featured-products h2 {
            font-size: 2rem;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 1.5rem;
            text-align: left;
            padding-left: 1rem;
        }
        @media (max-width: 767.98px) {
            .featured-products {
                padding: 1rem 0;
            }
            .featured-products h2 {
                font-size: 1.25rem;
                margin-bottom: 0.75rem;
            }
            .featured-products .product-card {
                padding: 0.5rem;
            }
            .featured-products .product-card a {
                padding: 0.5rem 0.4rem;
            }
            .featured-products .product-card h3 {
                font-size: 0.82rem;
                min-height: 2.1rem;
            }
            .featured-products .product-card .price {
                font-size: 0.9rem;
            }
        }
    </style>
    <!-- Featured Products Section -->
    <section class="py-5" style="background-color: #f8f9f8;">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="section-header mb-0">
                    Featured Products
                </h2>
                <a href="products.php" class="btn btn-outline-success btn-sm d-flex align-items-center" style="border-radius: 50px; padding: 0.25rem 1rem; border-width: 2px;">
                    View All <i class="fas fa-arrow-right ms-2"></i>
                </a>
            </div>
            <div class="row g-3">
                <?php
                $sql = "SELECT * FROM products LIMIT 4";
                $result = $conn->query($sql);
                while($product = $result->fetch_assoc()):
                ?>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="card product-card h-100 border-0 shadow-sm" tabindex="0">
                        <a href="product-details.php?id=<?php echo $product['product_id']; ?>" class="text-decoration-none">
                            <img src="<?php echo htmlspecialchars($product['image_url']); ?>" class="card-img-top p-3" alt="<?php echo htmlspecialchars($product['name']); ?>" style="height: 180px; object-fit: contain;">
                            <div class="card-body text-center">
                                <h6 class="card-title mb-1"><?php echo htmlspecialchars($product['name']); ?></h6>
                                <p class="card-text text-muted mb-1 small"><?php echo htmlspecialchars($product['description']); ?></p>
                                <p class="card-text fw-bold" style="color: #1c7430; font-size: 1.1rem;">₹<?php echo number_format($product['price'], 2); ?></p>
                            </div>
                        </a>
                        <div class="card-footer bg-transparent border-0 pt-0">
                            <button class="btn btn-sm w-100 add-to-cart" data-product-id="<?php echo $product['product_id']; ?>" style="background: linear-gradient(90deg, #28a745, #1c7430); color: white; border: none; transition: all 0.3s;">
                                <i class="fas fa-cart-plus me-1"></i> Add to Cart
                            </button>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </section>

    <style>
        .product-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border-radius: 10px;
            overflow: hidden;
            background-color: #f0f9f0;
            border: 1px solid #e0f0e0;
        }
        .product-card .card-title {
            color: #1c7430;
            font-weight: 600;
        }
        .product-card:active {
            transform: scale(0.98) !important;
            box-shadow: 0 2px 8px rgba(28, 116, 48, 0.3) !important;
        }
        .product-card:focus {
            outline: 2px solid #1c7430;
            outline-offset: 2px;
        }
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1) !important;
        }
        .product-card .card-body {
            border-bottom: 1px solid #e9ecef;
        }
        .product-card .card-footer {
            background-color: #f8f9fa;
        }
        .add-to-cart:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(40, 167, 69, 0.3) !important;
        }
    </style>

    <!-- Prescription Upload Section -->
    <style>
        .prescription-section {
            background-color: #f8f9f8;
            border-top: 1px solid #e8f5e9;
            border-bottom: 1px solid #e8f5e9;
            padding: 2.5rem 0;
        }
        .prescription-upload-box {
            background: linear-gradient(135deg, #f8f9f8 0%, #e8f5e9 100%);
            border: 1px solid #c8e6c9;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .prescription-upload-box:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(40, 167, 69, 0.1);
        }
        .prescription-upload-box .btn-primary {
            background: linear-gradient(90deg, #28a745, #1c7430);
            border: none;
            padding: 0.5rem 1.5rem;
            font-weight: 500;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
        }
        .prescription-upload-box .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(40, 167, 69, 0.3);
            background: linear-gradient(90deg, #23923d, #155724);
        }
        .prescription-upload-box .text-muted a {
            color: #1c7430 !important;
            font-weight: 500;
            transition: all 0.2s ease;
        }
        .prescription-upload-box .text-muted a:hover {
            text-decoration: underline !important;
            color: #155724 !important;
        }
        .how-it-works {
            padding: 1.5rem 0 0;
            margin-top: 1.5rem;
            border-top: none !important;
        }
        .how-it-works h4 {
            color: #1c7430;
            position: relative;
            padding-bottom: 0.5rem;
        }
        .how-it-works h4 {
            color: #1c7430;
            padding-bottom: 0;
        }
        .how-it-works-toggle {
            display: none;
            width: 100%;
            text-align: left;
            background: linear-gradient(135deg, #f8f9f8 0%, #e8f5e9 100%);
            border: 1px solid #c8e6c9;
            border-radius: 6px;
            padding: 0.75rem 1rem;
            font-weight: 600;
            color: #1c7430;
            margin-bottom: 1rem;
            transition: all 0.2s ease;
        }
        .how-it-works-toggle:hover {
            background: linear-gradient(135deg, #e8f5e9 0%, #d8edda 100%);
            color: #155724;
        }
        .how-it-works-toggle:after {
            content: '\f078';
            font-family: 'Font Awesome 5 Free';
            float: right;
        }
    </style>
    
    <!-- Categories Section -->
    <section class="py-5" style="background-color: #f8f9f8;">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="section-header mb-0">Shop by Categories</h2>
                <a href="categories.php" class="btn btn-outline-success btn-sm d-flex align-items-center" style="border-radius: 50px; padding: 0.25rem 1rem; border-width: 2px;">
                    View All <i class="fas fa-arrow-right ms-2"></i>
                </a>
            </div>
            <div class="row g-4">
                <?php
                // Fetch all categories
                $sql = "SELECT * FROM categories ORDER BY name ASC";
                $result = mysqli_query($conn, $sql);
                
                // Default categories in case the table is empty
                $default_categories = [
                    ['name' => 'Vitamins & Supplements', 'icon' => 'pills'],
                    ['name' => 'Personal Care', 'icon' => 'spa'],
                    ['name' => 'Healthcare Devices', 'icon' => 'heart-pulse'],
                    ['name' => 'Ayurvedic', 'icon' => 'leaf'],
                    ['name' => 'Baby Care', 'icon' => 'baby'],
                    ['name' => 'Health Food', 'icon' => 'apple-whole'],
                    ['name' => 'Diabetes Care', 'icon' => 'syringe'],
                    ['name' => 'Elderly Care', 'icon' => 'user-nurse']
                ];
                
                // Use database categories if available, otherwise use default
                $categories = [];
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $categories[] = $row;
                    }
                } else {
                    $categories = $default_categories;
                }
                
                // Display categories
                foreach ($categories as $category):
                    $icon = isset($category['icon']) ? $category['icon'] : 'shapes';
                ?>
                <div class="col-6 col-md-3">
                    <a href="categories.php?category=<?php echo urlencode($category['name']); ?>" class="category-card text-decoration-none">
                        <div class="category-icon">
                            <i class="fas fa-<?php echo $icon; ?>"></i>
                        </div>
                        <h3 class="category-name"><?php echo htmlspecialchars($category['name']); ?></h3>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Best Selling Products Section -->
    <section class="py-5" style="background-color: #f8f9f8;">
        <div class="container">
            <h2 class="section-header">
                Frequently Bought Medicines
            </h2>
            <div class="row g-3">
                <?php
                // Fetch best selling products (top 4)
                $sql = "SELECT p.*, SUM(oi.quantity) as total_sold 
                        FROM products p 
                        JOIN order_items oi ON p.product_id = oi.product_id 
                        JOIN orders o ON oi.order_id = o.order_id 
                        WHERE o.status = 'completed' 
                        GROUP BY p.product_id 
                        ORDER BY total_sold DESC 
                        LIMIT 4";
                $result = $conn->query($sql);

                if ($result && $result->num_rows > 0) {
                    while($product = $result->fetch_assoc()) {
                        echo '<div class="col-6 col-md-4 col-lg-3">';
                        echo '<div class="card product-card h-100 border-0 shadow-sm">';
                        echo '<a href="product-details.php?id=' . $product['product_id'] . '" class="text-decoration-none">';
                        echo '<img src="' . htmlspecialchars($product['image_url']) . '" class="card-img-top p-3" alt="' . htmlspecialchars($product['name']) . '" style="height: 180px; object-fit: contain;">';
                        echo '<div class="card-body text-center">';
                        echo '<h6 class="card-title mb-1">' . htmlspecialchars($product['name']) . '</h6>';
                        echo '<p class="card-text text-muted mb-1 small">' . htmlspecialchars($product['description']) . '</p>';
                        echo '<p class="product-price">₹' . number_format($product['price'], 2) . '</p>';
                        echo '</div></a>';
                        echo '<div class="card-footer bg-transparent border-0 pt-0">';
                        echo '<button class="btn btn-green w-100 add-to-cart" data-product-id="' . $product['product_id'] . '">';
                        echo '<i class="fas fa-cart-plus me-1"></i> Add to Cart';
                        echo '</button>';
                        echo '</div>';
                        echo '</div></div>';
                    }
                } else {
                    // Fallback to featured products if no best sellers yet
                    $sql = "SELECT * FROM products LIMIT 4";
                    $result = $conn->query($sql);
                    if ($result) {
                        while($product = $result->fetch_assoc()) {
                            echo '<div class="col-6 col-md-4 col-lg-3">';
                            echo '<div class="card product-card h-100 border-0 shadow-sm">';
                            echo '<a href="product-details.php?id=' . $product['product_id'] . '" class="text-decoration-none">';
                            echo '<img src="' . htmlspecialchars($product['image_url']) . '" class="card-img-top p-3" alt="' . htmlspecialchars($product['name']) . '" style="height: 180px; object-fit: contain;">';
                            echo '<div class="card-body text-center">';
                            echo '<h6 class="card-title mb-1">' . htmlspecialchars($product['name']) . '</h6>';
                            echo '<p class="card-text text-muted mb-1 small">' . htmlspecialchars($product['description']) . '</p>';
                            echo '<p class="product-price">₹' . number_format($product['price'], 2) . '</p>';
                            echo '</div></a>';
                            echo '<div class="card-footer bg-transparent border-0 pt-0">';
                            echo '<button class="btn btn-green w-100 add-to-cart" data-product-id="' . $product['product_id'] . '">';
                            echo '<i class="fas fa-cart-plus me-1"></i> Add to Cart';
                            echo '</button>';
                            echo '</div>';
                            echo '</div></div>';
                        }
                    }
                }
                ?>
            </div>
        </div>
    </section>

    <!-- New Arrivals Section -->
    <section class="py-5 new-arrivals" style="background-color: #f8f9f8;">
    <style>
        .new-arrivals .product-card {
            background: #f0f9f0; /* Lighter green background */
            border: 1px solid #e0f0e0; /* Lighter green border */
            color: #333; /* Darker text for better readability */
        }
    </style>
        <div class="container">
            <h2 class="section-header">New Arrivals</h2>
            <div class="row g-3">
                <?php
                // Fetch new arrivals (most recent 4 products)
                $sql = "SELECT * FROM products ORDER BY created_at DESC LIMIT 4";
                $result = $conn->query($sql);

                if ($result && $result->num_rows > 0) {
                    while($product = $result->fetch_assoc()) {
                        echo '<div class="col-6 col-md-4 col-lg-3">';
                        echo '<div class="card product-card h-100 border-0 shadow-sm">';
                        echo '<a href="product-details.php?id=' . $product['product_id'] . '" class="text-decoration-none">';
                        echo '<img src="' . htmlspecialchars($product['image_url']) . '" class="card-img-top p-3" alt="' . htmlspecialchars($product['name']) . '" style="height: 180px; object-fit: contain;">';
                        echo '<div class="card-body text-center">';
                        echo '<h6 class="card-title mb-1">' . htmlspecialchars($product['name']) . '</h6>';
                        echo '<p class="card-text text-muted mb-1 small">' . htmlspecialchars($product['description']) . '</p>';
                        echo '<p class="product-price">₹' . number_format($product['price'], 2) . '</p>';
                        echo '</div></a>';
                        echo '<div class="card-footer bg-transparent border-0 pt-0">';
                        echo '<button class="btn btn-green w-100 add-to-cart" data-product-id="' . $product['product_id'] . '">';
                        echo '<i class="fas fa-cart-plus me-1"></i> Add to Cart';
                        echo '</button>';
                        echo '</div>';
                        echo '</div></div>';
                    }
                } else {
                    echo '<div class="col-12 text-center"><p>No new products available at the moment.</p></div>';
                }
                ?>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="py-5" style="background-color: #f8f9f8;">
        <div class="container">
            <h2 class="section-header text-center">Frequently Asked Questions</h2>
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="accordion" id="faqAccordion">
                        <!-- FAQ Item 1 -->
                        <div class="card mb-3 border-0 shadow-sm overflow-hidden">
                            <div class="card-header p-0" id="headingOne">
                                <h3 class="mb-0">
                                    <button class="btn btn-link text-decoration-none w-100 text-start d-flex justify-content-between align-items-center p-3 collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne" style="background-color: #e8f5e9; color: #1c7430; font-weight: 500;">
                                        How do I place an order for medicines?
                                        <i class="fas fa-chevron-down ms-2 transition-all"></i>
                                    </button>
                                </h3>
                            </div>
                            <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-bs-parent="#faqAccordion">
                                <div class="card-body bg-white">
                                    You can place an order by browsing our products online, adding them to your cart, and proceeding to checkout. Alternatively, you can upload a photo of your prescription, and we'll prepare your order for you.
                                </div>
                            </div>
                        </div>

                        <!-- FAQ Item 2 -->
                        <div class="card mb-3 border-0 shadow-sm overflow-hidden">
                            <div class="card-header p-0" id="headingTwo">
                                <h3 class="mb-0">
                                    <button class="btn btn-link text-decoration-none w-100 text-start d-flex justify-content-between align-items-center p-3 collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo" style="background-color: #e8f5e9; color: #1c7430; font-weight: 500;">
                                        What are your delivery timings?
                                        <i class="fas fa-chevron-down ms-2 transition-all"></i>
                                    </button>
                                </h3>
                            </div>
                            <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-bs-parent="#faqAccordion">
                                <div class="card-body bg-white">
                                    We offer home delivery from 9:00 AM to 9:00 PM, seven days a week. Orders placed before 7:00 PM will be delivered on the same day. For emergency orders after hours, please call our 24/7 helpline.
                                </div>
                            </div>
                        </div>

                        <!-- FAQ Item 3 -->
                        <div class="card mb-3 border-0 shadow-sm overflow-hidden">
                            <div class="card-header p-0" id="headingThree">
                                <h3 class="mb-0">
                                    <button class="btn btn-link text-decoration-none w-100 text-start d-flex justify-content-between align-items-center p-3 collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree" style="background-color: #e8f5e9; color: #1c7430; font-weight: 500;">
                                        Do you deliver in my area?
                                        <i class="fas fa-chevron-down ms-2 transition-all"></i>
                                    </button>
                                </h3>
                            </div>
                            <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-bs-parent="#faqAccordion">
                                <div class="card-body bg-white">
                                    We currently serve all areas within [Your City]. During checkout, you can enter your pincode to confirm if we deliver to your location. If your area is not serviceable yet, please check back later as we're constantly expanding our delivery network.
                                </div>
                            </div>
                        </div>

                        <!-- FAQ Item 4 -->
                        <div class="card mb-3 border-0 shadow-sm overflow-hidden">
                            <div class="card-header p-0" id="headingFour">
                                <h3 class="mb-0">
                                    <button class="btn btn-link text-decoration-none w-100 text-start d-flex justify-content-between align-items-center p-3 collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour" style="background-color: #e8f5e9; color: #1c7430; font-weight: 500;">
                                        How do I upload a prescription?
                                        <i class="fas fa-chevron-down ms-2 transition-all"></i>
                                    </button>
                                </h3>
                            </div>
                            <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-bs-parent="#faqAccordion">
                                <div class="card-body bg-white">
                                    You can upload your prescription by clicking on the 'Upload Prescription' button on our homepage. Take a clear photo of your prescription and upload the file. Our pharmacists will verify it and prepare your order. You'll receive a confirmation call before we process your order.
                                </div>
                            </div>
                        </div>

                        <!-- FAQ Item 5 -->
                        <div class="card mb-3 border-0 shadow-sm overflow-hidden">
                            <div class="card-header p-0" id="headingFive">
                                <h3 class="mb-0">
                                    <button class="btn btn-link text-decoration-none w-100 text-start d-flex justify-content-between align-items-center p-3 collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive" style="background-color: #e8f5e9; color: #1c7430; font-weight: 500;">
                                        What payment methods do you accept?
                                        <i class="fas fa-chevron-down ms-2 transition-all"></i>
                                    </button>
                                </h3>
                            </div>
                            <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-bs-parent="#faqAccordion">
                                <div class="card-body bg-white">
                                    We accept various payment methods including cash on delivery, credit/debit cards, UPI, and net banking. For online payments, we use secure payment gateways to ensure your transaction details are always protected.
                                </div>
                            </div>
                        </div>

                        <!-- FAQ Item 6 -->
                        <div class="card mb-3 border-0 shadow-sm overflow-hidden">
                            <div class="card-header p-0" id="headingSix">
                                <h3 class="mb-0">
                                    <button class="btn btn-link text-decoration-none w-100 text-start d-flex justify-content-between align-items-center p-3 collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix" style="background-color: #e8f5e9; color: #1c7430; font-weight: 500;">
                                        Do you provide emergency medicine delivery?
                                        <i class="fas fa-chevron-down ms-2 transition-all"></i>
                                    </button>
                                </h3>
                            </div>
                            <div id="collapseSix" class="collapse" aria-labelledby="headingSix" data-bs-parent="#faqAccordion">
                                <div class="card-body bg-white">
                                    Yes, we understand that some medical situations can't wait. We offer emergency delivery services 24/7 for critical medicines. Please call our emergency helpline number [Emergency Number] for immediate assistance. Additional charges may apply for emergency deliveries.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <style>
        .product-card .btn-green {
            background: linear-gradient(90deg, #28a745, #1c7430);
            color: white;
            border: none;
            transition: all 0.3s;
        }
        .product-card .btn-green:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(40, 167, 69, 0.3);
        }
        /* FAQ Section Styling */
        .accordion .card {
            border-radius: 8px;
            overflow: hidden;
            margin-bottom: 12px;
            border: 1px solid #e0e0e0;
        }
        .accordion .card:last-child {
            margin-bottom: 0;
        }
        .accordion .card-header {
            padding: 0;
            border: none;
        }
        .accordion .btn-link {
            position: relative;
            transition: all 0.3s ease;
            text-decoration: none !important;
        }
        .accordion .btn-link:not(.collapsed) {
            background-color: #1c7430 !important;
            color: white !important;
        }
        .accordion .btn-link:not(.collapsed) .fa-chevron-down {
            transform: rotate(180deg);
            color: white;
        }
        .accordion .btn-link:hover {
            background-color: #d8edda !important;
        }
        .accordion .btn-link .fa-chevron-down {
            transition: transform 0.3s ease, color 0.3s ease;
        }
        .accordion .card-body {
            border-top: 1px solid #f0f0f0;
        }

        .product-price {
            color: #1c7430;
            font-size: 1.1rem;
            font-weight: bold;
        }
        .category-card {
            display: block;
            background: white;
            border-radius: 10px;
            padding: 1.5rem 1rem;
            text-align: center;
            transition: all 0.3s ease;
            border: 1px solid #e8f5e9;
            height: 100%;
            color: #1c7430;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
        .category-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(40, 167, 69, 0.1);
            color: #155724;
            border-color: #c8e6c9;
        }
        .category-icon {
            width: 60px;
            height: 60px;
            margin: 0 auto 1rem;
            background: linear-gradient(135deg, #e8f5e9 0%, #d8edda 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: #1c7430;
            transition: all 0.3s ease;
        }
        .category-card:hover .category-icon {
            background: linear-gradient(135deg, #d8edda 0%, #c8e6c9 100%);
            transform: scale(1.05);
        }
        .category-name {
            font-size: 0.95rem;
            font-weight: 500;
            margin: 0;
            line-height: 1.3;
            transition: color 0.3s ease;
        }
        @media (max-width: 767.98px) {
            .category-card {
                padding: 1rem 0.5rem;
            }
            .category-icon {
                width: 50px;
                height: 50px;
                font-size: 1.25rem;
            }
            .category-name {
                font-size: 0.85rem;
            }
        }
    </style>

    <!-- Footer -->
    <?php include 'includes/footer.php'; ?>

    <!-- Load jQuery first -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Then Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize any other necessary JavaScript here
        console.log('DOM fully loaded');
    });
    </script>


    <!-- Load main.js -->
    <script src="assets/js/main.js"></script>
    
    <script>
    // Initialize Bootstrap collapse for FAQ accordion
        var collapseElementList = [].slice.call(document.querySelectorAll('.collapse'));
        var collapseList = collapseElementList.map(function (collapseEl) {
            return new bootstrap.Collapse(collapseEl, {
                toggle: false
            });
        });

        // Handle accordion button clicks
        document.querySelectorAll('[data-bs-toggle="collapse"]').forEach(button => {
            button.addEventListener('click', function() {
                const target = document.querySelector(this.getAttribute('data-bs-target'));
                const isExpanded = this.getAttribute('aria-expanded') === 'true';
                
                // Close all other accordion items when one is opened
                if (!isExpanded) {
                    document.querySelectorAll('.accordion .collapse').forEach(collapse => {
                        if (collapse !== target) {
                            const bsCollapse = bootstrap.Collapse.getInstance(collapse);
                            if (bsCollapse) {
                                bsCollapse.hide();
                            }
                        }
                    });
                }
            });
        });
    });
    </script>
    <style>
    /* Ensure modal backdrop is properly styled */
    .modal-backdrop {
        position: fixed;
        top: 0;
        left: 0;
        z-index: 1040;
        width: 100vw;
        height: 100vh;
        background-color: #000;
        opacity: 0.5;
    }
    .modal.show {
        display: block;
        background-color: rgba(0,0,0,0.5);
    }
    </style>
</body>
</html>
