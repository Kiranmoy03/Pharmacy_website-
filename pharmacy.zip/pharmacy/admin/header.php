<?php
// This file is included by other admin pages which already have session and database connection
// So we don't need to start session or connect to database here

// Get the current page filename
$current_page = basename($_SERVER['PHP_SELF']);
$is_orders_page = ($current_page === 'orders.php');
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="orders.php">Admin Panel - PharmaMed</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#adminNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="adminNavbar">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link <?php echo $is_orders_page ? 'active' : ''; ?>" href="orders.php">
                        <i class="fas fa-box"></i> Manage Orders
                    </a>
                </li>
                <?php if (!$is_orders_page): ?>
                <li class="nav-item">
                    <a class="nav-link" href="../products.php">
                        <i class="fas fa-pills"></i> Products
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../categories.php">
                        <i class="fas fa-list"></i> Categories
                    </a>
                </li>
                <?php endif; ?>
            </ul>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="../index.php">
                        <i class="fas fa-home"></i> Back to Store
                    </a>
                </li>
                <?php if (!$is_orders_page): ?>
                <li class="nav-item">
                    <a class="nav-link" href="../logout.php">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
