<?php
require_once("../config/database.php");

// Add status column if it doesn't exist
$check_status = "SHOW COLUMNS FROM users LIKE 'status'";
$result = mysqli_query($conn, $check_status);
if(mysqli_num_rows($result) == 0) {
    $sql = "ALTER TABLE users ADD COLUMN status ENUM('active', 'inactive') DEFAULT 'active' AFTER role";
    if(mysqli_query($conn, $sql)) {
        echo "Successfully added 'status' column to users table.<br>";
    } else {
        die("Error adding status column: " . mysqli_error($conn));
    }
} else {
    echo "'status' column already exists.<br>";
}

// Add role column if it doesn't exist
$check_role = "SHOW COLUMNS FROM users LIKE 'role'";
$result = mysqli_query($conn, $check_role);
if(mysqli_num_rows($result) == 0) {
    $sql = "ALTER TABLE users ADD COLUMN role ENUM('admin', 'staff', 'user') DEFAULT 'user' AFTER password";
    if(mysqli_query($conn, $sql)) {
        echo "Successfully added 'role' column to users table.<br>";
    } else {
        die("Error adding role column: " . mysqli_error($conn));
    }
} else {
    echo "'role' column already exists.<br>";
}

// Set first user as admin if no admin exists
$check_admin = "SELECT user_id FROM users WHERE role = 'admin' LIMIT 1";
$result = mysqli_query($conn, $check_admin);
if(mysqli_num_rows($result) == 0) {
    $update_admin = "UPDATE users SET role = 'admin' ORDER BY user_id ASC LIMIT 1";
    if(mysqli_query($conn, $update_admin)) {
        echo "Set first user as admin.<br>";
    } else {
        echo "Error setting admin: " . mysqli_error($conn) . "<br>";
    }
}

echo "Database update complete. <a href='users.php'>Go to Users</a>";
?>
