<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include required files
require_once __DIR__ . '/includes/auth_check.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/includes/category_functions.php';

// Set page title
$page_title = 'Manage Categories';

// Generate CSRF token if not exists
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Check if user is admin
if ($_SESSION['role'] !== 'admin') {
    header('Location: dashboard.php');
    exit();
}

// Initialize messages
$success_msg = $error_msg = "";

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verify CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error_msg = 'Invalid CSRF token';
    } else {
        // Handle category addition
        if (isset($_POST['add_category'])) {
            $name = trim($_POST['name']);
            $description = trim($_POST['description']);
            
            if (empty($error_msg)) {
                if (addCategory($conn, $name, $description)) {
                    $success_msg = "Category added successfully.";
                    // Refresh the page to show the new category
                    header("Location: categories.php");
                    exit();
                } else {
                    $error_msg = "Error adding category: " . mysqli_error($conn);
                }
            }
        }
        // Handle category deletion
        elseif (isset($_POST['delete_category'])) {
            $category_id = (int)$_POST['category_id'];
            $result = deleteCategory($conn, $category_id);
            
            if ($result === true) {
                $success_msg = "Category deleted successfully.";
            } else {
                $error_msg = is_string($result) ? $result : "Error deleting category";
            }
        }
        // Handle status update
        elseif (isset($_POST['update_status'])) {
            $category_id = (int)$_POST['category_id'];
            $status = $_POST['status'] === 'active' ? 'active' : 'inactive';
            
            if (updateCategoryStatus($conn, $category_id, $status)) {
                $success_msg = "Category status updated successfully.";
            } else {
                $error_msg = "Error updating category status: " . mysqli_error($conn);
            }
        }
    }
}

// Check if categories table is empty and add sample data if needed
$result = mysqli_query($conn, "SELECT COUNT(*) as count FROM categories");
$row = mysqli_fetch_assoc($result);

if ($row['count'] == 0) {
    // Add sample categories
    $sample_categories = [
        ["name" => "Pain Relief", "description" => "Medications for pain management"],
        ["name" => "Vitamins & Supplements", "description" => "Nutritional supplements and vitamins"],
        ["name" => "First Aid", "description" => "First aid supplies and equipment"],
        ["name" => "Personal Care", "description" => "Personal hygiene and care products"],
        ["name" => "Baby Care", "description" => "Products for baby care and hygiene"]
    ];
    
    foreach ($sample_categories as $cat) {
        $name = mysqli_real_escape_string($conn, $cat['name']);
        $desc = mysqli_real_escape_string($conn, $cat['description']);
        $sql = "INSERT INTO categories (name, description, status) VALUES ('$name', '$desc', 'active')";
        mysqli_query($conn, $sql);
    }
    
    // Refresh the page to show the new categories
    header("Location: categories.php");
    exit();
}

// Get all categories with product count
$categories = getAllCategories($conn);

// Include header after session and database are set up
require_once 'includes/header.php';
?>

<!-- Main Content -->
<div class="container-fluid">
    <div class="row">
        <div class="col-md-10 p-4">

            <!-- Page title is set in the header -->

            <?php if($success_msg): ?>
                <div class="alert alert-success"><?php echo $success_msg; ?></div>
            <?php endif; ?>
            
            <?php if($error_msg): ?>
                <div class="alert alert-danger"><?php echo $error_msg; ?></div>
            <?php endif; ?>

            <div class="row">
                <!-- Add Category Form -->
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Add New Category</h5>
                        </div>
                        <div class="card-body">
                            <form action="" method="post" enctype="multipart/form-data">
                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                <div class="mb-3">
                                    <label for="name" class="form-label">Category Name *</label>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                </div>
                                <div class="mb-3">
                                    <label for="description" class="form-label">Description</label>
                                    <textarea class="form-control" id="description" name="description" rows="2"></textarea>
                                </div>

                                <button type="submit" name="add_category" class="btn btn-primary">
                                    <i class="fas fa-plus me-1"></i> Add Category
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Categories List -->
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">All Categories</h5>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Name</th>
                                            <th>Products</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(!empty($categories)): ?>
                                            <?php foreach($categories as $category): ?>
                                            <tr>

                                                <td>
                                                    <strong><?php echo htmlspecialchars($category['name']); ?></strong>
                                                    <?php if(!empty($category['description'])): ?>
                                                        <p class="text-muted small mb-0"><?php echo htmlspecialchars(substr($category['description'], 0, 50)); ?><?php echo strlen($category['description']) > 50 ? '...' : ''; ?></p>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo $category['product_count']; ?> products</td>
                                                <td>
                                                    <span class="badge bg-success">Active</span>
                                                </td>
                                                <td>
                                                    <div class="btn-group" role="group">
                                                        <a href="edit_category.php?id=<?php echo $category['category_id']; ?>" class="btn btn-sm btn-primary me-1">
                                                            <i class="fas fa-edit"></i>
                                                        </a>
                                                        <form method="post" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this category? This action cannot be undone.');">
                                                            <input type="hidden" name="category_id" value="<?php echo $category['category_id']; ?>">
                                                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                                            <button type="submit" name="delete_category" class="btn btn-sm btn-danger">
                                                                <i class="fas fa-trash"></i>
                                                            </button>
                                                        </form>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="5" class="text-center py-4">No categories found. Add your first category using the form.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Additional Scripts -->
<script>
// Delete confirmation
function confirmDelete() {
    return confirm('Are you sure you want to delete this category? This action cannot be undone.');
}
</script>

<?php include 'includes/footer.php'; ?>
