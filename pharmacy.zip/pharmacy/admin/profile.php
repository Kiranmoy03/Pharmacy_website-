<?php
// Start session and include database configuration
session_start();
require_once '../config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Set page title
$page_title = 'My Profile';

// Include header
require_once 'includes/header.php';

// Initialize variables
$name = $email = $phone = '';
$name_err = $email_err = $current_password_err = $new_password_err = $confirm_password_err = '';
$success_msg = '';

// Get current user data
$user_id = $_SESSION['user_id'];
$sql = "SELECT full_name, email, phone FROM users WHERE user_id = ?";
if ($stmt = mysqli_prepare($conn, $sql)) {
    mysqli_stmt_bind_param($stmt, "i", $param_id);
    $param_id = $user_id;
    
    if (mysqli_stmt_execute($stmt)) {
        mysqli_stmt_store_result($stmt);
        
        if (mysqli_stmt_num_rows($stmt) == 1) {
            mysqli_stmt_bind_result($stmt, $name, $email, $phone);
            mysqli_stmt_fetch($stmt);
        } else {
            // User not found
            $_SESSION['error'] = "User not found.";
            header("location: dashboard.php");
            exit();
        }
    } else {
        $_SESSION['error'] = "Oops! Something went wrong. Please try again later.";
        header("location: dashboard.php");
        exit();
    }
    
    mysqli_stmt_close($stmt);
}

// Process form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $name_err = "Invalid request. Please try again.";
    } else {
        // Check if it's a profile update or password change
        if (isset($_POST['update_profile'])) {
            // Validate name
            if (empty(trim($_POST["name"]))) {
                $name_err = "Please enter your name.";
            } else {
                $name = trim($_POST["name"]);
            }
            
            // Validate email
            if (empty(trim($_POST["email"]))) {
                $email_err = "Please enter your email.";
            } else {
                // Check if email exists
                $sql = "SELECT user_id FROM users WHERE email = ? AND user_id != ?";
                if ($stmt = mysqli_prepare($conn, $sql)) {
                    mysqli_stmt_bind_param($stmt, "si", $param_email, $param_user_id);
                    $param_email = trim($_POST["email"]);
                    $param_user_id = $user_id;
                    
                    if (mysqli_stmt_execute($stmt)) {
                        mysqli_stmt_store_result($stmt);
                        
                        if (mysqli_stmt_num_rows($stmt) == 1) {
                            $email_err = "This email is already taken.";
                        } else {
                            $email = trim($_POST["email"]);
                        }
                    } else {
                        $_SESSION['error'] = "Oops! Something went wrong. Please try again later.";
                    }
                    
                    mysqli_stmt_close($stmt);
                }
            }
            
            // Get phone
            $phone = trim($_POST["phone"]);
            
            // Check input errors before updating the database
            if (empty($name_err) && empty($email_err)) {
                $sql = "UPDATE users SET full_name = ?, email = ?, phone = ? WHERE user_id = ?";
                
                if ($update_stmt = mysqli_prepare($conn, $sql)) {
                    mysqli_stmt_bind_param($update_stmt, "sssi", $param_name, $param_email, $param_phone, $param_user_id);
                    
                    // Set parameters
                    $param_name = $name;
                    $param_email = $email;
                    $param_phone = $phone;
                    $param_user_id = $user_id;
                    
                    if (mysqli_stmt_execute($update_stmt)) {
                        // Update session variables
                        $_SESSION['name'] = $name;
                        $_SESSION['email'] = $email;
                        
                        $success_msg = "Profile updated successfully!";
                    } else {
                        $_SESSION['error'] = "Oops! Something went wrong. Please try again later.";
                    }
                    
                    mysqli_stmt_close($update_stmt);
                }
            }
        } 
        // Handle password change
        elseif (isset($_POST['change_password'])) {
            // Validate current password
            if (empty(trim($_POST["current_password"]))) {
                $current_password_err = "Please enter your current password.";
            } else {
                $current_password = trim($_POST["current_password"]);
                
                // Verify current password
                $sql = "SELECT password FROM users WHERE user_id = ?";
                if ($stmt = mysqli_prepare($conn, $sql)) {
                    mysqli_stmt_bind_param($stmt, "i", $param_user_id);
                    $param_user_id = $user_id;
                    
                    if (mysqli_stmt_execute($stmt)) {
                        mysqli_stmt_store_result($stmt);
                        
                        if (mysqli_stmt_num_rows($stmt) == 1) {
                            mysqli_stmt_bind_result($stmt, $hashed_password);
                            if (mysqli_stmt_fetch($stmt)) {
                                if (!password_verify($current_password, $hashed_password)) {
                                    $current_password_err = "The current password is not valid.";
                                }
                            }
                        }
                    } else {
                        $_SESSION['error'] = "Oops! Something went wrong. Please try again later.";
                    }
                    
                    mysqli_stmt_close($stmt);
                }
            }
            
            // Validate new password
            if (empty(trim($_POST["new_password"]))) {
                $new_password_err = "Please enter a new password.";     
            } elseif (strlen(trim($_POST["new_password"])) < 6) {
                $new_password_err = "Password must have at least 6 characters.";
            } else {
                $new_password = trim($_POST["new_password"]);
            }
            
            // Validate confirm password
            if (empty(trim($_POST["confirm_password"]))) {
                $confirm_password_err = "Please confirm the password.";     
            } else {
                $confirm_password = trim($_POST["confirm_password"]);
                if (empty($new_password_err) && ($new_password != $confirm_password)) {
                    $confirm_password_err = "Password did not match.";
                }
            }
            
            // Check input errors before updating the database
            if (empty($current_password_err) && empty($new_password_err) && empty($confirm_password_err)) {
                $sql = "UPDATE users SET password = ? WHERE user_id = ?";
                
                if ($update_stmt = mysqli_prepare($conn, $sql)) {
                    mysqli_stmt_bind_param($update_stmt, "si", $param_password, $param_user_id);
                    
                    // Set parameters
                    $param_password = password_hash($new_password, PASSWORD_DEFAULT);
                    $param_user_id = $user_id;
                    
                    if (mysqli_stmt_execute($update_stmt)) {
                        $success_msg = "Password updated successfully!";
                    } else {
                        $_SESSION['error'] = "Oops! Something went wrong. Please try again later.";
                    }
                    
                    // Close the update statement
                    mysqli_stmt_close($update_stmt);
                }
            }
        }
    }
}
?>

<div class="row">
    <div class="col-lg-8 mx-auto">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Profile Information</h6>
            </div>
            <div class="card-body">
                <?php if ($success_msg): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo $success_msg; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="needs-validation" novalidate>
                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="name" class="form-label">Full Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php echo (!empty($name_err)) ? 'is-invalid' : ''; ?>" 
                                   id="name" name="name" value="<?php echo htmlspecialchars($name); ?>" required>
                            <div class="invalid-feedback">
                                <?php echo $name_err ?: 'Please enter your full name.'; ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                            <input type="email" class="form-control <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>" 
                                   id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                            <div class="invalid-feedback">
                                <?php echo $email_err ?: 'Please enter a valid email address.'; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="phone" class="form-label">Phone Number</label>
                        <input type="tel" class="form-control" id="phone" name="phone" 
                               value="<?php echo htmlspecialchars($phone); ?>">
                    </div>
                    
                    <div class="d-flex justify-content-end">
                        <button type="submit" name="update_profile" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i> Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-danger">Change Password</h6>
            </div>
            <div class="card-body">
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="needs-validation" novalidate>
                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                    
                    <div class="mb-3">
                        <label for="current_password" class="form-label">Current Password <span class="text-danger">*</span></label>
                        <input type="password" class="form-control <?php echo (!empty($current_password_err)) ? 'is-invalid' : ''; ?>" 
                               id="current_password" name="current_password" required>
                        <div class="invalid-feedback">
                            <?php echo $current_password_err ?: 'Please enter your current password.'; ?>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="new_password" class="form-label">New Password <span class="text-danger">*</span></label>
                            <input type="password" class="form-control <?php echo (!empty($new_password_err)) ? 'is-invalid' : ''; ?>" 
                                   id="new_password" name="new_password" required>
                            <div class="invalid-feedback">
                                <?php echo $new_password_err ?: 'Please enter a new password (min 6 characters).'; ?>
                            </div>
                            <div class="form-text">Must be at least 6 characters long.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="confirm_password" class="form-label">Confirm New Password <span class="text-danger">*</span></label>
                            <input type="password" class="form-control <?php echo (!empty($confirm_password_err)) ? 'is-invalid' : ''; ?>" 
                                   id="confirm_password" name="confirm_password" required>
                            <div class="invalid-feedback">
                                <?php echo $confirm_password_err ?: 'Please confirm your new password.'; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="d-flex justify-content-end">
                        <button type="submit" name="change_password" class="btn btn-danger">
                            <i class="fas fa-key me-1"></i> Change Password
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
require_once 'includes/footer.php';
?>
