<?php
// Function to get pending orders count
function getPendingOrdersCount($conn) {
    if (!isset($conn) || !$conn) {
        return 0;
    }
    
    $query = "SELECT COUNT(*) as count FROM orders WHERE status = 'pending'";
    $result = mysqli_query($conn, $query);
    
    if ($result && $row = mysqli_fetch_assoc($result)) {
        return (int)$row['count'];
    }
    
    return 0;
}

// Get pending orders count if connection is available
$pending_orders_count = isset($conn) ? getPendingOrdersCount($conn) : 0;
?>
