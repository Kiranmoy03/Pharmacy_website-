<?php
// Initialize the session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in, if not then redirect to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    // Store the current URL in session for redirecting after login
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
    
    // Redirect to login page
    header("location: login.php");
    exit;
}

// Check if user has the required role (admin or staff)
$allowed_roles = ['admin', 'staff'];
if(!in_array($_SESSION['role'], $allowed_roles)){
    // User doesn't have permission
    header("location: 403.php");
    exit;
}

// Check for session timeout (30 minutes of inactivity)
$inactive = 1800; // 30 minutes in seconds
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $inactive)) {
    // Last request was more than 30 minutes ago
    session_unset();     // Unset $_SESSION variable for the run-time 
    session_destroy();   // Destroy session data in storage
    header("Location: login.php?error=session_expired");
    exit;
}
$_SESSION['last_activity'] = time(); // Update last activity time stamp

// Check for CSRF token on POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        // CSRF token validation failed
        die('CSRF token validation failed');
    }
}

// Generate a new CSRF token if one doesn't exist
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
