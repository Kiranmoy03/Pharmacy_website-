<?php
// Function to add a new category
function addCategory($conn, $name, $description) {
    $sql = "INSERT INTO categories (name, description) VALUES (?, ?)";
    if($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "ss", $name, $description);
        $result = mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        return $result;
    }
    return false;
}

// Function to delete a category
function deleteCategory($conn, $category_id) {
    // First, check if there are products in this category
    $check_sql = "SELECT COUNT(*) as product_count FROM products WHERE category_id = ?";
    if($stmt = mysqli_prepare($conn, $check_sql)) {
        mysqli_stmt_bind_param($stmt, "i", $category_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $row = mysqli_fetch_assoc($result);
        
        if($row['product_count'] > 0) {
            return "Cannot delete category. There are products associated with it.";
        }
        
        // Delete the category
        $delete_sql = "DELETE FROM categories WHERE category_id = ?";
        if($delete_stmt = mysqli_prepare($conn, $delete_sql)) {
            mysqli_stmt_bind_param($delete_stmt, "i", $category_id);
            $result = mysqli_stmt_execute($delete_stmt);
            mysqli_stmt_close($delete_stmt);
            return $result ? true : mysqli_error($conn);
        }
        mysqli_stmt_close($stmt);
    }
    return "Error preparing statement";
}

// Function to update category status
// Note: Status functionality is not implemented in the database
// This function is kept for backward compatibility but doesn't modify the database
function updateCategoryStatus($conn, $category_id, $status) {
    // Since status column doesn't exist, we'll just return true to indicate success
    // without actually updating anything in the database
    return true;
}

// Function to get all categories with product count
function getAllCategories($conn) {
    $sql = "SELECT c.category_id, c.name, c.description, c.created_at, 
                   COUNT(p.product_id) as product_count 
            FROM categories c 
            LEFT JOIN products p ON c.category_id = p.category_id 
            GROUP BY c.category_id 
            ORDER BY c.name ASC";
    
    $result = mysqli_query($conn, $sql);
    $categories = [];
    
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            // Add a default status of 'active' for compatibility with the UI
            $row['status'] = 'active';
            $categories[] = $row;
        }
    } else {
        error_log("Error fetching categories: " . mysqli_error($conn));
    }
    
    return $categories;
}

// Function to handle file uploads
function handleFileUpload($file, $target_dir) {
    if(!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    
    $file_extension = strtolower(pathinfo($file["name"], PATHINFO_EXTENSION));
    $new_filename = uniqid() . '.' . $file_extension;
    $target_file = $target_dir . $new_filename;
    
    // Check if file is an actual image
    $check = getimagesize($file["tmp_name"]);
    if($check === false) {
        return ["success" => false, "message" => "File is not an image."];
    }
    
    // Check file type
    $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
    if(!in_array($file_extension, $allowed_types)) {
        return ["success" => false, "message" => "Sorry, only JPG, JPEG, PNG & GIF files are allowed."];
    }
    
    // Try to upload file
    if(move_uploaded_file($file["tmp_name"], $target_file)) {
        return [
            "success" => true, 
            "path" => str_replace("../", "", $target_file),
            "filename" => $new_filename
        ];
    } else {
        return ["success" => false, "message" => "Sorry, there was an error uploading your file."];
    }
}
