<?php
session_start();
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["role"] !== 'admin'){
    header("location: login.php");
    exit;
}

require_once("../config/database.php");

$name = $description = $price = $stock_quantity = $category_id = $manufacturer = $image_url = "";
$name_err = $price_err = $stock_err = $image_err = "";
$success_msg = $error_msg = "";

// Get all categories for the dropdown
$categories = [];
$sql = "SELECT category_id, name FROM categories ORDER BY name";
$result = mysqli_query($conn, $sql);
if($result) {
    while($row = mysqli_fetch_assoc($result)) {
        $categories[] = $row;
    }
}

// Process form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Validate name
    if(empty(trim($_POST["name"]))){
        $name_err = "Please enter a product name.";
    } else{
        $name = trim($_POST["name"]);
    }
    
    // Validate price
    if(empty(trim($_POST["price"])) || !is_numeric(trim($_POST["price"])) || trim($_POST["price"]) <= 0){
        $price_err = "Please enter a valid price.";
    } else{
        $price = trim($_POST["price"]);
    }
    
    // Validate stock quantity
    if(empty(trim($_POST["stock_quantity"])) || !is_numeric(trim($_POST["stock_quantity"])) || trim($_POST["stock_quantity"]) < 0){
        $stock_err = "Please enter a valid stock quantity.";
    } else{
        $stock_quantity = trim($_POST["stock_quantity"]);
    }
    
    // Get other form data
    $description = trim($_POST["description"]);
    $category_id = !empty($_POST["category_id"]) ? (int)$_POST["category_id"] : null;
    $manufacturer = trim($_POST["manufacturer"]);
    $status = !empty($_POST["status"]) ? 'active' : 'inactive';
    
    // Handle file upload
    if(isset($_FILES["image"]) && $_FILES["image"]["error"] == 0) {
        $target_dir = "../uploads/products/";
        
        // Create uploads directory if it doesn't exist
        if(!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        
        $file_extension = strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION));
        $new_filename = uniqid() . '.' . $file_extension;
        $target_file = $target_dir . $new_filename;
        
        // Check if image file is an actual image
        $check = getimagesize($_FILES["image"]["tmp_name"]);
        if($check === false) {
            $image_err = "File is not an image.";
        }
        
        // Check file size (max 2MB)
        if ($_FILES["image"]["size"] > 2000000) {
            $image_err = "Sorry, your file is too large. Maximum size is 2MB.";
        }
        
        // Allow certain file formats
        $allowed_extensions = ["jpg", "jpeg", "png", "gif"];
        if(!in_array($file_extension, $allowed_extensions)) {
            $image_err = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        }
        
        if(empty($image_err)) {
            if(move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                $image_url = "uploads/products/" . $new_filename;
            } else {
                $image_err = "Sorry, there was an error uploading your file.";
            }
        }
    }
    
    // Check input errors before inserting in database
    if(empty($name_err) && empty($price_err) && empty($stock_err) && empty($image_err)){
        // Prepare an insert statement
        $sql = "INSERT INTO products (name, description, price, stock_quantity, category_id, manufacturer, image_url, status) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
         
        if($stmt = mysqli_prepare($conn, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssdiisss", 
                $param_name, 
                $param_description, 
                $param_price, 
                $param_stock, 
                $param_category_id,
                $param_manufacturer,
                $param_image_url,
                $status
            );
            
            // Set parameters
            $param_name = $name;
            $param_description = $description;
            $param_price = $price;
            $param_stock = $stock_quantity;
            $param_category_id = $category_id;
            $param_manufacturer = $manufacturer;
            $param_image_url = $image_url;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                $success_msg = "Product added successfully!";
                // Reset form
                $name = $description = $price = $stock_quantity = $category_id = $manufacturer = $image_url = "";
            } else{
                $error_msg = "Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    } else {
        $error_msg = "Please correct the errors in the form.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Product - Pharmacy Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background: #343a40;
            color: white;
        }
        .sidebar a {
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            padding: 10px 15px;
            display: block;
            transition: all 0.3s;
        }
        .sidebar a:hover, .sidebar a.active {
            color: white;
            background: #495057;
        }
        .preview-image {
            max-width: 200px;
            max-height: 200px;
            margin-top: 10px;
            display: none;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 p-0 sidebar">
                <div class="p-3">
                    <h4 class="text-center">Pharmacy Admin</h4>
                    <hr>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a href="dashboard.php" class="nav-link">
                                <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="products.php" class="nav-link active">
                                <i class="fas fa-pills me-2"></i> Products
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="categories.php" class="nav-link">
                                <i class="fas fa-tags me-2"></i> Categories
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="orders.php" class="nav-link">
                                <i class="fas fa-shopping-cart me-2"></i> Orders
                            </a>
                        </li>
                        <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                        <li class="nav-item">
                            <a href="users.php" class="nav-link">
                                <i class="fas fa-users me-2"></i> Users
                            </a>
                        </li>
                        <?php endif; ?>
                        <li class="nav-item mt-4">
                            <a href="settings.php" class="nav-link">
                                <i class="fas fa-cog me-2"></i> Settings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="logout.php" class="nav-link text-danger">
                                <i class="fas fa-sign-out-alt me-2"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Add New Product</h2>
                    <a href="products.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left me-2"></i>Back to Products
                    </a>
                </div>

                <?php if(!empty($success_msg)): ?>
                    <div class="alert alert-success"><?php echo $success_msg; ?></div>
                <?php endif; ?>
                
                <?php if(!empty($error_msg)): ?>
                    <div class="alert alert-danger"><?php echo $error_msg; ?></div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="mb-3">
                                        <label for="name" class="form-label">Product Name <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control <?php echo (!empty($name_err)) ? 'is-invalid' : ''; ?>" 
                                               id="name" name="name" value="<?php echo $name; ?>">
                                        <span class="invalid-feedback"><?php echo $name_err; ?></span>
                                    </div>

                                    <div class="mb-3">
                                        <label for="description" class="form-label">Description</label>
                                        <textarea class="form-control" id="description" name="description" rows="3"><?php echo $description; ?></textarea>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="price" class="form-label">Price <span class="text-danger">*</span></label>
                                                <div class="input-group">
                                                    <span class="input-group-text">₹</span>
                                                    <input type="number" step="0.01" class="form-control <?php echo (!empty($price_err)) ? 'is-invalid' : ''; ?>" 
                                                           id="price" name="price" value="<?php echo $price; ?>">
                                                    <span class="invalid-feedback"><?php echo $price_err; ?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="stock_quantity" class="form-label">Stock Quantity <span class="text-danger">*</span></label>
                                                <input type="number" class="form-control <?php echo (!empty($stock_err)) ? 'is-invalid' : ''; ?>" 
                                                       id="stock_quantity" name="stock_quantity" value="<?php echo $stock_quantity; ?>">
                                                <span class="invalid-feedback"><?php echo $stock_err; ?></span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="category_id" class="form-label">Category</label>
                                                <select class="form-select" id="category_id" name="category_id">
                                                    <option value="">-- Select Category --</option>
                                                    <?php foreach($categories as $category): ?>
                                                        <option value="<?php echo $category['category_id']; ?>" <?php echo ($category_id == $category['category_id']) ? 'selected' : ''; ?>>
                                                            <?php echo htmlspecialchars($category['name']); ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="manufacturer" class="form-label">Manufacturer</label>
                                                <input type="text" class="form-control" id="manufacturer" name="manufacturer" value="<?php echo $manufacturer; ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="mb-3 form-check">
                                        <input type="checkbox" class="form-check-input" id="status" name="status" value="1" checked>
                                        <label class="form-check-label" for="status">Active</label>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="card">
                                        <div class="card-header">
                                            <h5 class="card-title mb-0">Product Image</h5>
                                        </div>
                                        <div class="card-body text-center">
                                            <div class="mb-3">
                                                <img id="imagePreview" src="#" alt="Preview" class="img-fluid img-thumbnail preview-image">
                                                <div id="noImage" class="p-3 border rounded bg-light">
                                                    <i class="fas fa-image fa-3x text-muted mb-2"></i>
                                                    <p class="mb-0">No image selected</p>
                                                </div>
                                            </div>
                                            <div class="mb-3">
                                                <label for="image" class="form-label">Upload Image</label>
                                                <input class="form-control <?php echo (!empty($image_err)) ? 'is-invalid' : ''; ?>" 
                                                       type="file" id="image" name="image" accept="image/*">
                                                <div class="form-text">Max size: 2MB. Allowed: JPG, JPEG, PNG, GIF</div>
                                                <span class="invalid-feedback"><?php echo $image_err; ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                                <button type="reset" class="btn btn-secondary me-md-2">Reset</button>
                                <button type="submit" class="btn btn-primary">Add Product</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Image preview
        document.getElementById('image').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const preview = document.getElementById('imagePreview');
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                    document.getElementById('noImage').style.display = 'none';
                }
                reader.readAsDataURL(file);
            } else {
                document.getElementById('imagePreview').style.display = 'none';
                document.getElementById('noImage').style.display = 'block';
            }
        });

        // Show success message and redirect after 2 seconds if form was submitted successfully
        <?php if(!empty($success_msg)): ?>
            setTimeout(function() {
                window.location.href = 'products.php';
            }, 2000);
        <?php endif; ?>
    </script>
</body>
</html>
