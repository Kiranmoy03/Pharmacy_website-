<?php
require_once __DIR__ . '/../config/database.php';

// Check database connection
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Get all unique categories from products table
$query = "SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND category != ''";
$result = mysqli_query($conn, $query);

$added = 0;
$errors = [];

while ($row = mysqli_fetch_assoc($result)) {
    $category_name = trim($row['category']);
    
    // Check if category already exists
    $check_sql = "SELECT category_id FROM categories WHERE name = '" . mysqli_real_escape_string($conn, $category_name) . "'";
    $check_result = mysqli_query($conn, $check_sql);
    
    if (mysqli_num_rows($check_result) == 0) {
        // Category doesn't exist, add it
        $insert_sql = "INSERT INTO categories (name) VALUES ('" . 
                     mysqli_real_escape_string($conn, $category_name) . "')";
        
        if (mysqli_query($conn, $insert_sql)) {
            $added++;
            
            // Update the products table with the new category_id
            $new_category_id = mysqli_insert_id($conn);
            $update_sql = "UPDATE products SET category_id = $new_category_id WHERE category = '" . 
                         mysqli_real_escape_string($conn, $category_name) . "'";
            mysqli_query($conn, $update_sql);
        } else {
            $errors[] = "Failed to add category: " . $category_name . " - " . mysqli_error($conn);
        }
    }
}

// Output results
echo "<h2>Category Sync Complete</h2>";
echo "<p>Added $added new categories to the categories table.</p>";

if (!empty($errors)) {
    echo "<h3>Errors:</h3>";
    echo "<ul>";
    foreach ($errors as $error) {
        echo "<li>$error</li>";
    }
    echo "</ul>";
}

echo "<p><a href='categories.php'>Return to Categories</a></p>";
?>
