<?php
session_start();

// Include maintenance check
require_once '../includes/maintenance_check.php';

// Redirect to dashboard if already logged in
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    header('Location: dashboard.php');
    exit;
}

require_once '../config/database.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Debug: Log POST data
    error_log('Login attempt - POST data: ' . print_r($_POST, true));
    
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = 'Invalid request. Please try again.';
        error_log('CSRF token validation failed');
    } else {
        // Validate inputs
        if (empty($_POST['username']) || empty($_POST['password'])) {
            $error = 'Please enter both username and password';
            error_log('Empty username or password');
        } else {
            $username = trim($_POST['username']);
            $password = $_POST['password'];
            
            // Debug: Log username being used for login
            error_log('Attempting login with username: ' . $username);
            
            // Prepare and execute the query
            $sql = "SELECT user_id, username, full_name, email, password, role FROM users WHERE username = ? AND role IN ('admin', 'staff')";
            error_log('SQL Query: ' . $sql . ' | Username: ' . $username);
            
            if ($stmt = mysqli_prepare($conn, $sql)) {
                error_log('Prepared statement created successfully');
                mysqli_stmt_bind_param($stmt, "s", $username);
                
                if (mysqli_stmt_execute($stmt)) {
                    mysqli_stmt_store_result($stmt);
                    $num_rows = mysqli_stmt_num_rows($stmt);
                    error_log('Number of matching users found: ' . $num_rows);
                    
                    if ($num_rows == 1) {
                        mysqli_stmt_bind_result($stmt, $user_id, $username, $full_name, $email, $hashed_password, $role);
                        mysqli_stmt_fetch($stmt);
                        
                        error_log('User found - ID: ' . $user_id . ', Username: ' . $username . ', Role: ' . $role);
                        error_log('Password verification attempt for user: ' . $username);
                        
                        if (password_verify($password, $hashed_password)) {
                            error_log('Password verification successful for user: ' . $username);
                            // Password is correct, start a new session
                            session_regenerate_id();
                            
                            // Store data in session variables
                            $_SESSION['loggedin'] = true;
                            $_SESSION['user_id'] = $user_id;
                            $_SESSION['username'] = $username;
                            $_SESSION['name'] = $full_name;
                            $_SESSION['email'] = $email;
                            $_SESSION['role'] = $role;
                            
                            // Record login time
                            $_SESSION['last_login'] = time();
                            
                            // Redirect to dashboard
                            header('Location: dashboard.php');
                            exit;
                        } else {
                            // Password is not valid
                            $error = 'Invalid username or password';
                            error_log('Password verification failed for user: ' . $username);
                        }
                    } else {
                        // Username doesn't exist
                        $error = 'Invalid username or password';
                    }
                } else {
                    $error = 'Oops! Something went wrong. Please try again later.';
                }
                
                // Close statement
                mysqli_stmt_close($stmt);
            } else {
                $error = 'Database connection error';
            }
        }
    }
}

// Generate a new CSRF token if one doesn't exist
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Pharmacy Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            height: 100vh;
            display: flex;
            align-items: center;
        }
        .login-container {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .login-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .login-logo i {
            font-size: 50px;
            color: #0d6efd;
        }
        .form-floating {
            margin-bottom: 1rem;
        }
        .btn-login {
            padding: 10px;
            font-size: 1.1rem;
        }
    </style>
</head>
<body class="bg-light">
    <div class="container">
        <div class="login-container">
            <div class="login-logo">
                <i class="fas fa-pills"></i>
                <h2 class="mt-3">Pharmacy Admin</h2>
                <p class="text-muted">Sign in to start your session</p>
            </div>
            
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="" novalidate>
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="username" name="username" placeholder="Enter your username" 
                           value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>" required>
                    <label for="username">Username</label>
                </div>
                
                <div class="form-floating mb-4">
                    <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                    <label for="password">Password</label>
                </div>
                
                <div class="d-grid">
                    <button type="submit" class="btn btn-primary btn-login">
                        <i class="fas fa-sign-in-alt me-2"></i>Sign In
                    </button>
                </div>
                
                <div class="text-center mt-3">
                    <a href="forgot-password.php" class="text-decoration-none">Forgot your password?</a>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Disable form submissions if there are invalid fields
        (function () {
            'use strict';
            
            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.querySelectorAll('.needs-validation');
            
            // Loop over them and prevent submission
            Array.prototype.slice.call(forms)
                .forEach(function (form) {
                    form.addEventListener('submit', function (event) {
                        if (!form.checkValidity()) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        
                        form.classList.add('was-validated');
                    }, false);
                });
        })();
    </script>
</body>
</html>
