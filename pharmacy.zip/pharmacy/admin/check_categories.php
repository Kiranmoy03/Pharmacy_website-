<?php
require_once __DIR__ . '/../config/database.php';

// Check database connection
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// List all tables in the database
$tables = [];
$result = mysqli_query($conn, "SHOW TABLES");
while ($row = mysqli_fetch_array($result)) {
    $tables[] = $row[0];
}

echo "<h3>Available Tables:</h3>";
echo "<pre>";
print_r($tables);
echo "</pre>";

// Check if categories table exists
if (in_array('categories', $tables)) {
    echo "<h3>Categories Table Structure:</h3>";
    $result = mysqli_query($conn, "DESCRIBE categories");
    echo "<table border='1'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['Field'] . "</td>";
        echo "<td>" . $row['Type'] . "</td>";
        echo "<td>" . $row['Null'] . "</td>";
        echo "<td>" . $row['Key'] . "</td>";
        echo "<td>" . $row['Default'] . "</td>";
        echo "<td>" . $row['Extra'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";

    // Check if there are any categories
    $result = mysqli_query($conn, "SELECT COUNT(*) as count FROM categories");
    $row = mysqli_fetch_assoc($result);
    $count = $row['count'];
    
    echo "<h3>Categories Count: $count</h3>";
    
    if ($count > 0) {
        echo "<h3>Sample Categories (first 5):</h3>";
        $result = mysqli_query($conn, "SELECT * FROM categories LIMIT 5");
        echo "<pre>";
        while ($row = mysqli_fetch_assoc($result)) {
            print_r($row);
        }
        echo "</pre>";
    }
} else {
    echo "<h3>Error: Categories table does not exist!</h3>";
}

// Check products table structure
if (in_array('products', $tables)) {
    echo "<h3>Products Table Structure (relevant columns):</h3>";
    $result = mysqli_query($conn, "DESCRIBE products");
    echo "<table border='1'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    while ($row = mysqli_fetch_assoc($result)) {
        if (in_array($row['Field'], ['id', 'name', 'category_id', 'status'])) {
            echo "<tr>";
            echo "<td>" . $row['Field'] . "</td>";
            echo "<td>" . $row['Type'] . "</td>";
            echo "<td>" . $row['Null'] . "</td>";
            echo "<td>" . $row['Key'] . "</td>";
            echo "<td>" . $row['Default'] . "</td>";
            echo "<td>" . $row['Extra'] . "</td>";
            echo "</tr>";
        }
    }
    echo "</table>
</body>
</html>";
}
?>
