<?php
// Start session and include database configuration
session_start();
require_once '../config/database.php';
require_once '../includes/settings_functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Set page title
$page_title = 'Settings';

// Include header
require_once 'includes/header.php';

// Initialize variables
$success_msg = $error_msg = '';

// Generate CSRF token if not exists
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Default values
$default_settings = [
    'items_per_page' => '10',
    'maintenance_mode' => '0'
];

// Get current settings with fallback to defaults
$items_per_page = getSetting($conn, 'items_per_page', $default_settings['items_per_page']);
$maintenance_mode = getSetting($conn, 'maintenance_mode', $default_settings['maintenance_mode']);

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error_msg = 'Invalid request. Please try again.';
    } else {
        $update_errors = [];
        

        // Update items per page
        if (isset($_POST['items_per_page'])) {
            $new_items_per_page = (int)$_POST['items_per_page'];
            if ($new_items_per_page > 0) {
                if (updateSetting($conn, 'items_per_page', $new_items_per_page)) {
                    $items_per_page = $new_items_per_page;
                } else {
                    $update_errors[] = 'Failed to update items per page';
                }
            }
        }
        
        // Update maintenance mode
        $new_maintenance_mode = isset($_POST['maintenance_mode']) ? '1' : '0';
        if (updateSetting($conn, 'maintenance_mode', $new_maintenance_mode)) {
            $maintenance_mode = $new_maintenance_mode;
        } else {
            $update_errors[] = 'Failed to update maintenance mode';
        }
        
        if (empty($update_errors)) {
            $success_msg = 'Settings updated successfully!';
        } else {
            $error_msg = 'Some settings could not be updated: ' . implode(', ', $update_errors);
        }
    }
}
?>

<div class="row">
    <div class="col-lg-8 mx-auto">
        <?php if ($success_msg): ?>
            <div class="alert alert-success"><?php echo $success_msg; ?></div>
        <?php endif; ?>
        
        <?php if ($error_msg): ?>
            <div class="alert alert-danger"><?php echo $error_msg; ?></div>
        <?php endif; ?>
        
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Application Settings</h6>
            </div>
            <div class="card-body">
                <form action="settings.php" method="post">
                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
<div class="mb-3">
                        <label for="items_per_page" class="form-label">Items Per Page</label>
                        <select class="form-select" id="items_per_page" name="items_per_page">
                            <option value="10" <?php echo $items_per_page == '10' ? 'selected' : ''; ?>>10 items</option>
                            <option value="25" <?php echo $items_per_page == '25' ? 'selected' : ''; ?>>25 items</option>
                            <option value="50" <?php echo $items_per_page == '50' ? 'selected' : ''; ?>>50 items</option>
                            <option value="100" <?php echo $items_per_page == '100' ? 'selected' : ''; ?>>100 items</option>
                        </select>
                    </div>
                    
                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input" type="checkbox" id="maintenance_mode" name="maintenance_mode" <?php echo $maintenance_mode == '1' ? 'checked' : ''; ?>>
                        <label class="form-check-label" for="maintenance_mode">
                            Enable Maintenance Mode
                        </label>
                    </div>
                    
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <button type="submit" class="btn btn-primary">Save Settings</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
require_once 'includes/footer.php';
?>
