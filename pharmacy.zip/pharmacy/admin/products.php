<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in and is admin
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["role"] !== 'admin') {
    header("location: login.php");
    exit;
}

// Include database configuration
require_once "../config/database.php";

// Set page title
$page_title = 'Manage Products';

$success_msg = $error_msg = "";

// Handle product deletion
if(isset($_POST['delete_product'])) {
    $product_id = $_POST['product_id'];
    
    // First, get the image path to delete the file
    $sql = "SELECT image_url as image FROM products WHERE product_id = ?";
    if($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "i", $product_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $product = mysqli_fetch_assoc($result);
        
        if($product && !empty($product['image']) && file_exists("../" . $product['image'])) {
            unlink("../" . $product['image']);
        }
        mysqli_stmt_close($stmt);
    }
    
    // Delete the product
    $sql = "DELETE FROM products WHERE product_id = ?";
    if($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "i", $product_id);
        if(mysqli_stmt_execute($stmt)) {
            $success_msg = "Product deleted successfully.";
        } else {
            $error_msg = "Error deleting product: " . mysqli_error($conn);
        }
        mysqli_stmt_close($stmt);
    }
}

// Update product status (active/inactive)
if(isset($_POST['update_status'])) {
    $product_id = $_POST['product_id'];
    $status = $_POST['status'];
    
    $sql = "UPDATE products SET status = ? WHERE product_id = ?";
    if($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "si", $status, $product_id);
        if(mysqli_stmt_execute($stmt)) {
            $success_msg = "Product status updated successfully.";
        } else {
            $error_msg = "Error updating product status: " . mysqli_error($conn);
        }
        mysqli_stmt_close($stmt);
    }
}

// Fetch all products with category name
$sql = "SELECT p.*, c.name as category_name 
        FROM products p 
        LEFT JOIN categories c ON p.category_id = c.category_id 
        ORDER BY p.created_at DESC";
$products = mysqli_query($conn, $sql);

// Include header after session and database are set up
require_once 'includes/header.php';
?>

<!-- Main Content -->
<div class="container-fluid">
    <div class="row">
        <div class="col-md-10 p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Manage Products</h2>
                    <a href="add_product.php" class="btn btn-primary">
                        <i class="fas fa-plus me-2"></i>Add New Product
                    </a>
                </div>

                <?php if($success_msg): ?>
                    <div class="alert alert-success"><?php echo $success_msg; ?></div>
                <?php endif; ?>
                
                <?php if($error_msg): ?>
                    <div class="alert alert-danger"><?php echo $error_msg; ?></div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Image</th>
                                        <th>Name</th>
                                        <th>Category</th>
                                        <th>Price</th>
                                        <th>Stock</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($product = mysqli_fetch_assoc($products)): ?>
                                    <tr>
                                        <td>
                                            <?php 
                                            $image_path = !empty($product['image_url']) ? $product['image_url'] : '';
                                            $full_image_path = !empty($image_path) ? '../' . $image_path : '';
                                            $image_exists = !empty($image_path) && file_exists($full_image_path);
                                            ?>
                                            <?php if($image_exists): ?>
                                                <img src="<?php echo htmlspecialchars($full_image_path); ?>" 
                                                     alt="<?php echo htmlspecialchars($product['name']); ?>" 
                                                     class="img-thumbnail" 
                                                     style="width: 50px; height: 50px; object-fit: cover;">
                                            <?php else: ?>
                                                <div class="bg-light d-flex align-items-center justify-content-center" 
                                                     style="width: 50px; height: 50px; border: 1px solid #dee2e6; border-radius: 0.25rem;">
                                                    <i class="fas fa-pills text-muted"></i>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <strong><?php echo htmlspecialchars($product['name']); ?></strong><br>
                                            <small class="text-muted">SKU: <?php echo $product['sku'] ?? 'N/A'; ?></small>
                                        </td>
                                        <td><?php echo htmlspecialchars($product['category_name'] ?? 'Uncategorized'); ?></td>
                                        <td>₹<?php echo number_format($product['price'], 2); ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo $product['stock_quantity'] > 0 ? 'success' : 'danger'; ?>">
                                                <?php echo $product['stock_quantity']; ?> in stock
                                            </span>
                                        </td>
                                        <td>
                                            <form method="post" class="d-inline">
                                                <input type="hidden" name="product_id" value="<?php echo $product['product_id']; ?>">
                                                <input type="hidden" name="status" value="<?php echo $product['status'] == 'active' ? 'inactive' : 'active'; ?>">
                                                <button type="submit" name="update_status" class="btn btn-sm btn-<?php echo $product['status'] == 'active' ? 'success' : 'secondary'; ?> btn-sm">
                                                    <?php echo ucfirst($product['status'] ?? 'active'); ?>
                                                </button>
                                            </form>
                                        </td>
                                        <td>
                                            <a href="edit_product.php?id=<?php echo $product['product_id']; ?>" class="btn btn-sm btn-primary">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <form method="post" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this product? This action cannot be undone.');">
                                                <input type="hidden" name="product_id" value="<?php echo $product['product_id']; ?>">
                                                <button type="submit" name="delete_product" class="btn btn-sm btn-danger">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>
</div>

<!-- Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Additional Scripts -->
<script>
// Delete confirmation
function confirmDelete() {
    return confirm('Are you sure you want to delete this product? This action cannot be undone.');
}
</script>

<?php include 'includes/footer.php'; ?>
