<?php
require_once("../config/database.php");

// Add role column if it doesn't exist
$sql = "ALTER TABLE users 
        ADD COLUMN IF NOT EXISTS role ENUM('admin', 'staff', 'user') DEFAULT 'user',
        ADD COLUMN IF NOT EXISTS status ENUM('active', 'inactive') DEFAULT 'active'";

if (mysqli_query($conn, $sql)) {
    echo "Users table updated successfully with role and status columns.<br>";
    
    // Create admin user if not exists
    $admin_email = "admin@pharmacy.com";
    $admin_password = password_hash("admin123", PASSWORD_DEFAULT);
    
    $check_sql = "SELECT id FROM users WHERE email = ?";
    $stmt = mysqli_prepare($conn, $check_sql);
    mysqli_stmt_bind_param($stmt, "s", $admin_email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if (mysqli_num_rows($result) == 0) {
        $insert_sql = "INSERT INTO users (email, password, full_name, phone, role) 
                     VALUES (?, ?, 'Admin User', '0000000000', 'admin')";
        $stmt = mysqli_prepare($conn, $insert_sql);
        mysqli_stmt_bind_param($stmt, "ss", $admin_email, $admin_password);
        
        if (mysqli_stmt_execute($stmt)) {
            echo "Admin user created successfully.<br>";
            echo "Email: admin@pharmacy.com<br>";
            echo "Password: admin123<br>";
        } else {
            echo "Error creating admin user: " . mysqli_error($conn) . "<br>";
        }
    } else {
        echo "Admin user already exists.<br>";
    }
    
    echo "<a href='users.php'>Go to Users Management</a>";
} else {
    echo "Error updating users table: " . mysqli_error($conn) . "<br>";
}
?>
