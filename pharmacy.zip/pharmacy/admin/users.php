<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include required files
require_once __DIR__ . '/includes/auth_check.php';
require_once __DIR__ . '/../config/database.php';

// Include header after session and database are set up
require_once 'includes/header.php';

$success_msg = $error_msg = "";

// Handle user status toggle
if(isset($_POST['toggle_status'])) {
    $user_id = (int)$_POST['user_id'];
    $new_status = $_POST['current_status'] === 'active' ? 'inactive' : 'active';
    
    $sql = "UPDATE users SET status = ? WHERE id = ?";
    
    if($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "si", $new_status, $user_id);
        if(mysqli_stmt_execute($stmt)) {
            $success_msg = "User status updated successfully.";
        } else {
            $error_msg = "Error updating user status: " . mysqli_error($conn);
        }
        mysqli_stmt_close($stmt);
    }
}

// Handle user role update
if(isset($_POST['update_role'])) {
    $user_id = (int)$_POST['user_id'];
    $new_role = $_POST['role'];
    
    $sql = "UPDATE users SET role = ? WHERE user_id = ?";
    
    if($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "si", $new_role, $user_id);
        if(mysqli_stmt_execute($stmt)) {
            $success_msg = "User role updated successfully.";
        } else {
            $error_msg = "Error updating user role: " . mysqli_error($conn);
        }
        mysqli_stmt_close($stmt);
    }
}

// Handle user deletion
if(isset($_POST['delete_user'])) {
    $user_id = (int)$_POST['user_id'];
    
    // Prevent deleting the current admin user
    if($user_id === (int)$_SESSION['user_id']) {
        $error_msg = "You cannot delete your own account while logged in.";
    } else {
        // First, verify the user exists
        $check_user = "SELECT user_id FROM users WHERE user_id = ? LIMIT 1";
        $user_exists = false;
        
        if($stmt = mysqli_prepare($conn, $check_user)) {
            mysqli_stmt_bind_param($stmt, "i", $user_id);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
            $user_exists = mysqli_stmt_num_rows($stmt) > 0;
            mysqli_stmt_close($stmt);
        }
        
        if(!$user_exists) {
            $error_msg = "User not found.";
        } else {
            // Temporarily disable foreign key checks
            mysqli_query($conn, "SET FOREIGN_KEY_CHECKS = 0");
            
            // Delete user directly
            $sql = "DELETE FROM users WHERE user_id = ?";
            $success = false;
            
            if($stmt = mysqli_prepare($conn, $sql)) {
                mysqli_stmt_bind_param($stmt, "i", $user_id);
                if(mysqli_stmt_execute($stmt)) {
                    if(mysqli_affected_rows($conn) > 0) {
                        $success = true;
                        $success_msg = "User deleted successfully.";
                    } else {
                        $error_msg = "No rows were deleted. User may not exist.";
                    }
                } else {
                    $error_msg = "Error deleting user: " . mysqli_error($conn);
                }
                mysqli_stmt_close($stmt);
            } else {
                $error_msg = "Error preparing statement: " . mysqli_error($conn);
            }
            
            // Re-enable foreign key checks
            mysqli_query($conn, "SET FOREIGN_KEY_CHECKS = 1");
            
            // If deletion was successful, clean up any orphaned records
            if($success) {
                $tables_to_clean = [
                    'orders', 'cart', 'reviews', 'prescriptions', 
                    'wishlist', 'notifications', 'user_addresses'
                ];
                
                // Get list of all tables in the database
                $result = mysqli_query($conn, "SHOW TABLES");
                $existing_tables = [];
                while($row = mysqli_fetch_row($result)) {
                    $existing_tables[] = $row[0];
                }
                
                foreach($tables_to_clean as $table) {
                    // Only proceed if table exists
                    if(in_array($table, $existing_tables)) {
                        // Check if table has user_id column
                        $check_column = mysqli_query($conn, "SHOW COLUMNS FROM $table LIKE 'user_id'");
                        if(mysqli_num_rows($check_column) > 0) {
                            $clean_sql = "DELETE FROM $table WHERE user_id = ? AND NOT EXISTS (SELECT 1 FROM users WHERE user_id = $table.user_id)";
                            if($stmt = mysqli_prepare($conn, $clean_sql)) {
                                mysqli_stmt_bind_param($stmt, "i", $user_id);
                                @mysqli_stmt_execute($stmt); // Suppress any errors
                                mysqli_stmt_close($stmt);
                            }
                        }
                    }
                }
            }
        }
    }
}

// Fetch all users with pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

// Get total number of users
$count_sql = "SELECT COUNT(*) as total FROM users";
$count_result = mysqli_query($conn, $count_sql);
$total_users = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_users / $per_page);

// Check if status and role columns exist
$check_columns = [];
$result = mysqli_query($conn, "SHOW COLUMNS FROM users");
while($row = mysqli_fetch_assoc($result)) {
    $check_columns[strtolower($row['Field'])] = true;
}

$select_fields = [
    'user_id as id',
    'full_name as name',
    'email',
    'phone',
    isset($check_columns['role']) ? 'role' : "'user' as role",
    isset($check_columns['status']) ? 'status' : "'active' as status",
    "DATE_FORMAT(created_at, '%b %d, %Y') as join_date"
];

// Fetch users for current page
$sql = "SELECT " . implode(", ", $select_fields) . " 
        FROM users 
        ORDER BY created_at DESC 
        LIMIT ? OFFSET ?";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ii", $per_page, $offset);
mysqli_stmt_execute($stmt);
$users = mysqli_stmt_get_result($stmt);
?>

<!-- Main Content -->
<div class="container-fluid">
    <div class="row">
        <!-- Main Content Area -->
        <div class="col-md-12 p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="mb-0">User Management</h2>
                </div>
                <a href="add_user.php" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i> Add New User
                </a>
            </div>

            <?php if($success_msg): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i> <?php echo $success_msg; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if($error_msg): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error_msg; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">All Users</h5>
                    <div class="input-group" style="width: 300px;">
                        <span class="input-group-text bg-white border-end-0"><i class="fas fa-search"></i></span>
                        <input type="text" class="form-control border-start-0" placeholder="Search users...">
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-4">USER</th>
                                    <th>EMAIL</th>
                                    <th>PHONE</th>
                                    <th>ROLE</th>
                                    <th>STATUS</th>
                                    <th>JOINED</th>
                                    <th class="text-end pe-4">ACTIONS</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(mysqli_num_rows($users) > 0): ?>
                                    <?php while($user = mysqli_fetch_assoc($users)): ?>
                                        <tr>
                                            <td class="ps-4">
                                                <div class="d-flex align-items-center">
                                                    <div class="avatar me-3 bg-light rounded-circle text-dark d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                                        <i class="fas fa-user"></i>
                                                    </div>
                                                    <div>
                                                        <div class="fw-medium"><?php echo htmlspecialchars($user['name']); ?></div>
                                                        <small class="text-muted">ID: <?php echo $user['id']; ?></small>
                                                    </div>
                                                </div>
                                            </td>
                                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                                            <td><?php echo $user['phone'] ? htmlspecialchars($user['phone']) : 'N/A'; ?></td>
                                            <td>
                                                <form method="post" class="d-inline">
                                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                    <select name="role" class="form-select form-select-sm d-inline-block w-auto" onchange="this.form.submit()" style="min-width: 100px;">
                                                        <option value="admin" <?php echo $user['role'] === 'admin' ? 'selected' : ''; ?>>Admin</option>
                                                        <option value="staff" <?php echo $user['role'] === 'staff' ? 'selected' : ''; ?>>Staff</option>
                                                        <option value="user" <?php echo !in_array($user['role'], ['admin', 'staff']) ? 'selected' : ''; ?>>User</option>
                                                    </select>
                                                    <input type="hidden" name="update_role" value="1">
                                                </form>
                                            </td>
                                            <td>
                                                <form method="post" class="d-inline">
                                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                    <input type="hidden" name="current_status" value="<?php echo $user['status']; ?>">
                                                    <button type="submit" name="toggle_status" class="btn btn-sm btn-link p-0 border-0 bg-transparent">
                                                        <span class="badge rounded-pill bg-<?php echo $user['status'] === 'active' ? 'success' : 'danger'; ?> bg-opacity-10 text-<?php echo $user['status'] === 'active' ? 'success' : 'danger'; ?> p-2">
                                                            <i class="fas fa-circle me-1" style="font-size: 0.5rem;"></i>
                                                            <?php echo ucfirst($user['status']); ?>
                                                        </span>
                                                    </button>
                                                </form>
                                            </td>
                                            <td><?php echo $user['join_date'] ?? 'N/A'; ?></td>
                                            <td class="text-end pe-4">
                                                <div class="btn-group">
                                                    <a href="edit_user.php?id=<?php echo $user['id']; ?>" class="btn btn-sm btn-outline-primary" data-bs-toggle="tooltip" title="Edit">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <button type="button" class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#deleteUserModal<?php echo $user['id']; ?>" title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>

                                        <!-- Delete Confirmation Modal -->
                                        <div class="modal fade" id="deleteUserModal<?php echo $user['id']; ?>" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Confirm Deletion</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p>Are you sure you want to delete <strong><?php echo htmlspecialchars($user['name']); ?></strong>? This action cannot be undone.</p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                        <form method="post" class="d-inline">
                                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                            <button type="submit" name="delete_user" class="btn btn-danger">
                                                                <i class="fas fa-trash me-1"></i> Delete
                                                            </button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="7" class="text-center py-4">
                                            <div class="text-muted">
                                                <i class="fas fa-users fa-3x mb-3"></i>
                                                <p class="mb-0">No users found</p>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php if($total_pages > 1): ?>
                    <div class="card-footer d-flex justify-content-between align-items-center">
                        <div class="text-muted">
                            Showing <span class="fw-semibold"><?php echo min(($page - 1) * $per_page + 1, $total_users); ?></span> to 
                            <span class="fw-semibold"><?php echo min($page * $per_page, $total_users); ?></span> of 
                            <span class="fw-semibold"><?php echo $total_users; ?></span> users
                        </div>
                        <nav aria-label="Page navigation">
                            <ul class="pagination mb-0">
                                <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $page - 1; ?>" aria-label="Previous">
                                        <span aria-hidden="true">&laquo;</span>
                                    </a>
                                </li>
                                <?php for($i = 1; $i <= $total_pages; $i++): ?>
                                    <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                        <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                                    </li>
                                <?php endfor; ?>
                                <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $page + 1; ?>" aria-label="Next">
                                        <span aria-hidden="true">&raquo;</span>
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Include page-specific scripts if any -->
<?php if (isset($page_scripts)) echo $page_scripts; ?>

<!-- Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Custom scripts -->
<script>
// Enable tooltips
var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
});
</script>

<!-- Include footer -->
<?php require_once 'includes/footer.php'; ?>
