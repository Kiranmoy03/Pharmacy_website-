<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database and functions
require_once '../config/database.php';
require_once '../includes/functions.php';

// Check if user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    // Store the current URL in session for redirecting after login
    $_SESSION['redirect_url'] = 'orders.php';
    header("Location: login.php");
    exit();
}

// Check if user has admin or staff role
$allowed_roles = ['admin', 'staff'];
if (!in_array($_SESSION['role'], $allowed_roles)) {
    // User doesn't have permission
    header("Location: 403.php");
    exit();
}

// Handle order status update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && isset($_POST['order_id'])) {
    $order_id = $_POST['order_id'];
    
    if ($_POST['action'] == 'deliver') {
        $sql = "UPDATE orders SET status = 'completed', delivered_at = NOW() WHERE order_id = ?";
    } elseif ($_POST['action'] == 'process') {
        $sql = "UPDATE orders SET status = 'processing' WHERE order_id = ?";
    }
    
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $order_id);
    mysqli_stmt_execute($stmt);
    
    header("Location: orders.php?success=Order status updated successfully");
    exit();
}

// Get all orders
$sql = "SELECT o.*, u.full_name, u.address, u.phone 
        FROM orders o 
        JOIN users u ON o.user_id = u.user_id 
        ORDER BY o.created_at DESC";
$result = mysqli_query($conn, $sql);
$orders = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Manage Orders - PharmaMed</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'header.php'; ?>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5>Manage Orders</h5>
                        <?php if (isset($_GET['success'])): ?>
                            <div class="alert alert-success"><?php echo $_GET['success']; ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Order ID</th>
                                        <th>Customer</th>
                                        <th>Contact</th>
                                        <th>Total Amount</th>
                                        <th>Status</th>
                                        <th>Created At</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($orders as $order): ?>
                                        <tr>
                                            <td>#<?php echo $order['order_id']; ?></td>
                                            <td>
                                                <strong><?php echo htmlspecialchars($order['full_name']); ?></strong><br>
                                                <small><?php echo nl2br(htmlspecialchars($order['address'])); ?></small>
                                            </td>
                                            <td><?php echo htmlspecialchars($order['phone']); ?></td>
                                            <td>₹<?php echo number_format($order['total_amount'], 2); ?></td>
                                            <td>
                                                <span class="badge bg-<?php 
                                                    echo $order['status'] == 'cancelled' ? 'danger' : 
                                                           ($order['status'] == 'returned' ? 'warning' : 
                                                            ($order['status'] == 'completed' ? 'success' : 'primary'));
                                                ?>">
                                                    <?php 
                                                    echo ucfirst($order['status'] == 'completed' ? 'Delivered' : 
                                                               ($order['status'] == 'cancelled' ? 'Cancelled' : 
                                                                ($order['status'] == 'returned' ? 'Returned' : 
                                                                 ($order['status'] == 'pending' ? 'Pending' : 'Processing'))));
                                                    ?>
                                                </span>
                                            </td>
                                            <td><?php echo date('F j, Y H:i', strtotime($order['created_at'])); ?></td>
                                            <td>
                                                <div class="btn-group">
                                                    <a href="admin_order_details.php?order_id=<?php echo $order['order_id']; ?>" 
                                                       class="btn btn-sm btn-info" title="View Order Details">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    <?php if ($order['status'] == 'pending'): ?>
                                                        <form method="POST" action="" style="display: inline;">
                                                            <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                                            <input type="hidden" name="action" value="process">
                                                            <button type="submit" class="btn btn-sm btn-primary">
                                                                <i class="fas fa-truck"></i>
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>
                                                    <?php if ($order['status'] == 'processing'): ?>
                                                        <form method="POST" action="" style="display: inline;">
                                                            <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                                            <input type="hidden" name="action" value="deliver">
                                                            <button type="submit" class="btn btn-sm btn-success">
                                                                <i class="fas fa-check"></i>
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include '../includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/main.js"></script>
</body>
</html>
