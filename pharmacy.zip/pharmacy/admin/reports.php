<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database configuration first
require_once "../config/database.php";

// Check if user is logged in and is admin
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["role"] !== 'admin') {
    header("location: login.php");
    exit;
}

// Set page title
$page_title = 'Reports';

// Include header after session and database are set up
require_once 'includes/header.php';

// Set default date range (last 30 days)
$end_date = date('Y-m-d');
$start_date = date('Y-m-d', strtotime('-30 days'));

// Handle date filter
if(isset($_GET['start_date']) && isset($_GET['end_date'])) {
    $start_date = $_GET['start_date'];
    $end_date = $_GET['end_date'];
}

// Format currency to Indian Rupees
function formatINR($amount) {
    return '₹' . number_format($amount, 2);
}

// 1. Sales Summary
$sales_sql = "SELECT 
                COUNT(DISTINCT o.order_id) as total_orders,
                SUM(oi.quantity) as total_items_sold,
                SUM(oi.price * oi.quantity) as total_revenue,
                AVG(oi.price * oi.quantity) as avg_order_value
              FROM orders o
              JOIN order_items oi ON o.order_id = oi.order_id
              WHERE o.status = 'completed'
              AND DATE(o.created_at) BETWEEN ? AND ?";

$sales_stmt = mysqli_prepare($conn, $sales_sql);
mysqli_stmt_bind_param($sales_stmt, "ss", $start_date, $end_date);
mysqli_stmt_execute($sales_stmt);
$sales_result = mysqli_stmt_get_result($sales_stmt);
$sales_summary = mysqli_fetch_assoc($sales_result);
mysqli_stmt_close($sales_stmt);

// 2. Top Selling Products
$top_products_sql = "SELECT 
                      p.name, 
                      p.product_id as sku,
                      SUM(oi.quantity) as total_quantity,
                      SUM(oi.price * oi.quantity) as total_revenue
                    FROM order_items oi
                    JOIN products p ON oi.product_id = p.product_id
                    JOIN orders o ON oi.order_id = o.order_id
                    WHERE o.status = 'completed'
                    AND DATE(o.created_at) BETWEEN ? AND ?
                    GROUP BY oi.product_id
                    ORDER BY total_quantity DESC
                    LIMIT 5";

// 3. Low Stock Alert (products with quantity < 10)
$low_stock_sql = "SELECT 
                   product_id,
                   name,
                   product_id as sku,
                   stock_quantity as quantity
                 FROM products 
                 WHERE stock_quantity < 10
                 ORDER BY stock_quantity ASC
                 LIMIT 5";
$low_stock_result = mysqli_query($conn, $low_stock_sql);

// 4. Recent Orders
$recent_orders_sql = "SELECT 
                       o.order_id as order_number,
                       u.full_name,
                       o.total_amount,
                       o.status
                     FROM orders o
                     LEFT JOIN users u ON o.user_id = u.user_id
                     ORDER BY o.created_at DESC
                     LIMIT 5";
$recent_orders_result = mysqli_query($conn, $recent_orders_sql);

// 5. Sales by Category
$category_sales_sql = "SELECT 
                        p.category as category_name,
                        COUNT(DISTINCT oi.order_id) as order_count,
                        COALESCE(SUM(oi.quantity), 0) as total_quantity,
                        COALESCE(SUM(oi.price * oi.quantity), 0) as total_revenue
                      FROM products p
                      LEFT JOIN order_items oi ON p.product_id = oi.product_id
                      LEFT JOIN orders o ON oi.order_id = o.order_id
                      WHERE o.status = 'completed'
                      AND (DATE(o.created_at) BETWEEN ? AND ?)
                      GROUP BY p.category
                      ORDER BY total_revenue DESC";

$category_sales_stmt = mysqli_prepare($conn, $category_sales_sql);
mysqli_stmt_bind_param($category_sales_stmt, "ss", $start_date, $end_date);
mysqli_stmt_execute($category_sales_stmt);
$category_sales_result = mysqli_stmt_get_result($category_sales_stmt);

// 6. Customer Activity
$customer_activity_sql = "SELECT 
                           u.user_id,
                           u.full_name,
                           u.email,
                           COUNT(o.order_id) as total_orders,
                           COALESCE(SUM(o.total_amount), 0) as total_spent
                         FROM users u
                         LEFT JOIN orders o ON u.user_id = o.user_id AND o.status = 'completed'
                         GROUP BY u.user_id, u.full_name, u.email
                         HAVING total_orders > 0
                         ORDER BY total_spent DESC
                         LIMIT 5";

// Execute all queries with proper parameter binding
$top_products_stmt = mysqli_prepare($conn, $top_products_sql);
mysqli_stmt_bind_param($top_products_stmt, "ss", $start_date, $end_date);
mysqli_stmt_execute($top_products_stmt);
$top_products_result = mysqli_stmt_get_result($top_products_stmt);

// Execute customer activity query (no parameters needed)
$customer_activity_result = mysqli_query($conn, $customer_activity_sql);

// Prepare and execute category sales query
$category_sales_stmt = mysqli_prepare($conn, $category_sales_sql);
mysqli_stmt_bind_param($category_sales_stmt, "ss", $start_date, $end_date);
mysqli_stmt_execute($category_sales_stmt);
$category_sales = mysqli_stmt_get_result($category_sales_stmt);

// Get daily sales data for chart
$daily_sales_sql = "SELECT 
                     DATE(created_at) as sale_date,
                     COUNT(DISTINCT order_id) as order_count,
                     COALESCE(SUM(total_amount), 0) as daily_revenue
                   FROM orders
                   WHERE status = 'completed'
                   AND DATE(created_at) BETWEEN ? AND ?
                   GROUP BY DATE(created_at)
                   ORDER BY sale_date ASC";

$daily_sales_stmt = mysqli_prepare($conn, $daily_sales_sql);
mysqli_stmt_bind_param($daily_sales_stmt, "ss", $start_date, $end_date);
mysqli_stmt_execute($daily_sales_stmt);
$daily_sales_result = mysqli_stmt_get_result($daily_sales_stmt);

// Prepare data for the chart
$chart_labels = [];
$chart_data = [];
$chart_orders = [];

while($row = mysqli_fetch_assoc($daily_sales_result)) {
    $chart_labels[] = date('M d', strtotime($row['sale_date']));
    $chart_data[] = $row['daily_revenue'];
    $chart_orders[] = $row['order_count'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - Pharmacy Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .stat-card {
            border-radius: 10px;
            transition: transform 0.3s;
            height: 100%;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        .stat-card .card-body {
            padding: 1.5rem;
        }
        .stat-card .card-title {
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 0.5rem;
            opacity: 0.8;
        }
        .stat-card .card-value {
            font-size: 1.75rem;
            font-weight: 700;
            margin: 0.5rem 0;
        }
        .stat-card .card-change {
            font-size: 0.8rem;
            display: flex;
            align-items: center;
        }
        .stat-card .card-change i {
            margin-right: 0.25rem;
        }
        .card {
            margin-bottom: 1.5rem;
            border: none;
            box-shadow: 0 0.125rem 0.25rem rgba(0,0,0,0.075);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 0.5rem 1rem rgba(0,0,0,0.1);
        }
        .card-header {
            background-color: #fff;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            padding: 1rem 1.25rem;
            font-weight: 600;
        }
        .table th {
            border-top: none;
            font-weight: 600;
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: #6c757d;
        }
        .table td {
            vertical-align: middle;
        }
        .revenue {
            font-weight: 600;
            color: #2e59d9;
        }
        .status-completed {
            background-color: #d4edda;
            color: #155724;
            padding: 0.25rem 0.5rem;
            border-radius: 0.25rem;
            font-size: 0.75rem;
            font-weight: 600;
        }
        .status-pending {
            background-color: #fff3cd;
            color: #856404;
            padding: 0.25rem 0.5rem;
            border-radius: 0.25rem;
            font-size: 0.75rem;
            font-weight: 600;
        }
        .status-cancelled {
            background-color: #f8d7da;
            color: #721c24;
            padding: 0.25rem 0.5rem;
            border-radius: 0.25rem;
            font-size: 0.75rem;
            font-weight: 600;
        }
    </style>
</head>
<!-- Main Content -->
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar is included from header.php -->
        <div class="col-md-10 p-4">
            <div class="d-flex justify-content-end mb-3">
                <div>
                    <a href="generate_pdf.php?start_date=<?php echo htmlspecialchars($start_date); ?>&end_date=<?php echo htmlspecialchars($end_date); ?>" class="btn btn-outline-primary btn-sm export-pdf-btn" id="exportPdfBtn">
                        <i class="fas fa-file-pdf me-2"></i>Export PDF
                    </a>
                    <button class="btn btn-outline-success btn-sm ms-2 export-excel-btn" onclick="exportToExcel()">
                        <i class="fas fa-file-excel me-2"></i>Export Excel
                    </button>
                </div>
            </div>
            <!-- Date Filter -->
            <div class="card">
                <div class="card-body">
                    <form method="GET" class="row g-3">
                        <div class="col-md-4">
                            <label for="start_date" class="form-label">Start Date</label>
                            <input type="date" class="form-control" id="start_date" name="start_date" value="<?php echo $start_date; ?>">
                        </div>
                        <div class="col-md-4">
                            <label for="end_date" class="form-label">End Date</label>
                            <input type="date" class="form-control" id="end_date" name="end_date" value="<?php echo $end_date; ?>">
                        </div>
                        <div class="col-md-4 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-filter me-2"></i>Filter
                            </button>
                            <a href="reports.php" class="btn btn-outline-secondary ms-2">
                                <i class="fas fa-sync-alt me-2"></i>Reset
                            </a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Summary Cards -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="card bg-primary text-white stat-card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="text-uppercase">Total Orders</h6>
                                    <h3 class="mb-0"><?php echo number_format($sales_summary['total_orders']); ?></h3>
                                </div>
                                <div class="stat-icon">
                                    <i class="fas fa-shopping-bag"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-success text-white stat-card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="text-uppercase">Items Sold</h6>
                                    <h3 class="mb-0"><?php echo number_format($sales_summary['total_items_sold']); ?></h3>
                                </div>
                                <div class="stat-icon">
                                    <i class="fas fa-box"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-info text-white stat-card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="text-uppercase">Total Revenue</h6>
                                    <div class="card-value"><?php echo formatINR($sales_summary['total_revenue'] ?? 0); ?></div>
                                </div>
                                <div class="stat-icon">
                                    <i class="fas fa-rupee-sign"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-warning text-white stat-card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="text-uppercase">Avg. Order Value</h6>
                                    <div class="card-value"><?php echo formatINR($sales_summary['avg_order_value'] ?? 0); ?></div>
                                </div>
                                <div class="stat-icon">
                                    <i class="fas fa-chart-line"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Top Selling Products -->
                <div class="col-md-6">
                    <div class="card h-100">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="card-title mb-0">Top Selling Products</h5>
                            <a href="products.php" class="btn btn-sm btn-outline-primary">View All</a>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead>
                                        <tr>
                                            <th>Product</th>
                                            <th>SKU</th>
                                            <th>Qty Sold</th>
                                            <th>Revenue</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($product = mysqli_fetch_assoc($top_products_result)): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($product['name']); ?></td>
                                            <td><?php echo htmlspecialchars($product['sku']); ?></td>
                                            <td><?php echo number_format($product['total_quantity']); ?></td>
                                            <td class="revenue"><?php echo formatINR($product['total_revenue']); ?></td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Low Stock Alert -->
                <div class="col-md-6">
                    <div class="card h-100">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="card-title mb-0">Low Stock Alert</h5>
                            <a href="products.php?filter=low_stock" class="btn btn-sm btn-outline-danger">View All</a>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead>
                                        <tr>
                                            <th>Product</th>
                                            <th>SKU</th>
                                            <th>Stock</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($product = mysqli_fetch_assoc($low_stock_result)): 
                                            $status_class = $product['quantity'] < 5 ? 'bg-danger' : 'bg-warning';
                                            $status_text = $product['quantity'] < 5 ? 'Critical' : 'Low';
                                        ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($product['name']); ?></td>
                                            <td><?php echo htmlspecialchars($product['sku']); ?></td>
                                            <td><?php echo $product['quantity']; ?></td>
                                            <td><span class="badge <?php echo $status_class; ?> text-white"><?php echo $status_text; ?></span></td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mt-4">
                <!-- Recent Orders -->
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="card-title mb-0">Recent Orders</h5>
                            <a href="orders.php" class="btn btn-sm btn-outline-primary">View All</a>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead>
                                        <tr>
                                            <th>Order #</th>
                                            <th>Customer</th>
                                            <th>Amount</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($order = mysqli_fetch_assoc($recent_orders_result)): 
                                            $status_class = '';
                                            if($order['status'] === 'completed') $status_class = 'status-completed';
                                            elseif($order['status'] === 'pending') $status_class = 'status-pending';
                                            else $status_class = 'status-cancelled';
                                        ?>
                                        <tr>
                                            <td>#<?php echo $order['order_number']; ?></td>
                                            <td><?php echo htmlspecialchars($order['full_name'] ?? 'Guest'); ?></td>
                                            <td><?php echo formatINR($order['total_amount']); ?></td>
                                            <td><span class="badge <?php echo $status_class; ?>"><?php echo ucfirst($order['status']); ?></span></td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Customer Activity -->
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Top Customers</h5>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead>
                                        <tr>
                                            <th>Customer</th>
                                            <th>Email</th>
                                            <th>Orders</th>
                                            <th>Total Spent</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($customer = mysqli_fetch_assoc($customer_activity_result)): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($customer['full_name']); ?></td>
                                            <td><?php echo htmlspecialchars($customer['email']); ?></td>
                                            <td><?php echo $customer['total_orders']; ?></td>
                                            <td class="revenue"><?php echo formatINR($customer['total_spent']); ?></td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mt-4">
                <!-- Sales by Category -->
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Sales by Category</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="table-responsive">
                                        <table class="table table-hover mb-0">
                                            <thead class="table-light">
                                                <tr>
                                                    <th>Category</th>
                                                    <th class="text-end">Orders</th>
                                                    <th class="text-end">Qty</th>
                                                    <th class="text-end">Revenue</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                $category_data = [];
                                                mysqli_data_seek($category_sales_result, 0); // Reset pointer
                                                if(mysqli_num_rows($category_sales_result) > 0): 
                                                    while($category = mysqli_fetch_assoc($category_sales_result)): 
                                                        $category_data[] = $category;
                                                ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($category['category_name']); ?></td>
                                                    <td class="text-end"><?php echo number_format($category['order_count']); ?></td>
                                                    <td class="text-end"><?php echo number_format($category['total_quantity']); ?></td>
                                                    <td class="text-end"><?php echo formatINR($category['total_revenue']); ?></td>
                                                </tr>
                                                <?php 
                                                    endwhile;
                                                else: 
                                                ?>
                                                <tr>
                                                    <td colspan="4" class="text-center py-4">No data available</td>
                                                </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <canvas id="categoryChart" height="300"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Additional Scripts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
    
<script>
    // Format number to Indian Rupees
    function formatINR(amount) {
        return '₹' + parseFloat(amount).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
    }

    // Wait for DOM to be fully loaded
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize Category Chart if element exists
            if (categoryChartEl) {
                const categoryCtx = categoryChartEl.getContext('2d');
                
                // Get category data from the table
                const categoryLabels = [];
                const categoryData = [];
                const categoryColors = [
                    '#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', 
                    '#e74a3b', '#6c757d', '#858796', '#5a5c69'
                ];
                
                // Extract data from the table
                document.querySelectorAll('#categoryChart + .table tbody tr').forEach(row => {
                    const cells = row.cells;
                    if (cells.length >= 2) {
                        categoryLabels.push(cells[0].textContent);
                        // Remove $ and commas, then convert to number
                        const value = parseFloat(cells[1].textContent.replace(/[^0-9.-]+/g, ''));
                        categoryData.push(value);
                    }
                });

                // Create the chart
                new Chart(categoryCtx, {
                    type: 'doughnut',
                    data: {
                        labels: categoryLabels,
                        datasets: [{
                            data: categoryData,
                            backgroundColor: categoryColors.slice(0, categoryData.length),
                            borderWidth: 0,
                            hoverOffset: 10
                        }]
                    },
                    options: {
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'right',
                                labels: {
                                    boxWidth: 15,
                                    padding: 15,
                                    usePointStyle: true,
                                    pointStyle: 'circle'
                                }
                            },
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        const label = context.label || '';
                                        const value = context.raw || 0;
                                        const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                        const percentage = Math.round((value / total) * 100);
                                        return `${label}: $${value.toLocaleString()} (${percentage}%)`;
                                    }
                                }
                            }
                        },
                        cutout: '70%',
                        animation: {
                            animateScale: true,
                            animateRotate: true
                        }
                    }
                });
            }
        });

        // Add loading state to PDF export button
        document.getElementById('exportPdfBtn').addEventListener('click', function(e) {
            const btn = this;
            const originalHTML = btn.innerHTML;
            
            // Show loading state
            btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Generating...';
            btn.classList.add('disabled');
            
            // Re-enable button after 5 seconds in case the download doesn't start
            setTimeout(() => {
                btn.innerHTML = originalHTML;
                btn.classList.remove('disabled');
            }, 5000);
        });

        // Export to Excel
        function exportToExcel() {
            // Show loading state
            const originalText = document.querySelector('.export-excel-btn i').nextSibling.textContent;
            document.querySelector('.export-excel-btn').innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Generating...';
            document.querySelector('.export-excel-btn').disabled = true;

            try {
                // Create a new workbook
                const wb = XLSX.utils.book_new();
                
                // Process each card as a separate worksheet
                document.querySelectorAll('.card').forEach((card, index) => {
                    const header = card.querySelector('.card-title');
                    if (!header) return;
                    
                    const title = header.textContent.trim();
                    const table = card.querySelector('table');
                    
                    if (table) {
                        // Clone the table to avoid modifying the original
                        const tableCopy = table.cloneNode(true);
                        
                        // Clean up the table (remove any buttons, etc.)
                        tableCopy.querySelectorAll('a, button').forEach(el => el.remove());
                        
                        // Convert table to worksheet
                        const ws = XLSX.utils.table_to_sheet(tableCopy);
                        
                        // Add worksheet to workbook
                        XLSX.utils.book_append_sheet(wb, ws, title.substring(0, 31)); // Sheet name max 31 chars
                    } else if (card.querySelector('.chart-container')) {
                        // Handle charts - export as data table
                        const chartTitle = title;
                        const chartData = [];
                        
                        // This is a simplified example - you'd need to extract data from your chart
                        // For now, we'll just add a placeholder
                        chartData.push([chartTitle]);
                        chartData.push(['Category', 'Value']);
                        
                        // Add some sample data - replace with actual chart data extraction
                        const chart = card.querySelector('canvas');
                        if (chart) {
                            // In a real implementation, you would extract data from the chart
                            // For now, we'll just add a note
                            chartData.push(['Note', 'Chart data export not fully implemented']);
                            chartData.push(['Please use PDF export for charts', '']);
                        }
                        
                        const ws = XLSX.utils.aoa_to_sheet(chartData);
                        XLSX.utils.book_append_sheet(wb, ws, `Chart_${index + 1}`.substring(0, 31));
                    }
                });
                
                // Generate Excel file and trigger download
                XLSX.writeFile(wb, `pharmacy-report-${new Date().toISOString().split('T')[0]}.xlsx`);
                
            } catch (error) {
                console.error('Error generating Excel:', error);
                alert('Error generating Excel file. Please try again.');
            } finally {
                // Restore button state
                document.querySelector('.export-excel-btn').innerHTML = '<i class="fas fa-file-excel me-2"></i>' + originalText;
                document.querySelector('.export-excel-btn').disabled = false;
            }
        }
    </script>
<?php include 'includes/footer.php'; ?>
