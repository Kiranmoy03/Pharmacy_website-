-- Add verification_status column if it doesn't exist
ALTER TABLE `prescriptions` 
ADD COLUMN IF NOT EXISTS `verification_status` ENUM('pending', 'verifying', 'verified', 'unavailable') NOT NULL DEFAULT 'pending' 
AFTER `status`;
