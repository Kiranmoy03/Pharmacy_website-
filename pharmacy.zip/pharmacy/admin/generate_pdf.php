<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in and is admin
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["role"] !== 'admin') {
    header("HTTP/1.1 403 Forbidden");
    exit('Access Denied');
}

// Include database configuration
require_once "../config/database.php";

// Get date range from GET parameters
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d', strtotime('-30 days'));
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');

// 1. Sales Summary
$sales_sql = "SELECT 
                COUNT(DISTINCT o.order_id) as total_orders,
                SUM(oi.quantity) as total_items_sold,
                SUM(oi.price * oi.quantity) as total_revenue,
                AVG(oi.price * oi.quantity) as avg_order_value
              FROM orders o
              JOIN order_items oi ON o.order_id = oi.order_id
              WHERE o.status = 'completed'
              AND DATE(o.created_at) BETWEEN ? AND ?";

$sales_stmt = mysqli_prepare($conn, $sales_sql);
mysqli_stmt_bind_param($sales_stmt, "ss", $start_date, $end_date);
mysqli_stmt_execute($sales_stmt);
$sales_result = mysqli_stmt_get_result($sales_stmt);
$sales_summary = mysqli_fetch_assoc($sales_result);

// 2. Top Selling Products
$top_products_sql = "SELECT 
                    p.name,
                    SUM(oi.quantity) as total_quantity,
                    SUM(oi.price * oi.quantity) as total_revenue
                  FROM order_items oi
                  JOIN products p ON oi.product_id = p.product_id
                  JOIN orders o ON oi.order_id = o.order_id
                  WHERE o.status = 'completed'
                  AND DATE(o.created_at) BETWEEN ? AND ?
                  GROUP BY p.product_id
                  ORDER BY total_quantity DESC
                  LIMIT 5";

$top_products_stmt = mysqli_prepare($conn, $top_products_sql);
mysqli_stmt_bind_param($top_products_stmt, "ss", $start_date, $end_date);
mysqli_stmt_execute($top_products_stmt);
$top_products_result = mysqli_stmt_get_result($top_products_stmt);

// Create HTML content
$html = '<!DOCTYPE html>
<html>
<head>
    <title>Sales Report</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; }
        .header { text-align: center; margin-bottom: 20px; }
        .title { font-size: 18px; font-weight: bold; margin-bottom: 5px; }
        .subtitle { font-size: 14px; color: #555; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th { background-color: #f5f5f5; text-align: left; padding: 8px; border: 1px solid #ddd; }
        td { padding: 8px; border: 1px solid #ddd; }
        .summary { margin-bottom: 20px; }
        .summary p { margin: 5px 0; }
    </style>
</head>
<body>
    <div class="header">
        <div class="title">Pharmacy Management System</div>
        <div class="subtitle">Sales Report</div>
        <div>Date: ' . date('Y-m-d') . '</div>
        <div>Period: ' . date('M d, Y', strtotime($start_date)) . ' to ' . date('M d, Y', strtotime($end_date)) . '</div>
    </div>

    <div class="summary">
        <h3>Sales Summary</h3>
        <p>Total Orders: ' . $sales_summary['total_orders'] . '</p>
        <p>Total Items Sold: ' . $sales_summary['total_items_sold'] . '</p>
        <p>Total Revenue: $' . number_format($sales_summary['total_revenue'], 2) . '</p>
        <p>Average Order Value: $' . number_format($sales_summary['avg_order_value'], 2) . '</p>
    </div>

    <h3>Top Selling Products</h3>
    <table>
        <tr>
            <th>Product</th>
            <th>Quantity Sold</th>
            <th>Revenue</th>
        </tr>';

// Add top products to HTML
while ($row = mysqli_fetch_assoc($top_products_result)) {
    $html .= '<tr>';
    $html .= '<td>' . htmlspecialchars($row['name']) . '</td>';
    $html .= '<td>' . $row['total_quantity'] . '</td>';
    $html .= '<td>$' . number_format($row['total_revenue'], 2) . '</td>';
    $html .= '</tr>';
}

$html .= '</table>
</body>
</html>';

// Close database connections
mysqli_stmt_close($sales_stmt);
mysqli_stmt_close($top_products_stmt);
mysqli_close($conn);

// Set headers for download
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="sales_report_' . date('Y-m-d') . '.xls"');
header('Pragma: no-cache');
header('Expires: 0');

// Output HTML as Excel
echo $html;
?>
