<?php
// Redirect to the original dashboard
header('Location: dashboard.php');
exit;
?>
