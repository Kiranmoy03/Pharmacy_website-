<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?redirect=payment.php");
    exit();
}

// Get cart items and calculate total
$user_id = $_SESSION['user_id'];
$sql = "SELECT c.*, p.name, p.price, p.image_url 
        FROM cart c 
        JOIN products p ON c.product_id = p.product_id 
        WHERE c.user_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$cart_items = mysqli_fetch_all($result, MYSQLI_ASSOC);
$total = 0;
foreach ($cart_items as $item) {
    $total += $item['price'] * $item['quantity'];
}

// Get user profile
$user = getUserProfile($user_id);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment - PharmaMed</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .payment-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }
        .payment-method {
            border: 2px solid #ddd;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .payment-method:hover {
            border-color: #e74c3c;
        }
        .payment-method.selected {
            border-color: #e74c3c;
            background-color: #fff;
        }
        .payment-form {
            display: none;
        }
        .payment-form.active {
            display: block;
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container mt-4">
        <div class="row">
            <!-- Order Summary -->
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h5>Order Summary</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Price</th>
                                        <th>Quantity</th>
                                        <th>Subtotal</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($cart_items as $item): ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <img src="<?php echo $item['image_url']; ?>" 
                                                         alt="<?php echo $item['name']; ?>" 
                                                         style="width: 50px; height: 50px; object-fit: cover;">
                                                    <div class="ms-3">
                                                        <h6 class="mb-0"><?php echo $item['name']; ?></h6>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>₹<?php echo $item['price']; ?></td>
                                            <td><?php echo $item['quantity']; ?></td>
                                            <td>₹<?php echo $item['price'] * $item['quantity']; ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="3" class="text-end"><strong>Total:</strong></td>
                                        <td><strong>₹<?php echo $total; ?></strong></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Payment Methods -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h5>Payment Methods</h5>
                    </div>
                    <div class="card-body">
                        <div id="paymentMethods">
                            <div class="payment-method" data-method="card">
                                <i class="fas fa-credit-card fa-2x mb-2"></i>
                                <h6>Credit/Debit Card</h6>
                            </div>
                            <div class="payment-method" data-method="upi">
                                <i class="fas fa-qrcode fa-2x mb-2"></i>
                                <h6>UPI Payment</h6>
                            </div>
                            <div class="payment-method" data-method="cod">
                                <i class="fas fa-cash-register fa-2x mb-2"></i>
                                <h6>Cash on Delivery</h6>
                            </div>
                        </div>

                        <!-- Card Payment Form -->
                        <div id="cardForm" class="payment-form">
                            <form action="includes/process_payment.php" method="POST">
                                <input type="hidden" name="payment_method" value="card">
                                <input type="hidden" name="total_amount" value="<?php echo $total; ?>">
                                <div class="mb-3">
                                    <label for="cardNumber" class="form-label">Card Number</label>
                                    <input type="text" class="form-control" id="cardNumber" name="card_number" required>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="expiryDate" class="form-label">Expiry Date</label>
                                        <input type="text" class="form-control" id="expiryDate" name="expiry_date" placeholder="MM/YY" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="cvv" class="form-label">CVV</label>
                                        <input type="password" class="form-control" id="cvv" name="cvv" required>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary">Make Payment</button>
                            </form>
                        </div>

                        <!-- UPI Payment Form -->
                        <div id="upiForm" class="payment-form">
                            <form action="includes/process_payment.php" method="POST">
                                <input type="hidden" name="payment_method" value="upi">
                                <input type="hidden" name="total_amount" value="<?php echo $total; ?>">
                                
                                <div class="mb-3">
                                    <label for="upiVerify" class="form-label">Verify UPI Payment</label>
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="upiVerify" name="upi_verify" 
                                               placeholder="Enter UPI transaction ID">
                                        <button class="btn btn-outline-secondary" type="button" id="verifyBtn">Verify</button>
                                    </div>
                                </div>
                                
                                <div id="verificationStatus" class="mb-3"></div>
                                
                                <button type="submit" class="btn btn-primary" id="upiSubmit" disabled>Complete Payment</button>
                            </form>
                        </div>

                        <!-- COD Form -->
                        <div id="codForm" class="payment-form">
                            <form action="includes/process_payment.php" method="POST">
                                <input type="hidden" name="payment_method" value="cod">
                                <input type="hidden" name="total_amount" value="<?php echo $total; ?>">
                                <div class="alert alert-info">
                                    <i class="fas fa-info-circle"></i> You will pay cash when the order is delivered.
                                </div>
                                <button type="submit" class="btn btn-primary">Place Order</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Shipping Address -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5>Shipping Address</h5>
                    </div>
                    <div class="card-body">
                        <h6><?php echo htmlspecialchars($user['full_name']); ?></h6>
                        <p><?php echo htmlspecialchars($user['address']); ?></p>
                        <p>Phone: <?php echo htmlspecialchars($user['phone']); ?></p>
                        <a href="profile.php" class="btn btn-link">Edit Address</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Payment method selection
        document.querySelectorAll('.payment-method').forEach(method => {
            method.addEventListener('click', function() {
                // Remove selected class from all methods
                document.querySelectorAll('.payment-method').forEach(m => m.classList.remove('selected'));
                
                // Add selected class to clicked method
                this.classList.add('selected');
                
                // Hide all payment forms
                document.querySelectorAll('.payment-form').forEach(form => form.classList.remove('active'));
                
                // Show corresponding payment form
                const method = this.dataset.method;
                document.getElementById(`${method}Form`).classList.add('active');
            });
        });

        // Auto-select first payment method
        document.querySelector('.payment-method').click();
    </script>
</body>
</html>
