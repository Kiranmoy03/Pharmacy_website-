<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - PharmaMed</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Custom styles for about page */
        .about-hero {
            background: linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%);
            padding: 4rem 0;
            margin-bottom: 3rem;
            border-radius: 0 0 20px 20px;
        }
        
        .about-hero h1 {
            color: #1c7430;
            font-weight: 700;
            margin-bottom: 1.5rem;
        }
        
        .about-card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            height: 100%;
            border-top: 4px solid #1c7430;
        }
        
        .about-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(28, 116, 48, 0.15);
        }
        
        .about-card .card-body {
            padding: 2rem;
        }
        
        .about-card i {
            color: #1c7430;
            margin-bottom: 1.5rem;
            font-size: 2.5rem;
        }
        
        .about-card h5 {
            color: #1c7430;
            font-weight: 600;
            margin-bottom: 1rem;
        }
        
        .team-card {
            border: none;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            margin-bottom: 1.5rem;
        }
        
        .team-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(28, 116, 48, 0.15);
        }
        
        .team-card .card-body {
            padding: 1.5rem;
            text-align: center;
        }
        
        .team-card h5 {
            color: #1c7430;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .team-card .text-muted {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .section-title {
            color: #1c7430;
            font-weight: 600;
            margin-bottom: 2rem;
            position: relative;
            padding-bottom: 0.5rem;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            left: 0;
            bottom: 0;
            width: 60px;
            height: 3px;
            background-color: #1c7430;
            border-radius: 2px;
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <!-- Hero Section -->
    <div class="about-hero">
        <div class="container">
            <h1 class="text-center">About PharmaMed</h1>
            <p class="lead text-center mx-auto" style="max-width: 700px; color: #2e7d32;">
                Your trusted partner in healthcare, providing quality medicines and healthcare products with care and compassion.
            </p>
        </div>
    </div>

    <div class="container">
        <!-- Mission & Vision -->
        <div class="row align-items-center mb-5">
            <div class="col-lg-6 mb-4 mb-lg-0">
                <div class="about-card h-100">
                    <div class="card-body">
                        <i class="fas fa-bullseye"></i>
                        <h3 class="section-title">Our Mission</h3>
                        <p class="mb-0">At PharmaMed, our mission is to provide quality healthcare products and services to our customers. We aim to make healthcare accessible and convenient for everyone, ensuring that quality medicines are just a click away.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="about-card h-100">
                    <div class="card-body">
                        <i class="fas fa-eye"></i>
                        <h3 class="section-title">Our Vision</h3>
                        <p class="mb-0">We envision a world where healthcare is easily accessible to all, and we strive to be a trusted partner in everyone's healthcare journey, providing reliable and affordable healthcare solutions.</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Features -->
        <h3 class="section-title text-center mt-5">Why Choose Us</h3>
        <div class="row g-4 mb-5">
            <div class="col-md-4">
                <div class="about-card h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-shield-alt"></i>
                        <h5>Quality Assurance</h5>
                        <p class="mb-0">All our products are sourced from trusted manufacturers and go through rigorous quality checks to ensure your safety and satisfaction.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="about-card h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-truck"></i>
                        <h5>Fast Delivery</h5>
                        <p class="mb-0">We ensure quick and reliable delivery of your healthcare products right to your doorstep, because your health can't wait.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="about-card h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-headset"></i>
                        <h5>24/7 Support</h5>
                        <p class="mb-0">Our dedicated customer support team is available round the clock to assist you with any queries or concerns you may have.</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Team Section -->
        <h3 class="section-title text-center mt-5">Our Team</h3>
        <div class="row g-4 mb-5">
            <div class="col-md-3 col-6">
                <div class="team-card">
                    <div class="card-body">
                        <div class="mb-3" style="width: 100px; height: 100px; background: #e8f5e9; border-radius: 50%; margin: 0 auto 1rem; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-user-md" style="font-size: 2.5rem; color: #1c7430;"></i>
                        </div>
                        <h5>Karun Gogoi</h5>
                        <p class="text-muted mb-0">CEO & Founder</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="team-card">
                    <div class="card-body">
                        <div class="mb-3" style="width: 100px; height: 100px; background: #e8f5e9; border-radius: 50%; margin: 0 auto 1rem; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-pills" style="font-size: 2.5rem; color: #1c7430;"></i>
                        </div>
                        <h5>Rumi Gogoi</h5>
                        <p class="text-muted mb-0">Chief Pharmacist</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="team-card">
                    <div class="card-body">
                        <div class="mb-3" style="width: 100px; height: 100px; background: #e8f5e9; border-radius: 50%; margin: 0 auto 1rem; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-bullhorn" style="font-size: 2.5rem; color: #1c7430;"></i>
                        </div>
                        <h5>Ujjal Dutta</h5>
                        <p class="text-muted mb-0">Marketing Head</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="team-card">
                    <div class="card-body">
                        <div class="mb-3" style="width: 100px; height: 100px; background: #e8f5e9; border-radius: 50%; margin: 0 auto 1rem; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-cogs" style="font-size: 2.5rem; color: #1c7430;"></i>
                        </div>
                        <h5>Progyan Sharma</h5>
                        <p class="text-muted mb-0">Operations Manager</p>
                    </div>
                </div>
            </div>
        </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>
