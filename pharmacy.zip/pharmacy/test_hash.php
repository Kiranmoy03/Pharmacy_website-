<?php
echo "<h2>PHP Version: " . phpversion() . "</h2>";
echo "<h3>Hashing 'admin123':</h3>";
echo password_hash('admin123', PASSWORD_DEFAULT);
?>
