<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?redirect=profile.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['order_id'])) {
    $order_id = $_POST['order_id'];
    
    // Check if the order belongs to the current user
    $sql = "SELECT * FROM orders WHERE order_id = ? AND user_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ii", $order_id, $_SESSION['user_id']);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $order = mysqli_fetch_assoc($result);
    
    if ($order && ($order['status'] != 'completed' && $order['status'] != 'cancelled')) {
        if (cancelOrder($order_id)) {
            header("Location: profile.php?success=Order cancelled successfully");
            exit();
        } else {
            header("Location: profile.php?error=Failed to cancel order");
            exit();
        }
    } else {
        header("Location: profile.php?error=Invalid order or cannot cancel completed/cancelled order");
        exit();
    }
} else {
    header("Location: profile.php?error=Invalid request");
    exit();
}
?>
