<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

// Get products with optional category and search filters
$category = isset($_GET['category']) ? trim($_GET['category']) : '';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Prepare the base query
$sql = "SELECT * FROM products WHERE 1=1";
$params = [];

// Add category filter if provided
if (!empty($category)) {
    $sql .= " AND category = ?";
    $params[] = $category;
}

// Add search filter if provided
if (!empty($search)) {
    $sql .= " AND (name LIKE ? OR description LIKE ? OR category LIKE ?)";
    $searchTerm = "%$search%";
    $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm]);
}

// Add sorting
$sql .= " ORDER BY name";

// Prepare and execute the query with parameters to prevent SQL injection
$stmt = mysqli_prepare($conn, $sql);
if (!empty($params)) {
    $types = str_repeat('s', count($params));
    mysqli_stmt_bind_param($stmt, $types, ...$params);
}
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$products = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - PharmaMed</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Active state for category items */
        .list-group-item.active {
            background-color: #e8f5e9 !important;
            color: #1c7430 !important;
            border-left: 3px solid #1c7430 !important;
            font-weight: 500;
        }
        
        /* Product card styles */
        .product-card {
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            overflow: hidden;
            transition: all 0.3s ease;
            background: white;
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            border-color: #a5d6a7;
        }
        
        .product-card img {
            width: 100%;
            height: 180px;
            object-fit: contain;
            padding: 15px;
            background: #f8f9fa;
        }
        
        .product-card h3 {
            font-size: 1.1rem;
            margin: 10px 15px 5px;
            color: #1c7430;
            font-weight: 600;
        }
        
        .product-card .price {
            color: #1c7430;
            font-size: 1.25rem;
            font-weight: 700;
            margin: 0 15px 10px;
        }
        
        .product-info {
            padding: 0 15px;
            margin-bottom: 15px;
            flex-grow: 1;
        }
        
        .product-info p {
            margin-bottom: 5px;
            color: #666;
            font-size: 0.9rem;
        }
        
        .product-card .btn-primary {
            background-color: #1c7430;
            border-color: #1c7430;
            border-radius: 0 0 8px 8px;
            padding: 8px;
            width: 100%;
            transition: all 0.3s ease;
        }
        
        .product-card .btn-primary:hover {
            background-color: #155724;
            border-color: #155724;
        }
    </style>
</head>
<body class="products-page">
    <?php include 'includes/header.php'; ?>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <div class="card" style="border: none; box-shadow: 0 2px 10px rgba(0,0,0,0.05); overflow: hidden;">
                    <div class="card-header" style="background-color: #1c7430; color: white; border-bottom: none; padding: 12px 15px; font-weight: 600;">
                        <h5 class="mb-0">Categories</h5>
                    </div>
                    <div class="list-group" style="border-radius: 0;">
                        <?php
                        $categories = array(
                            'All', 'Pain Relief', 'Digestive', 'Respiratory',
                            'Antibiotics', 'Supplements', 'Eye Care', 'First Aid'
                        );
                        foreach ($categories as $cat):
                        ?>
                            <a href="products.php?category=<?php echo ($cat == 'All') ? '' : $cat; ?>"
                               class="list-group-item list-group-item-action <?php echo ($category == $cat) ? 'active' : ''; ?>"
                               style="border: none; border-left: 3px solid transparent; padding: 10px 15px; color: #495057; transition: all 0.2s ease; background-color: #f8f9fa; text-decoration: none;"
                               onmouseover="this.style.backgroundColor='#e8f5e9'; this.style.borderLeftColor='#a5d6a7'; this.style.color='#1c7430'"
                               onmouseout="if(!this.classList.contains('active')) {this.style.backgroundColor='#f8f9fa'; this.style.borderLeftColor='transparent'; this.style.color='#495057'}">
                                <?php echo $cat; ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <div class="row">
                    <?php foreach ($products as $product): ?>
                        <div class="col-md-4 mb-4">
                            <div class="product-card">
                                <img src="<?php echo $product['image_url']; ?>" alt="<?php echo $product['name']; ?>">
                                <h3><?php echo $product['name']; ?></h3>
                                <p class="price">₹<?php echo $product['price']; ?></p>
                                <div class="product-info">
                                    <p class="category"><?php echo $product['category']; ?></p>
                                    <p class="stock"><?php echo $product['stock_quantity']; ?> in stock</p>
                                </div>
                                <button class="btn btn-primary add-to-cart" data-product-id="<?php echo $product['product_id']; ?>">
                                    Add to Cart
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>
