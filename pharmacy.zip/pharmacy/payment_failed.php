<?php
require_once 'config/database.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$error_message = 'Payment processing failed. Please try again.';
if (isset($_GET['error'])) {
    switch ($_GET['error']) {
        case 'payment_verification_failed':
            $error_message = 'Payment verification failed. Please contact support.';
            break;
        case 'payment_processing_error':
            $error_message = 'An error occurred while processing your payment.';
            break;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Failed - PharmaMed</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-8 text-center">
                <div class="card">
                    <div class="card-body p-5">
                        <div class="mb-4">
                            <div class="error-icon">
                                <i class="fas fa-times-circle text-danger" style="font-size: 80px;"></i>
                            </div>
                        </div>
                        <h2 class="text-danger mb-3">Payment Failed</h2>
                        <p class="lead"><?php echo $error_message; ?></p>
                        <p>Your order was not processed due to the payment failure.</p>
                        <div class="mt-4">
                            <a href="checkout.php" class="btn btn-primary me-2">
                                Try Again
                            </a>
                            <a href="contact.php" class="btn btn-outline-secondary me-2">
                                Contact Support
                            </a>
                            <a href="index.php" class="btn btn-outline-secondary">
                                Continue Shopping
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
