<?php
// Include database configuration
require_once '../config/database.php';

// Run all migration files in the migrations directory
$migration_dir = __DIR__ . '/migrations';
$migration_files = glob($migration_dir . '/*.php');

if (empty($migration_files)) {
    die("No migration files found in the migrations directory.\n");
}

// Sort files by name (they should be prefixed with numbers to control order)
sort($migration_files);

echo "Starting database migrations...\n\n";

foreach ($migration_files as $file) {
    $filename = basename($file);
    echo "Running migration: $filename\n";
    
    // Include the migration file
    include $file;
    
    echo "\n";
}

echo "All migrations completed successfully.\n";
?>
