<?php
// Create settings table if it doesn't exist
$sql = "CREATE TABLE IF NOT EXISTS settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(50) NOT NULL UNIQUE,
    setting_value TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

// Execute the query
if (mysqli_query($conn, $sql)) {
    // Insert default settings if they don't exist
    $default_settings = [
        ['site_name', 'Pharmacy Management System'],
        ['items_per_page', '10'],
        ['maintenance_mode', '0']
    ];
    
    foreach ($default_settings as $setting) {
        $key = $setting[0];
        $value = $setting[1];
        
        // Check if setting exists
        $check_sql = "SELECT id FROM settings WHERE setting_key = ?";
        $stmt = mysqli_prepare($conn, $check_sql);
        mysqli_stmt_bind_param($stmt, "s", $key);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        
        if (mysqli_num_rows($result) === 0) {
            // Insert default setting
            $insert_sql = "INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)";
            $stmt = mysqli_prepare($conn, $insert_sql);
            mysqli_stmt_bind_param($stmt, "ss", $key, $value);
            mysqli_stmt_execute($stmt);
        }
    }
    
    echo "Settings table created and default settings added successfully.\n";
} else {
    echo "Error creating settings table: " . mysqli_error($conn) . "\n";
}
?>
