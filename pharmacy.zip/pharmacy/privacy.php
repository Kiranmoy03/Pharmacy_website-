<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy - PharmaMed</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-12">
                <h1>Privacy Policy</h1>
                <div class="card">
                    <div class="card-body">
                        <h3>1. Information We Collect</h3>
                        <ul>
                            <li>Personal Information: Name, email, phone number, address</li>
                            <li>Order Information: Product details, order history, payment information</li>
                            <li>Usage Information: Website usage data, preferences, and interactions</li>
                        </ul>

                        <h3>2. How We Use Your Information</h3>
                        <ul>
                            <li>To process and fulfill your orders</li>
                            <li>To provide customer support</li>
                            <li>To improve our services and website</li>
                            <li>To send important notifications about your orders</li>
                        </ul>

                        <h3>3. Data Security</h3>
                        <ul>
                            <li>We use industry-standard security measures to protect your data</li>
                            <li>Your payment information is processed through secure payment gateways</li>
                            <li>We do not store sensitive payment information</li>
                        </ul>

                        <h3>4. Third Party Services</h3>
                        <ul>
                            <li>We may use third-party services for payment processing</li>
                            <li>Delivery services may require your address information</li>
                            <li>These services are bound by their own privacy policies</li>
                        </ul>

                        <h3>5. Your Rights</h3>
                        <ul>
                            <li>You can view and update your personal information</li>
                            <li>You can request deletion of your data</li>
                            <li>You can opt-out of marketing communications</li>
                        </ul>

                        <h3>6. Changes to Privacy Policy</h3>
                        <p>We may update this privacy policy from time to time. We will notify you of any significant changes.</p>

                        <h3>7. Contact Us</h3>
                        <p>If you have any questions about this privacy policy, please contact us at:</p>
                        <p>Email: support@pharmamed.com</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>
