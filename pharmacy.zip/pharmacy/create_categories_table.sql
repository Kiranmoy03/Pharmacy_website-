-- Create categories table if it doesn't exist
CREATE TABLE IF NOT EXISTS categories (
    category_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add category_id column to products table if it doesn't exist
ALTER TABLE products 
ADD COLUMN IF NOT EXISTS category_id INT,
ADD CONSTRAINT fk_product_category 
FOREIGN KEY (category_id) 
REFERENCES categories(category_id)
ON DELETE SET NULL;

-- If you want to keep the old category column data, you can run this after creating the categories:
-- INSERT IGNORE INTO categories (name) SELECT DISTINCT category FROM products WHERE category IS NOT NULL;
-- UPDATE products p JOIN categories c ON p.category = c.name SET p.category_id = c.category_id;
-- ALTER TABLE products DROP COLUMN category;
